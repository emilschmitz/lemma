//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT DISTINCT n.tag, n.version, COUNT(*) AS cnt
//!   FROM num n
//!   WHERE n.uom = 'USD' AND n.value IS NOT NULL
//!         AND EXISTS (
//!             SELECT 1 FROM pre p
//!             WHERE p.tag = n.tag AND p.version = n.version
//!                   AND p.stmt = 'CF'
//!         )
//!   GROUP BY n.tag, n.version
//!   ORDER BY cnt DESC
//!   LIMIT 100;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, Seq<char>), u64>
// Reverse scan ≡ method_spec_helper; nested EXISTS ≡ exists_corr_exists_1_helper.
pub exec fn run_query(cols: &Cols) -> (res: HashMap<(String, String), u64>)
    requires valid_cols(cols),
    ensures hashmap_str_str_u64_view(res@) == method_spec(cols),
{
    let mut agg = agg_new_str_str_u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            hashmap_str_str_u64_view(agg@) == method_spec_helper(cols, i as int),
        decreases i,
    {
        i = i - 1;
        let uom_ok = cols.eq_at_uom(i, "USD");
        let mut exists_ok = false;
        if uom_ok {
            let tag = cols.get_tag_exec(i);
            let version = cols.get_version_exec(i);
            let mut j: usize = 0;
            while j < cols.n
                invariant
                    i < cols.n,
                    j <= cols.n,
                    valid_cols(cols),
                    uom_ok == (cols.get_uom(i as int) == "USD"@),
                    tag@ == cols.get_tag(i as int),
                    version@ == cols.get_version(i as int),
                    !exists_ok ==> (exists_corr_exists_1_helper(
                        cols,
                        (tag@, version@),
                        0,
                    ) == exists_corr_exists_1_helper(cols, (tag@, version@), j as int)),
                    exists_ok ==> exists_corr_exists_1_spec(cols, (tag@, version@)),
                    hashmap_str_str_u64_view(agg@)
                        == method_spec_helper(cols, (i + 1) as int)
                decreases cols.n - j,
            {
                let tag_ok = cols.eq_at_tag(j, tag.as_str());
                let ver_ok = cols.eq_at_version(j, version.as_str());
                let stmt_ok = cols.eq_at_stmt(j, "CF");
                if tag_ok && ver_ok && stmt_ok {
                    exists_ok = true;
                    proof {
                        assert(exists_corr_exists_1_helper(
                            cols,
                            (tag@, version@),
                            j as int,
                        ));
                        assert(exists_corr_exists_1_spec(cols, (tag@, version@)));
                    }
                    j = cols.n;
                } else {
                    j = j + 1;
                    proof {
                        assert(exists_corr_exists_1_helper(
                            cols,
                            (tag@, version@),
                            (j - 1) as int,
                        ) == exists_corr_exists_1_helper(
                            cols,
                            (tag@, version@),
                            j as int,
                        ));
                    }
                }
            }
            proof {
                if exists_ok {
                    assert(exists_corr_exists_1_spec(
                        cols,
                        (cols.get_tag(i as int), cols.get_version(i as int)),
                    ));
                } else {
                    assert(!exists_corr_exists_1_helper(
                        cols,
                        (tag@, version@),
                        cols.n as int,
                    ));
                    assert(!exists_corr_exists_1_spec(
                        cols,
                        (cols.get_tag(i as int), cols.get_version(i as int)),
                    ));
                }
            }
            if exists_ok {
                agg_add_str_str_u64(&mut agg, tag.as_str(), version.as_str(), 1u64);
                proof {
                    let ghost tail = method_spec_helper(cols, (i + 1) as int);
                    let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
                    let ghost prev = if tail.contains_key(key) {
                        tail[key]
                    } else {
                        0u64
                    };
                    assert(hashmap_str_str_u64_view(agg@) == tail.insert(
                        key,
                        (prev as int + 1u64 as int) as u64,
                    ));
                    assert(hashmap_str_str_u64_view(agg@) == method_spec_helper(cols, i as int));
                }
            } else {
                proof {
                    assert(method_spec_helper(cols, i as int)
                        == method_spec_helper(cols, (i + 1) as int));
                }
            }
        } else {
            proof {
                assert(method_spec_helper(cols, i as int)
                    == method_spec_helper(cols, (i + 1) as int));
            }
        }
    }
    agg
}
// AGENT_EDIT_END

} // verus!
