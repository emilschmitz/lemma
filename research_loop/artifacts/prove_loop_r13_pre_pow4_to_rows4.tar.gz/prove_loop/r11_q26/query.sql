SELECT s.fy, s.fp, COUNT(DISTINCT s.cik) AS num_companies,
       SUM(n.value) AS total_value, AVG(n.value) AS avg_value
FROM num n
JOIN sub s ON n.adsh = s.adsh
WHERE n.tag = 'Assets' AND n.uom = 'USD'
      AND n.value IS NOT NULL AND s.fp IN ('Q1', 'Q2', 'Q3', 'Q4', 'FY')
GROUP BY s.fy, s.fp
ORDER BY s.fy, s.fp;
