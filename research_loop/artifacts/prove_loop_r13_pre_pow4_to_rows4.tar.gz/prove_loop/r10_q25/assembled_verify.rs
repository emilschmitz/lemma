use vstd::prelude::*;
use std::collections::{HashMap, HashSet};

verus! {

// === Lemma global input bounds (all queries) ===
pub const LEMMA_MAX_ROWS: usize = 2147483648;
pub const LEMMA_MAX_NATIVE_U32: u32 = 2147483648;
pub const LEMMA_MAX_MONEY_U64: u64 = 1099511627776;
pub const LEMMA_MAX_STRING_LEN: usize = 128;


// === Trusted arithmetic helpers ===
// TRUSTED: rustc wrapping_add; sound when ValidCols row/cell bounds apply (no overflow).
#[verifier::external_body]
pub exec fn add_u64(a: u64, b: u64) -> (res: u64)
    ensures res == a + b,
{
    a.wrapping_add(b)
}

// TRUSTED: rustc wrapping_mul; sound when ValidCols bounds apply.
#[verifier::external_body]
pub exec fn mul_u64_u32(a: u64, b: u32) -> (res: u64)
    ensures res == a * (b as u64),
{
    a.wrapping_mul(b as u64)
}

// TRUSTED: signed difference on bounded u64 cells.
#[verifier::external_body]
pub exec fn sub_u64_to_i64(a: u64, b: u64) -> (res: i64)
    ensures res == (a as int) - (b as int),
{
    (a as i64) - (b as i64)
}

// TRUSTED: rustc wrapping_add on i64.
#[verifier::external_body]
pub exec fn add_i64(a: i64, b: i64) -> (res: i64)
    ensures res == a + b,
{
    a.wrapping_add(b)
}

// === CASE WHEN (simple int branches) ===
pub open spec fn case_when_u64(cond: bool, then_v: u64, else_v: u64) -> u64 {
    if cond { then_v } else { else_v }
}

#[verifier::external_body]
pub exec fn case_when_u64_exec(cond: bool, then_v: u64, else_v: u64) -> (res: u64)
    ensures res == case_when_u64(cond, then_v, else_v),
{
    if cond { then_v } else { else_v }
}

// === String LIKE helpers (basic % prefix/suffix/contains) ===
pub open spec fn str_like_prefix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_prefix_of(s)
}

pub open spec fn str_like_suffix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_suffix_of(s)
}

// TRUSTED axiom: substring containment (exists quantifier needs manual triggers).
#[verifier::external_body]
pub open spec fn str_like_contains(s: Seq<char>, lit: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED: exec string prefix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_prefix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_prefix(s@, lit@),
{
    s.starts_with(lit)
}

// TRUSTED: exec string suffix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_suffix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_suffix(s@, lit@),
{
    s.ends_with(lit)
}

// TRUSTED: exec string contains check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_contains_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_contains(s@, lit@),
{
    s.contains(lit)
}

// === ILIKE + underscore LIKE (TRUSTED pattern match) ===
// TRUSTED axiom: case-insensitive SQL LIKE/ILIKE pattern (%, _ wildcards).
#[verifier::external_body]
pub open spec fn str_ilike_match(s: Seq<char>, pat: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED axiom: case-sensitive LIKE with _ single-char wildcard.
#[verifier::external_body]
pub open spec fn str_like_underscore_match(s: Seq<char>, pat: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED: exec ILIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_ilike_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_ilike_match(s@, pat@),
{
    str_like_underscore_match_exec(&s.to_ascii_lowercase(), &pat.to_ascii_lowercase())
}

// TRUSTED: exec underscore LIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_underscore_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_like_underscore_match(s@, pat@),
{
    fn m(s: &[char], si: usize, p: &[char], pi: usize) -> bool {
        if pi >= p.len() {
            return si >= s.len();
        }
        if p[pi] == '%' {
            let mut k = si;
            while k <= s.len() {
                if m(s, k, p, pi + 1) {
                    return true;
                }
                k += 1;
            }
            return false;
        }
        if p[pi] == '_' {
            if si >= s.len() {
                return false;
            }
            return m(s, si + 1, p, pi + 1);
        }
        if si >= s.len() || s[si] != p[pi] {
            return false;
        }
        m(s, si + 1, p, pi + 1)
    }
    let sc: Vec<char> = s.chars().collect();
    let pc: Vec<char> = pat.chars().collect();
    m(&sc, 0, &pc, 0)
}

// === Scalar helpers (abs / case) ===
// TRUSTED: abs on bounded u64 cell.
#[verifier::external_body]
pub open spec fn abs_u64(x: u64) -> u64 {
    arbitrary()
}

#[verifier::external_body]
pub exec fn abs_u64_exec(x: u64) -> (res: u64)
    ensures res == abs_u64(x),
{
    if x > (0u64) { x } else { 0u64.wrapping_sub(x) }
}

// TRUSTED axiom: ASCII lower/upper on Seq<char>.
#[verifier::external_body]
pub open spec fn str_lower(s: Seq<char>) -> Seq<char> {
    arbitrary()
}

#[verifier::external_body]
pub open spec fn str_upper(s: Seq<char>) -> Seq<char> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn str_lower_exec(s: &str) -> (res: String)
    ensures res@ == str_lower(s@),
{
    s.to_ascii_lowercase()
}

#[verifier::external_body]
pub exec fn str_upper_exec(s: &str) -> (res: String)
    ensures res@ == str_upper(s@),
{
    s.to_ascii_uppercase()
}

// === Seq helpers (projection + LIMIT) ===
pub open spec fn spec_seq_take<A>(s: Seq<A>, n: int) -> Seq<A> {
    if n <= 0 {
        Seq::empty()
    } else if n >= s.len() {
        s
    } else {
        s.subrange(0, n)
    }
}

pub open spec fn spec_seq_concat<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_concat_helper(a, b, 0)
}

pub open spec fn spec_seq_concat_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        spec_seq_concat_helper(a.push(b[i]), b, i + 1)
    } else {
        a
    }
}

pub open spec fn spec_seq_union_distinct<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_union_distinct_helper(a, b, 0)
}

pub open spec fn spec_seq_union_distinct_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        let tail = spec_seq_union_distinct_helper(a, b, i + 1);
        if tail.contains(b[i]) {
            tail
        } else {
            tail.push(b[i])
        }
    } else {
        a
    }
}

pub open spec fn seq_sum_u64(s: Seq<u64>) -> u64 {
    seq_sum_u64_helper(s, 0)
}

pub open spec fn seq_sum_u64_helper(s: Seq<u64>, i: int) -> u64
    decreases s.len() - i,
{
    if i < s.len() {
        (seq_sum_u64_helper(s, i + 1) as int + s[i] as int) as u64
    } else {
        0
    }
}

// === IS NULL / anti-join (Lemma non-null loads; LEFT JOIN miss) ===
// TRUSTED: LEFT JOIN anti-join miss predicate (schema-driven bridge).
#[verifier::external_body]
pub open spec fn left_join_miss_generic(cols: &Cols, row: int) -> bool {
    arbitrary()
}

// TRUSTED: multi-agg HashMap exec view bridge.
#[verifier::external_body]
pub open spec fn hashmap_multi_agg_view<K, V>(m: Map<K, V>) -> Map<K, V> {
    m
}


pub struct Cols {
    pub n: usize,
    pub cik: Vec<u32>,
    pub countryba: Vec<String>,
    pub form: Vec<String>,
    pub fy: Vec<u32>,
}

impl Cols {
    pub open spec fn get_cik(self, i: int) -> u32 {
        self.cik[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_cik_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_cik(i as int),
    {
        self.cik[i]
    }
    pub open spec fn get_countryba(self, i: int) -> Seq<char> {
        self.countryba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryba(i as int),
    {
        self.countryba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryba(i as int) == lit@),
    {
        self.countryba[i] == lit
    }
    pub open spec fn get_form(self, i: int) -> Seq<char> {
        self.form[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_form_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_form(i as int),
    {
        self.form[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_form(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_form(i as int) == lit@),
    {
        self.form[i] == lit
    }
    pub open spec fn get_fy(self, i: int) -> u32 {
        self.fy[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_fy_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_fy(i as int),
    {
        self.fy[i]
    }
}


pub open spec fn valid_cols(cols: &Cols) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.cik.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.cik[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.countryba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.form@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.form[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.fy.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.fy[i] < LEMMA_MAX_NATIVE_U32
}

pub proof fn valid_cols_get_cik(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures cols.cik[i as int] < LEMMA_MAX_NATIVE_U32,
{
}

pub proof fn valid_cols_get_countryba(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.countryba[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_form(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.form[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_fy(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures cols.fy[i as int] < LEMMA_MAX_NATIVE_U32,
{
}

pub open spec fn method_spec_helper(cols: &Cols, k: int) -> Map<(Seq<char>, Seq<char>, u32), (u64, Map<u32, bool>)>
    recommends
        0 <= k && k <= cols.n,
        valid_cols(cols),
    decreases cols.n - k,
{
    if k < cols.n {
        let tail = method_spec_helper(cols, k + 1);
        if (cols.get_fy(k) == 2024 && (cols.get_countryba(k) != ""@)) {
            let key = (cols.countryba[k as int]@, cols.form[k as int]@, cols.fy[k as int]);
            let prev = if tail.contains_key(key) { tail[key] } else { (0u64, Map::empty()) };
            let s0 = (prev.0 as int + 1) as u64;
            let s1 = if prev.1.contains_key(cols.cik[k as int]) { prev.1 } else { prev.1.insert(cols.cik[k as int], true) };
            tail.insert(key, (s0, s1))
        } else {
            tail
        }
    } else {
        Map::empty()
    }
}

pub open spec fn method_spec(cols: &Cols) -> Map<(Seq<char>, Seq<char>, u32), (u64, u64)>
    recommends valid_cols(cols),
{
    let raw = method_spec_helper(cols, 0);
    raw.map_values(|v: (u64, Map<u32, bool>)| (v.0, v.1.dom().len() as u64))
}

// Note: ORDER BY (filing_count DESC), LIMIT 200, OFFSET 0 are not part of method_spec (((Seq<char>, Seq<char>, u32), (u64, u64))); agent may apply in run_query.

// === TRUSTED structural map helpers (view + agg_new + agg_put/agg_add) ===
#[verifier::external_body]
pub open spec fn hashmap_str_str_u32__u64_u64_view(hm: Map<(String, String, u32), (u64, u64)>) -> Map<(Seq<char>, Seq<char>, u32), (u64, u64)> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn agg_new_str_str_u32__u64_u64() -> (hm: HashMap<(String, String, u32), (u64, u64)>)
    ensures hashmap_str_str_u32__u64_u64_view(hm@) == Map::empty(),
{
    HashMap::new()
}

#[verifier::external_body]
pub exec fn agg_put_str_str_u32__u64_u64(hm: &mut HashMap<(String, String, u32), (u64, u64)>, k0: &str, k1: &str, k2: u32, v0: u64, v1: u64)
    ensures hashmap_str_str_u32__u64_u64_view(final(hm)@) == hashmap_str_str_u32__u64_u64_view(old(hm)@).insert((k0@, k1@, k2), (v0, v1)),
{
    let key = (k0.to_string(), k1.to_string(), k2);
    hm.insert(key, (v0, v1));
}

#[verifier::external_body]
pub exec fn agg_add_str_str_u32__u64_u64(hm: &mut HashMap<(String, String, u32), (u64, u64)>, k0: &str, k1: &str, k2: u32, d0: u64, d1: u64)
    ensures
        hashmap_str_str_u32__u64_u64_view(final(hm)@) == hashmap_str_str_u32__u64_u64_view(old(hm)@).insert(
        (k0@, k1@, k2),
        (if hashmap_str_str_u32__u64_u64_view(old(hm)@).contains_key((k0@, k1@, k2)) {
            (hashmap_str_str_u32__u64_u64_view(old(hm)@)[(k0@, k1@, k2)].0 as int + d0 as int) as u64
        } else {
            d0
        }, if hashmap_str_str_u32__u64_u64_view(old(hm)@).contains_key((k0@, k1@, k2)) {
            (hashmap_str_str_u32__u64_u64_view(old(hm)@)[(k0@, k1@, k2)].1 as int + d1 as int) as u64
        } else {
            d1
        }),
    ),
{
    let key = (k0.to_string(), k1.to_string(), k2);
    let prev = hm.get(&key).copied().unwrap_or((0u64, 0u64));
    hm.insert(key, (prev.0.wrapping_add(d0), prev.1.wrapping_add(d1)));
}

// === TRUSTED distinct-set helpers (str: HashSet exec ↔ Map spec view) ===
#[verifier::external_body]
pub open spec fn hashset_str_view(s: Set<String>) -> Map<Seq<char>, bool> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn set_new_str() -> (s: HashSet<String>)
    ensures hashset_str_view(s@) == Map::empty(),
{
    HashSet::new()
}

#[verifier::external_body]
pub exec fn set_insert_str(s: &mut HashSet<String>, k: &str) -> (is_new: bool)
    ensures
        hashset_str_view(final(s)@).contains_key(k@),
        hashset_str_view(final(s)@) == hashset_str_view(old(s)@).insert(k@, true),
        is_new == !hashset_str_view(old(s)@).contains_key(k@),
        is_new ==> hashset_str_view(final(s)@).dom().len() == hashset_str_view(old(s)@).dom().len() + 1,
        !is_new ==> hashset_str_view(final(s)@).dom().len() == hashset_str_view(old(s)@).dom().len(),
{
    let is_new = !s.contains(k);
    s.insert(k.to_string());
    is_new
}

// === TRUSTED distinct-set helpers (u32: HashSet exec ↔ Map spec view) ===
#[verifier::external_body]
pub open spec fn hashset_u32_view(s: Set<u32>) -> Map<u32, bool> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn set_new_u32() -> (s: HashSet<u32>)
    ensures hashset_u32_view(s@) == Map::empty(),
{
    HashSet::new()
}

#[verifier::external_body]
pub exec fn set_insert_u32(s: &mut HashSet<u32>, k: u32) -> (is_new: bool)
    ensures
        hashset_u32_view(final(s)@).contains_key(k),
        hashset_u32_view(final(s)@) == hashset_u32_view(old(s)@).insert(k, true),
        is_new == !hashset_u32_view(old(s)@).contains_key(k),
        is_new ==> hashset_u32_view(final(s)@).dom().len() == hashset_u32_view(old(s)@).dom().len() + 1,
        !is_new ==> hashset_u32_view(final(s)@).dom().len() == hashset_u32_view(old(s)@).dom().len(),
{
    let is_new = !s.contains(&k);
    s.insert(k);
    is_new
}

// === Multi-agg group step (str_str_u32__u64_u64): inner HashMap + projected map ===
pub struct AggStepState_str_str_u32__u64_u64 {
    pub projected: HashMap<(String, String, u32), (u64, u64)>,
    pub inner: HashMap<(String, String, u32), (u64, std::collections::HashSet<u32>)>,
}

#[verifier::external_body]
pub open spec fn agg_step_inner_str_str_u32__u64_u64_view(hm: Map<(String, String, u32), (u64, std::collections::HashSet<u32>)>) -> Map<(Seq<char>, Seq<char>, u32), (u64, Map<u32, bool>)> {
    arbitrary()
}

pub open spec fn agg_step_project_str_str_u32__u64_u64(v: (u64, Map<u32, bool>)) -> (u64, u64) {
    (v.0, v.1.dom().len() as u64)
}

pub open spec fn agg_step_apply_row_str_str_u32__u64_u64(prev: (u64, Map<u32, bool>), distinct_0: u32) -> (u64, Map<u32, bool>) {
    let s0 = (prev.0 as int + 1) as u64;
    let s1 = if prev.1.contains_key(distinct_0) { prev.1 } else { prev.1.insert(distinct_0, true) };
    (s0, s1)
}

#[verifier::external_body]
pub exec fn agg_step_state_new_str_str_u32__u64_u64() -> (st: AggStepState_str_str_u32__u64_u64)
    ensures
        hashmap_str_str_u32__u64_u64_view(st.projected@) == Map::empty(),
        agg_step_inner_str_str_u32__u64_u64_view(st.inner@) == Map::empty(),
{
    AggStepState_str_str_u32__u64_u64 { projected: HashMap::new(), inner: HashMap::new() }
}

#[verifier::external_body]
pub exec fn agg_step_str_str_u32__u64_u64(
    st: &mut AggStepState_str_str_u32__u64_u64,
    k0: &str, k1: &str, k2: u32, distinct_0: u32,
)
    ensures
        ({
            let spec_key = (k0@, k1@, k2);
            let old_inner = agg_step_inner_str_str_u32__u64_u64_view(old(st).inner@);
            let prev_inner = if old_inner.contains_key(spec_key) {
                old_inner[spec_key]
            } else {
                (0u64, Map::empty())
            };
            let new_inner = agg_step_apply_row_str_str_u32__u64_u64(prev_inner, distinct_0);
            &&& agg_step_inner_str_str_u32__u64_u64_view(final(st).inner@) == old_inner.insert(spec_key, new_inner)
            &&& hashmap_str_str_u32__u64_u64_view(final(st).projected@) == hashmap_str_str_u32__u64_u64_view(old(st).projected@).insert(
                spec_key,
                agg_step_project_str_str_u32__u64_u64(new_inner),
            )
        }),
{
    let key = (k0.to_string(), k1.to_string(), k2);
    let prev = st.inner.get(&key).cloned().unwrap_or((0u64, std::collections::HashSet::new()));
    let v0 = prev.0.wrapping_add(1);
    let mut v1 = prev.1.clone();
    set_insert_u32(&mut v1, distinct_0);
    let new_inner = (v0, v1);
    st.inner.insert(key.clone(), new_inner.clone());
    st.projected.insert(key, ((new_inner.0, new_inner.1.len() as u64)));
}

// === Agent primitives: zone-map selective scan (GenDB zone pruning) ===
#[derive(Clone, Copy)]
pub struct ZoneSegmentU32 {
    pub min: u32,
    pub max: u32,
    pub start: usize,
    pub end: usize,
}

#[verifier::external_body]
pub exec fn build_zone_map_u32(col: &Vec<u32>, zone_rows: usize) -> (zones: Vec<ZoneSegmentU32>)
    ensures zones@.len() == 0 || zone_rows > 0,
{
    let zr = if zone_rows == 0 { 1 } else { zone_rows };
    let mut zones: Vec<ZoneSegmentU32> = Vec::new();
    if col.is_empty() {
        return zones;
    }
    let mut start: usize = 0;
    while start < col.len() {
        let end = if start + zr < col.len() { start + zr } else { col.len() };
        let mut min_v = col[start];
        let mut max_v = col[start];
        let mut j = start + 1;
        while j < end {
            if col[j] < min_v { min_v = col[j]; }
            if col[j] > max_v { max_v = col[j]; }
            j = j + 1;
        }
        zones.push(ZoneSegmentU32 { min: min_v, max: max_v, start, end });
        start = end;
    }
    zones
}

#[verifier::external_body]
pub exec fn may_satisfy_range_u32(seg: &ZoneSegmentU32, lo: u32, hi: u32) -> (b: bool)
    ensures b == (seg.max >= lo && seg.min <= hi),
{
    seg.max >= lo && seg.min <= hi
}

// === Agent primitives: hash-join build/probe (capacity-hinted HashSet) ===
#[verifier::external_body]
pub exec fn build_hashset_u32(keys: &Vec<u32>, capacity_hint: usize) -> (s: std::collections::HashSet<u32>)
    ensures true,
{
    use std::collections::HashSet;
    let cap = if capacity_hint > keys.len() { capacity_hint } else { keys.len() };
    let mut set = HashSet::with_capacity(cap);
    let mut i: usize = 0;
    while i < keys.len() {
        set.insert(keys[i]);
        i = i + 1;
    }
    set
}

#[verifier::external_body]
pub exec fn probe_sum_u64(
    probe_keys: &Vec<u32>,
    values: &Vec<u64>,
    build: &std::collections::HashSet<u32>,
) -> (sum: u64)
    ensures sum <= probe_keys@.len() as u64 * u64::MAX,
{
    let n = if probe_keys.len() < values.len() { probe_keys.len() } else { values.len() };
    let mut sum: u64 = 0;
    let mut i: usize = 0;
    while i < n {
        if build.contains(&probe_keys[i]) {
            sum = sum.wrapping_add(values[i]);
        }
        i = i + 1;
    }
    sum
}

// === Agent primitives: small-cardinality direct-index agg (≤64 buckets) ===
// Use a fixed [u64; N] accumulator when group NDV ≤ 64; index by dense key 0..N-1.
// Example: let mut buckets = [0u64; 6]; buckets[key as usize] = add_u64(buckets[key as usize], delta);

// === Agent primitives: dictionary string decode (duckdb_like load format) ===
#[verifier::external_body]
pub exec fn decode_dict_str(codes: &Vec<u32>, dict: &Vec<String>, i: usize) -> (s: String)
    requires i < codes@.len(),
    ensures (codes[i as int] as int) < dict@.len(),
{
    dict[codes[i] as usize].clone()
}

pub exec fn run_query(cols: &Cols) -> (res: HashMap<(String, String, u32), (u64, u64)>)
    requires valid_cols(cols),
    ensures hashmap_str_str_u32__u64_u64_view(res@) == method_spec(cols),
{
    let mut st = agg_step_state_new_str_str_u32__u64_u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            agg_step_inner_str_str_u32__u64_u64_view(st.inner@) == method_spec_helper(cols, i as int),
            hashmap_str_str_u32__u64_u64_view(st.projected@)
                == agg_step_inner_str_str_u32__u64_u64_view(st.inner@).map_values(
                    |v: (u64, Map<u32, bool>)| agg_step_project_str_str_u32__u64_u64(v),
                ),
        decreases i,
    {
        i = i - 1;
        let fy = cols.get_fy_exec(i);
        if fy == 2024 && !cols.eq_at_countryba(i, "") {
            let countryba = cols.get_countryba_exec(i);
            let form = cols.get_form_exec(i);
            let cik = cols.get_cik_exec(i);
            agg_step_str_str_u32__u64_u64(
                &mut st,
                countryba.as_str(),
                form.as_str(),
                fy,
                cik,
            );
            proof {
                let ghost tail = method_spec_helper(cols, (i + 1) as int);
                let ghost key = (cols.countryba[i as int]@, cols.form[i as int]@, cols.fy[i as int]);
                let ghost prev = if tail.contains_key(key) {
                    tail[key]
                } else {
                    (0u64, Map::empty())
                };
                let ghost expected = agg_step_apply_row_str_str_u32__u64_u64(
                    prev,
                    cols.cik[i as int],
                );
                assert(expected == method_spec_helper(cols, i as int)[key]);
                assert(agg_step_inner_str_str_u32__u64_u64_view(st.inner@) == method_spec_helper(cols, i as int));
            }
        } else {
            proof {
                assert(method_spec_helper(cols, i as int) == method_spec_helper(cols, (i + 1) as int));
            }
        }
    }
    st.projected
}


#[verifier::external_body]
pub exec fn load_cols(path: &str, limit: usize) -> (cols: Cols)
    ensures valid_cols(&cols),
{
    use std::collections::HashMap;
    use std::fs::File;
    use std::io::{BufRead, BufReader};

    fn strip_quotes(s: &str) -> &str {
        s.trim_matches('"')
    }

    let f = File::open(path).expect("open .tbl");
    let mut rdr = BufReader::new(f);
    let mut hdr = String::new();
    rdr.read_line(&mut hdr).unwrap();
    let mut name_to_idx: HashMap<String, usize> = HashMap::new();
    for (i, c) in hdr.split('|').enumerate() {
        name_to_idx.insert(c.trim().to_uppercase(), i);
    }
        let cik_i = *name_to_idx.get("CIK").expect("missing col cik");
        let countryba_i = *name_to_idx.get("COUNTRYBA").expect("missing col countryba");
        let form_i = *name_to_idx.get("FORM").expect("missing col form");
        let fy_i = *name_to_idx.get("FY").expect("missing col fy");

        let mut cik: Vec<u32> = Vec::new();
        let mut countryba: Vec<String> = Vec::new();
        let mut form: Vec<String> = Vec::new();
        let mut fy: Vec<u32> = Vec::new();

    for raw_line in rdr.lines().take(limit) {
        let raw_line = raw_line.unwrap();
        let f: Vec<&str> = raw_line.split('|').collect();
        if f.is_empty() {
            continue;
        }
        cik.push(f[cik_i].parse::<u32>().unwrap());
        countryba.push(strip_quotes(f[countryba_i]).to_string());
        form.push(strip_quotes(f[form_i]).to_string());
        fy.push(f[fy_i].parse::<u32>().unwrap());
    }

    let n = cik.len();
    Cols {
        n,
            cik,
            countryba,
            form,
            fy,
    }
}

} // verus!

fn main() {
    use std::env;
    use std::time::Instant;

    let args: Vec<String> = env::args().collect();
    let tbl_path = args
        .get(1)
        .map(|s| s.as_str())
        .unwrap_or("research_loop/generated/prove_loop/r10_q25/sub.tbl");
    let limit: usize = args
        .get(2)
        .and_then(|s| s.parse().ok())
        .unwrap_or(50_000);

    let cols = load_cols(tbl_path, limit);


    let mut times = [0u128; 5];
    let mut last = String::new();
    for t in &mut times {
        let t0 = Instant::now();
        let res = run_query(&cols);
        std::hint::black_box(res.len());
        *t = t0.elapsed().as_micros();
        last = {
        let checksum: u64 = res.values().fold(0u64, |a, v| {
            a.wrapping_add(v.0).wrapping_add(v.1)
        });
        format!("RESULT: map_len={} checksum={}", res.len(), checksum)
    };
    }
    times.sort();
    println!("QUERY_LATENCY_US: {}", times[times.len() / 2]);
    println!("{}", last);
}
