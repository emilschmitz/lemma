SELECT countryba, form, fy, COUNT(*) AS filing_count,
       COUNT(DISTINCT cik) AS company_count
FROM sub
WHERE fy = 2024 AND countryba IS NOT NULL
GROUP BY countryba, form, fy
ORDER BY filing_count DESC
LIMIT 200;
