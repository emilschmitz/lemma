//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT countryba, form, fy, COUNT(*) AS filing_count,
//!          COUNT(DISTINCT cik) AS company_count
//!   FROM sub
//!   WHERE fy = 2024 AND countryba IS NOT NULL
//!   GROUP BY countryba, form, fy
//!   ORDER BY filing_count DESC
//!   LIMIT 200;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, Seq<char>, u32), (u64, u64)>
// Trusted: agg_step_str_str_u32__u64_u64 + hashmap_str_str_u32__u64_u64_view
pub exec fn run_query(cols: &Cols) -> (res: HashMap<(String, String, u32), (u64, u64)>)
    requires valid_cols(cols),
    ensures hashmap_str_str_u32__u64_u64_view(res@) == method_spec(cols),
{
    let mut st = agg_step_state_new_str_str_u32__u64_u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            agg_step_inner_str_str_u32__u64_u64_view(st.inner@) == method_spec_helper(cols, i as int),
            hashmap_str_str_u32__u64_u64_view(st.projected@)
                == agg_step_inner_str_str_u32__u64_u64_view(st.inner@).map_values(
                    |v: (u64, Map<u32, bool>)| agg_step_project_str_str_u32__u64_u64(v),
                ),
        decreases i,
    {
        i = i - 1;
        let fy = cols.get_fy_exec(i);
        if fy == 2024 && !cols.eq_at_countryba(i, "") {
            let countryba = cols.get_countryba_exec(i);
            let form = cols.get_form_exec(i);
            let cik = cols.get_cik_exec(i);
            agg_step_str_str_u32__u64_u64(
                &mut st,
                countryba.as_str(),
                form.as_str(),
                fy,
                cik,
            );
            proof {
                let ghost tail = method_spec_helper(cols, (i + 1) as int);
                let ghost key = (cols.countryba[i as int]@, cols.form[i as int]@, cols.fy[i as int]);
                let ghost prev = if tail.contains_key(key) {
                    tail[key]
                } else {
                    (0u64, Map::empty())
                };
                let ghost expected = agg_step_apply_row_str_str_u32__u64_u64(
                    prev,
                    cols.cik[i as int],
                );
                assert(expected == method_spec_helper(cols, i as int)[key]);
                assert(agg_step_inner_str_str_u32__u64_u64_view(st.inner@) == method_spec_helper(cols, i as int));
            }
        } else {
            proof {
                assert(method_spec_helper(cols, i as int) == method_spec_helper(cols, (i + 1) as int));
            }
        }
    }
    st.projected
}
// AGENT_EDIT_END

} // verus!
