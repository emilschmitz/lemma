use vstd::prelude::*;
use std::collections::{HashMap, HashSet};

verus! {

// === Lemma global input bounds ===
pub const LEMMA_MAX_ROWS: usize = 65536;
pub const LEMMA_MAX_ROWS_CUBE: usize = 2047;
pub const LEMMA_MAX_ROWS_4: usize = 256;
pub const LEMMA_MAX_NATIVE_U32: u32 = 2147483648;
pub const LEMMA_MAX_STRING_LEN: usize = 128;
// Assumption-driven u64 cell cap (NOT implied by BIGINT type width).
pub const LEMMA_MAX_CELL_U64: u64 = 2147483648;
pub const LEMMA_MAX_MONEY_U64: u64 = LEMMA_MAX_CELL_U64;


// === Lemma global product bounds (host arithmetic) ===
#[verifier::external_body]
pub proof fn lemma_max_rows_times_native_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_sq_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_sq_times_native_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_NATIVE_U32 as int)
            <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS², then (rem_cap+1)·MONEY fits in u64 (uses join product bound).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS², then (rem_cap+1)·NATIVE_U32 fits (2-table join rem for SUM(native)).
#[verifier::external_body]
pub proof fn lemma_rem_cap_native_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

// ASSUMPTION (catalog/user): nested-loop rem ≤ ROWS² under valid_cols row caps.
// Not Verus-proved from fold induction — expert accepts under table assumptions.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_sq(
    n0: usize,
    n1: usize,
    i0: int,
    i1: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
    ensures
        ((n1 as int - i1) + (n0 as int - i0 - 1) * (n1 as int)) >= 0,
        (((n1 - i1) + (n0 - i0 - 1) * n1) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_cube_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_ROWS_CUBE as int)
            * (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_4_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

// rem_cap ≤ CUBE³ ⇒ (rem_cap+1)·MONEY fits (3-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS_4⁴ ⇒ (rem_cap+1)·MONEY fits (4-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS² ⇒ rem_cap+1 fits in u64 (COUNT / prev_le discharge).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS ⇒ rem_cap+1 fits (single-table suffix rem).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_rows(prev_cap: u64)
    requires
        prev_cap <= LEMMA_MAX_ROWS as u64,
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS³ ⇒ rem_cap+1 fits (3-table suffix rem with ROWS caps).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_pow3(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS⁴ ⇒ rem_cap+1 fits (4-table suffix rem with ROWS caps).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ CUBE³ ⇒ rem_cap+1 fits (3-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS_4⁴ ⇒ rem_cap+1 fits (4-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// ASSUMPTION (catalog/user): 3-table nested rem ≤ CUBE³ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_cube(
    n0: usize,
    n1: usize,
    n2: usize,
    i0: int,
    i1: int,
    i2: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS_CUBE,
        n1 <= LEMMA_MAX_ROWS_CUBE,
        n2 <= LEMMA_MAX_ROWS_CUBE,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
    ensures
        ((n2 as int - i2)
            + (n1 as int - i1 - 1) * (n2 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int)) >= 0,
        (((n2 - i2) + (n1 - i1 - 1) * n2 + (n0 - i0 - 1) * n1 * n2) as u64)
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
{
}

// ASSUMPTION (catalog/user): 4-table nested rem ≤ ROWS_4⁴ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_4(
    n0: usize,
    n1: usize,
    n2: usize,
    n3: usize,
    i0: int,
    i1: int,
    i2: int,
    i3: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS_4,
        n1 <= LEMMA_MAX_ROWS_4,
        n2 <= LEMMA_MAX_ROWS_4,
        n3 <= LEMMA_MAX_ROWS_4,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
        0 <= i3 <= n3 as int,
    ensures
        ((n3 as int - i3)
            + (n2 as int - i2 - 1) * (n3 as int)
            + (n1 as int - i1 - 1) * (n2 as int) * (n3 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int) * (n3 as int)) >= 0,
        (((n3 - i3) + (n2 - i2 - 1) * n3 + (n1 - i1 - 1) * n2 * n3
            + (n0 - i0 - 1) * n1 * n2 * n3) as u64)
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
{
}

// ASSUMPTION (catalog/user): 3-table suffix rem ≤ ROWS³ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_fold_suffix_rem_leq_rows_pow3(
    n0: usize,
    n1: usize,
    n2: usize,
    i0: int,
    i1: int,
    i2: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        n2 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
    ensures
        (((n2 as int - i2) + (n1 as int - i1 - 1) * (n2 as int) + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int)) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

// ASSUMPTION (catalog/user): 4-table suffix rem ≤ ROWS⁴ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_fold_suffix_rem_leq_rows_pow4(
    n0: usize,
    n1: usize,
    n2: usize,
    n3: usize,
    i0: int,
    i1: int,
    i2: int,
    i3: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        n2 <= LEMMA_MAX_ROWS,
        n3 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
        0 <= i3 <= n3 as int,
    ensures
        (((n3 as int - i3) + (n2 as int - i2 - 1) * (n3 as int) + (n1 as int - i1 - 1) * (n2 as int) * (n3 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int) * (n3 as int)) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_native_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

// === Discharge add_u64 / agg_add_* / agg_step_* checked_add requires ===
// COUNT / AVG-denom: prev <= n rows processed so far.
pub proof fn lemma_u64_add_one_fit(prev: u64, n: usize)
    requires
        prev <= n as u64,
        n <= LEMMA_MAX_ROWS,
    ensures
        (prev as int) + 1 <= u64::MAX as int,
{
}

// SUM(native u32 cell): prev <= n * cell_cap, cell < cell_cap, n <= LEMMA_MAX_ROWS.
#[verifier::external_body]
pub proof fn lemma_u64_add_native_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_NATIVE_U32 as u64),
        cell < LEMMA_MAX_NATIVE_U32 as u64,
        n <= LEMMA_MAX_ROWS,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// SUM(money u64 cell): requires global product bound (honest gate when constants allow).
#[verifier::external_body]
pub proof fn lemma_u64_add_cell_u64_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_CELL_U64 as u64),
        cell < LEMMA_MAX_CELL_U64,
        n <= LEMMA_MAX_ROWS,
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// COUNT with an explicit row-suffix / join-rem cap (elementary: prev ≤ cap ⇒ prev+1 fits).
#[verifier::external_body]
pub proof fn lemma_u64_add_one_prev_le(prev: u64, prev_cap: u64)
    requires
        prev <= prev_cap,
        (prev_cap as int) + 1 <= u64::MAX as int,
    ensures
        (prev as int) + 1 <= u64::MAX as int,
{
}

// SUM(money) with explicit rem-cap: prev ≤ cap·M, cell < M, (cap+1)·M fits ⇒ prev+cell fits.
// Same *kind* of fact as bounded int add (checkable from constants when cap ≤ ROWS²).
#[verifier::external_body]
pub proof fn lemma_u64_add_cell_u64_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_CELL_U64 as u64),
        cell < LEMMA_MAX_CELL_U64,
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// Native SUM with rem-cap (same shape as money).
#[verifier::external_body]
pub proof fn lemma_u64_add_native_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_NATIVE_U32 as u64),
        cell < LEMMA_MAX_NATIVE_U32 as u64,
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}


// === Deprecated aliases (money → cell_u64); prefer cell_u64 names ===
pub proof fn lemma_max_rows_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
    lemma_max_rows_times_cell_u64_fits_u64();
}

pub proof fn lemma_max_rows_sq_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
    lemma_max_rows_sq_times_cell_u64_fits_u64();
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_u64_add_money_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_MONEY_U64 as u64),
        cell < LEMMA_MAX_MONEY_U64,
        n <= LEMMA_MAX_ROWS,
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_u64_add_money_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_MONEY_U64 as u64),
        cell < LEMMA_MAX_MONEY_U64,
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_cube_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_ROWS_CUBE as int)
            * (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_4_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
}


// === Trusted arithmetic helpers ===
// TRUSTED: if (a as int) + (b as int) <= u64::MAX then add is mathematical +.
#[verifier::external_body]
pub exec fn add_u64(a: u64, b: u64) -> (res: u64)
    requires
        (a as int) + (b as int) <= u64::MAX as int,
    ensures
        res == a + b,
{
    a.checked_add(b).expect("Trusted overflow: ValidCols/requires violated")
}

// TRUSTED: if (a as int) * (b as int) <= u64::MAX then mul is mathematical *.
#[verifier::external_body]
pub exec fn mul_u64_u32(a: u64, b: u32) -> (res: u64)
    requires
        (a as int) * (b as int) <= u64::MAX as int,
    ensures
        res == a * (b as u64),
{
    a.checked_mul(b as u64).expect("Trusted overflow: ValidCols/requires violated")
}

// TRUSTED: if (a as int) - (b as int) fits in i64 then sub is mathematical -.
#[verifier::external_body]
pub exec fn sub_u64_to_i64(a: u64, b: u64) -> (res: i64)
    requires
        (a as int) - (b as int) >= i64::MIN as int,
        (a as int) - (b as int) <= i64::MAX as int,
    ensures
        res == (a as int) - (b as int),
{
    (a as i64) - (b as i64)
}

// TRUSTED: if (a as int) + (b as int) fits in i64 then add is mathematical +.
#[verifier::external_body]
pub exec fn add_i64(a: i64, b: i64) -> (res: i64)
    requires
        (a as int) + (b as int) >= i64::MIN as int,
        (a as int) + (b as int) <= i64::MAX as int,
    ensures
        res == a + b,
{
    a.checked_add(b).expect("Trusted overflow: ValidCols/requires violated")
}

// === CASE WHEN (simple int branches) ===
pub open spec fn case_when_u64(cond: bool, then_v: u64, else_v: u64) -> u64 {
    if cond { then_v } else { else_v }
}

#[verifier::external_body]
pub exec fn case_when_u64_exec(cond: bool, then_v: u64, else_v: u64) -> (res: u64)
    ensures res == case_when_u64(cond, then_v, else_v),
{
    if cond { then_v } else { else_v }
}

// === String LIKE helpers (basic % prefix/suffix/contains) ===
pub open spec fn str_like_prefix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_prefix_of(s)
}

pub open spec fn str_like_suffix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_suffix_of(s)
}

// Substring containment (open spec; empty lit matches any s).
pub open spec fn str_like_contains(s: Seq<char>, lit: Seq<char>) -> bool {
  if lit.len() == 0 {
    true
  } else {
    exists|i: int|
      0 <= i
      && i + lit.len() <= s.len()
      && #[trigger] s.subrange(i, i + lit.len()) == lit
  }
}

// TRUSTED: exec string prefix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_prefix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_prefix(s@, lit@),
{
    s.starts_with(lit)
}

// TRUSTED: exec string suffix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_suffix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_suffix(s@, lit@),
{
    s.ends_with(lit)
}

// TRUSTED: exec string contains check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_contains_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_contains(s@, lit@),
{
    s.contains(lit)
}

// === ILIKE + underscore LIKE (C-tier: ASCII / DuckDB-like exec path) ===
pub open spec fn ascii_lower_char(c: char) -> char {
    if 'A' <= c && c <= 'Z' {
        ((c as int) - ('A' as int) + ('a' as int)) as char
    } else {
        c
    }
}

pub open spec fn str_ascii_lower(s: Seq<char>) -> Seq<char> {
    str_ascii_lower_helper(s, 0)
}

pub open spec fn str_ascii_lower_helper(s: Seq<char>, i: int) -> Seq<char>
    decreases s.len() - i,
{
    if i >= s.len() {
        Seq::empty()
    } else {
        str_ascii_lower_helper(s, i + 1).insert(0, ascii_lower_char(s[i]))
    }
}

pub open spec fn str_like_underscore_match(s: Seq<char>, pat: Seq<char>) -> bool {
    str_like_underscore_match_rec(s, pat, 0, 0)
}

pub open spec fn str_like_underscore_match_rec(
    s: Seq<char>,
    pat: Seq<char>,
    si: int,
    pi: int,
) -> bool
    decreases pat.len() - pi,
{
    if pi >= pat.len() {
        si >= s.len()
    } else if pat[pi] == '%' {
        exists|k: int|
            si <= k
            && k <= s.len()
            && #[trigger] str_like_underscore_match_rec(s, pat, k, pi + 1)
    } else if pat[pi] == '_' {
        si < s.len() && str_like_underscore_match_rec(s, pat, si + 1, pi + 1)
    } else if si >= s.len() || s[si] != pat[pi] {
        false
    } else {
        str_like_underscore_match_rec(s, pat, si + 1, pi + 1)
    }
}

// C-tier: ASCII ILIKE (matches exec to_ascii_lowercase + underscore match).
pub open spec fn str_ilike_match(s: Seq<char>, pat: Seq<char>) -> bool {
    str_like_underscore_match(str_ascii_lower(s), str_ascii_lower(pat))
}

// TRUSTED: exec ILIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_ilike_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_ilike_match(s@, pat@),
{
    str_like_underscore_match_exec(&s.to_ascii_lowercase(), &pat.to_ascii_lowercase())
}

// TRUSTED: exec underscore LIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_underscore_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_like_underscore_match(s@, pat@),
{
    fn m(s: &[char], si: usize, p: &[char], pi: usize) -> bool {
        if pi >= p.len() {
            return si >= s.len();
        }
        if p[pi] == '%' {
            let mut k = si;
            while k <= s.len() {
                if m(s, k, p, pi + 1) {
                    return true;
                }
                k += 1;
            }
            return false;
        }
        if p[pi] == '_' {
            if si >= s.len() {
                return false;
            }
            return m(s, si + 1, p, pi + 1);
        }
        if si >= s.len() || s[si] != p[pi] {
            return false;
        }
        m(s, si + 1, p, pi + 1)
    }
    let sc: Vec<char> = s.chars().collect();
    let pc: Vec<char> = pat.chars().collect();
    m(&sc, 0, &pc, 0)
}

// === Scalar helpers (abs / case) ===
// abs on u64 cell: identity (non-negative type; SQL ABS on unsigned is a no-op).
pub open spec fn abs_u64(x: u64) -> u64 {
    x
}

#[verifier::external_body]
pub exec fn abs_u64_exec(x: u64) -> (res: u64)
    ensures res == abs_u64(x),
{
    x
}

// C-tier/ASCII dialect pin (same as ILIKE): lower/upper via per-char ASCII fold.
pub open spec fn ascii_upper_char(c: char) -> char {
    if 'a' <= c && c <= 'z' {
        ((c as int) - ('a' as int) + ('A' as int)) as char
    } else {
        c
    }
}

pub open spec fn str_ascii_upper(s: Seq<char>) -> Seq<char> {
    str_ascii_upper_helper(s, 0)
}

pub open spec fn str_ascii_upper_helper(s: Seq<char>, i: int) -> Seq<char>
    decreases s.len() - i,
{
    if i >= s.len() {
        Seq::empty()
    } else {
        str_ascii_upper_helper(s, i + 1).insert(0, ascii_upper_char(s[i]))
    }
}

pub open spec fn str_lower(s: Seq<char>) -> Seq<char> {
    str_ascii_lower(s)
}

pub open spec fn str_upper(s: Seq<char>) -> Seq<char> {
    str_ascii_upper(s)
}

#[verifier::external_body]
pub exec fn str_lower_exec(s: &str) -> (res: String)
    ensures res@ == str_lower(s@),
{
    s.to_ascii_lowercase()
}

#[verifier::external_body]
pub exec fn str_upper_exec(s: &str) -> (res: String)
    ensures res@ == str_upper(s@),
{
    s.to_ascii_uppercase()
}

// === Seq helpers (projection + LIMIT) ===
pub open spec fn spec_seq_take<A>(s: Seq<A>, n: int) -> Seq<A> {
    if n <= 0 {
        Seq::empty()
    } else if n >= s.len() {
        s
    } else {
        s.subrange(0, n)
    }
}

pub open spec fn spec_seq_concat<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_concat_helper(a, b, 0)
}

pub open spec fn spec_seq_concat_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        spec_seq_concat_helper(a.push(b[i]), b, i + 1)
    } else {
        a
    }
}

pub open spec fn spec_seq_union_distinct<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_union_distinct_helper(a, b, 0)
}

pub open spec fn spec_seq_union_distinct_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        let tail = spec_seq_union_distinct_helper(a, b, i + 1);
        if tail.contains(b[i]) {
            tail
        } else {
            tail.push(b[i])
        }
    } else {
        a
    }
}

pub open spec fn seq_sum_u64(s: Seq<u64>) -> u64 {
    seq_sum_u64_helper(s, 0)
}

pub open spec fn seq_sum_u64_helper(s: Seq<u64>, i: int) -> u64
    decreases s.len() - i,
{
    if i < s.len() {
        (seq_sum_u64_helper(s, i + 1) as int + s[i] as int) as u64
    } else {
        0
    }
}

// === IS NULL / anti-join (Lemma non-null loads; LEFT JOIN miss) ===
// Lemma non-null columnar loads compile base-table IS NULL without this helper.
// Multi-table LEFT JOIN miss is join-specific in MethodSpec; this schema-agnostic
// placeholder is always false (no unconstrained miss axiom on single-table emit).
pub open spec fn left_join_miss_generic(cols: &Cols, row: int) -> bool {
    false
}

// TRUSTED: multi-agg HashMap exec view bridge.
#[verifier::external_body]
pub open spec fn hashmap_multi_agg_view<K, V>(m: Map<K, V>) -> Map<K, V> {
    m
}


pub struct Cols {
    pub n: usize,
    pub adsh: Vec<String>,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub ddate: Vec<u32>,
    pub uom: Vec<String>,
    pub value: Vec<u64>,
}

impl Cols {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_ddate(self, i: int) -> u32 {
        self.ddate[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_ddate_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_ddate(i as int),
    {
        self.ddate[i]
    }
    pub open spec fn get_uom(self, i: int) -> Seq<char> {
        self.uom[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_uom_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_uom(i as int),
    {
        self.uom[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_uom(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_uom(i as int) == lit@),
    {
        self.uom[i] == lit
    }
    pub open spec fn get_value(self, i: int) -> u64 {
        self.value[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_value_exec(&self, i: usize) -> (res: u64)
        requires i < self.n,
        ensures res == self.get_value(i as int),
    {
        self.value[i]
    }
    #[verifier::external_body]
    pub exec fn agg_push_str_tag_version(
        &self,
        agg: &mut HashMapWithView<(String, String), u64>,
        i: usize,
        delta: u64,
    )
        requires
            i < self.n &&
        delta < LEMMA_MAX_CELL_U64 &&
        (if old(agg)@.contains_key((self.get_tag(i as int), self.get_version(i as int))) { old(agg)@[(self.get_tag(i as int), self.get_version(i as int))] } else { 0u64 } as int) + ((delta as int) as int) <= u64::MAX as int,
        ensures
            final(agg)@ == old(agg)@.insert(
        (self.get_tag(i as int), self.get_version(i as int)),
        if old(agg)@.contains_key((self.get_tag(i as int), self.get_version(i as int))) {
            (old(agg)@[(self.get_tag(i as int), self.get_version(i as int))] as int + delta as int) as u64
        } else {
            delta
        },
    ),
    {
        let key = (self.get_tag_exec(i), self.get_version_exec(i));
        let prev = agg.get(&key).copied().unwrap_or(0u64);
        let next = prev.checked_add(delta).expect("Trusted overflow: requires violated");
        agg.insert(key, next);
    }
}


pub open spec fn valid_cols(cols: &Cols) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.ddate.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.ddate[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.uom@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.uom[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.value.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.value[i] < LEMMA_MAX_CELL_U64
}

pub proof fn valid_cols_get_adsh(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.adsh[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_tag(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.tag[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_version(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.version[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_ddate(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures cols.ddate[i as int] < LEMMA_MAX_NATIVE_U32,
{
}

pub proof fn valid_cols_get_uom(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.uom[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_value(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures cols.value[i as int] < LEMMA_MAX_CELL_U64,
{
}

pub open spec fn method_spec_helper(cols: &Cols, k: int) -> Map<(Seq<char>, Seq<char>), (u64, u64)>
    recommends
        0 <= k && k <= cols.n,
        valid_cols(cols),
    decreases cols.n - k,
{
    if k < cols.n {
        let tail = method_spec_helper(cols, k + 1);
        if (((cols.get_uom(k) == "shares"@ && (cols.get_ddate(k) >= 20240101 && cols.get_ddate(k) <= 20241231)) && true) && !exists_corr_exists_1_spec(cols, (cols.get_adsh(k), cols.get_tag(k), cols.get_version(k)))) {
            let key = (cols.tag[k as int]@, cols.version[k as int]@);
            let prev = if tail.contains_key(key) { tail[key] } else { (0u64, 0u64) };
            let s0 = (prev.0 as int + 1) as u64;
            let s1 = (prev.1 as int + ((cols.get_value(k) as int)) as u64 as int) as u64;
            tail.insert(key, (s0, s1))
        } else {
            tail
        }
    } else {
        Map::empty()
    }
}

pub open spec fn apply_having_filter<K, V>(m: Map<K, V>, pred: spec_fn(K, V) -> bool) -> Map<K, V> {
    m.filter_keys(|k| pred(k, m[k]))
}

pub open spec fn exists_corr_exists_1_helper(cols: &Cols, outer_key: (Seq<char>, Seq<char>, Seq<char>), k: int) -> bool
    recommends valid_cols(cols),
    decreases cols.n - k,
{
    if k < cols.n {
        if ((cols.get_tag(k) == outer_key.1 && cols.get_version(k) == outer_key.2) && cols.get_adsh(k) == outer_key.0) {
            true
        } else {
            exists_corr_exists_1_helper(cols, outer_key, k + 1)
        }
    } else {
        false
    }
}

pub open spec fn exists_corr_exists_1_spec(cols: &Cols, outer_key: (Seq<char>, Seq<char>, Seq<char>)) -> bool
    recommends valid_cols(cols),
{
    exists_corr_exists_1_helper(cols, outer_key, 0)
}

pub open spec fn method_spec(cols: &Cols) -> Map<(Seq<char>, Seq<char>), (u64, u64)>
    recommends valid_cols(cols),
{
    {
    let m = {
        let raw = method_spec_helper(cols, 0);
    raw.map_values(|v: (u64, u64)| (v.0, v.1))
    };
    apply_having_filter(m, |k: (Seq<char>, Seq<char>), v: (u64, u64)| (v.0 > 10))
}
}

// Note: ORDER BY (cnt DESC), LIMIT 200, OFFSET 0 are not part of method_spec (((Seq<char>, Seq<char>), (u64, u64))); agent may apply in run_query.
// === Agent: use TRUSTED helpers below (vstd map/set @ views).
// Maps: agg_new_* / agg_add_* / agg_put_*; ensures res@ == method_spec.
// Multi-agg steps: agg_step_state_new_* / agg_step_* (+ agg_step_apply_row_* spec).
// HAVING: host post-filter exec helper (ensures vs apply_having_filter).
// Distinct sets: hashset_*_as_map + set_new_* / set_insert_* (COUNT_DISTINCT state).
// Seqs: seq_new_* / seq_push_* when present; else Vec@ directly.
use vstd::hash_map::{HashMapWithView, StringHashMap};
use vstd::hash_set::HashSetWithView;

// === TRUSTED structural map helpers (vstd view @ + agg_new + agg_put/agg_add) ===
#[verifier::external_body]
pub exec fn agg_new_str_str__u64_u64() -> (hm: HashMapWithView<(String, String), (u64, u64)>)
    ensures hm@ == Map::empty(),
{
    HashMapWithView::new()
}

#[verifier::external_body]
pub exec fn agg_put_str_str__u64_u64(hm: &mut HashMapWithView<(String, String), (u64, u64)>, k0: &str, k1: &str, v0: u64, v1: u64)
    ensures final(hm)@ == old(hm)@.insert((k0@, k1@), (v0, v1)),
{
    let key = (k0.to_string(), k1.to_string());
    hm.insert(key, (v0, v1));
}

#[verifier::external_body]
pub exec fn agg_add_str_str__u64_u64(hm: &mut HashMapWithView<(String, String), (u64, u64)>, k0: &str, k1: &str, d0: u64, d1: u64)
    requires
        d0 < LEMMA_MAX_CELL_U64 &&
        (if old(hm)@.contains_key((k0@, k1@)) { old(hm)@[(k0@, k1@)].0 } else { 0u64 } as int) + ((d0 as int)) <= u64::MAX as int &&
        d1 < LEMMA_MAX_CELL_U64 &&
        (if old(hm)@.contains_key((k0@, k1@)) { old(hm)@[(k0@, k1@)].1 } else { 0u64 } as int) + ((d1 as int)) <= u64::MAX as int,
    ensures
        final(hm)@ == old(hm)@.insert(
        (k0@, k1@),
        (if old(hm)@.contains_key((k0@, k1@)) {
            (old(hm)@[(k0@, k1@)].0 as int + d0 as int) as u64
        } else {
            d0
        }, if old(hm)@.contains_key((k0@, k1@)) {
            (old(hm)@[(k0@, k1@)].1 as int + d1 as int) as u64
        } else {
            d1
        }),
    ),
{
    let key = (k0.to_string(), k1.to_string());
    let prev = hm.get(&key).copied().unwrap_or((0u64, 0u64));
    hm.insert(key, (prev.0.checked_add(d0).expect("Trusted overflow: ValidCols/requires violated"), prev.1.checked_add(d1).expect("Trusted overflow: ValidCols/requires violated")));
}

// === TRUSTED distinct-set helpers (str: HashSetWithView exec ↔ Map spec) ===
pub open spec fn hashset_str_as_map(s: Set<Seq<char>>) -> Map<Seq<char>, bool> {
    Map::new(s, |k| true)
}

#[verifier::external_body]
pub exec fn set_new_str() -> (s: HashSetWithView<String>)
    ensures hashset_str_as_map(s@) == Map::empty(),
{
    HashSetWithView::new()
}

#[verifier::external_body]
pub exec fn set_insert_str(s: &mut HashSetWithView<String>, k: &str) -> (is_new: bool)
    ensures
        hashset_str_as_map(final(s)@).contains_key(k@),
        hashset_str_as_map(final(s)@) == hashset_str_as_map(old(s)@).insert(k@, true),
        is_new == !hashset_str_as_map(old(s)@).contains_key(k@),
        is_new ==> hashset_str_as_map(final(s)@).dom().len() == hashset_str_as_map(old(s)@).dom().len() + 1,
        !is_new ==> hashset_str_as_map(final(s)@).dom().len() == hashset_str_as_map(old(s)@).dom().len(),
{
    let is_new = !s.contains(&k.to_string());
    s.insert(k.to_string());
    is_new
}

// === TRUSTED distinct-set helpers (u32: HashSetWithView exec ↔ Map spec) ===
pub open spec fn hashset_u32_as_map(s: Set<u32>) -> Map<u32, bool> {
    Map::new(s, |k| true)
}

#[verifier::external_body]
pub exec fn set_new_u32() -> (s: HashSetWithView<u32>)
    ensures hashset_u32_as_map(s@) == Map::empty(),
{
    HashSetWithView::new()
}

#[verifier::external_body]
pub exec fn set_insert_u32(s: &mut HashSetWithView<u32>, k: u32) -> (is_new: bool)
    ensures
        hashset_u32_as_map(final(s)@).contains_key(k),
        hashset_u32_as_map(final(s)@) == hashset_u32_as_map(old(s)@).insert(k, true),
        is_new == !hashset_u32_as_map(old(s)@).contains_key(k),
        is_new ==> hashset_u32_as_map(final(s)@).dom().len() == hashset_u32_as_map(old(s)@).dom().len() + 1,
        !is_new ==> hashset_u32_as_map(final(s)@).dom().len() == hashset_u32_as_map(old(s)@).dom().len(),
{
    let is_new = !s.contains(&k);
    s.insert(k);
    is_new
}

// === Multi-agg group step (str_str__u64_u64): inner + projected vstd maps (@ view) ===
pub struct AggStepState_str_str__u64_u64 {
    pub projected: HashMapWithView<(String, String), (u64, u64)>,
    pub inner: HashMapWithView<(String, String), (u64, u64)>,
}

pub open spec fn agg_step_inner_str_str__u64_u64_spec(
    m: Map<(Seq<char>, Seq<char>), (u64, u64)>,
) -> Map<(Seq<char>, Seq<char>), (u64, u64)> {
    m.map_values(|v: (u64, u64)| (v.0, v.1))
}

pub open spec fn agg_step_project_str_str__u64_u64(v: (u64, u64)) -> (u64, u64) {
    (v.0, v.1)
}

pub open spec fn agg_step_apply_row_str_str__u64_u64(prev: (u64, u64), row_u64_0: u64) -> (u64, u64) {
    let s0 = (prev.0 as int + 1) as u64;
    let s1 = (prev.1 as int + (((row_u64_0 as int) as int)) as u64 as int) as u64;
    (s0, s1)
}

#[verifier::external_body]
pub exec fn agg_step_state_new_str_str__u64_u64() -> (st: AggStepState_str_str__u64_u64)
    ensures
        st.projected@ == Map::empty(),
        st.inner@ == Map::empty(),
{
    AggStepState_str_str__u64_u64 { projected: HashMapWithView::new(), inner: HashMapWithView::new() }
}

#[verifier::external_body]
pub exec fn agg_step_str_str__u64_u64(
    st: &mut AggStepState_str_str__u64_u64,
    k0: &str, k1: &str, row_u64_0: u64,
)
    requires
        ((if old(st).inner@.contains_key((k0@, k1@)) { old(st).inner@[(k0@, k1@)].0 } else { 0u64 }) as int) + 1 <= u64::MAX as int &&
        row_u64_0 < LEMMA_MAX_CELL_U64 &&
        ((if old(st).inner@.contains_key((k0@, k1@)) { old(st).inner@[(k0@, k1@)].1 } else { 0u64 }) as int) + (row_u64_0 as int) <= u64::MAX as int,
    ensures
        ({
            let spec_key = (k0@, k1@);
            let old_inner = agg_step_inner_str_str__u64_u64_spec(old(st).inner@);
            let prev_inner = if old_inner.contains_key(spec_key) {
                old_inner[spec_key]
            } else {
                (0u64, 0u64)
            };
            let new_inner = agg_step_apply_row_str_str__u64_u64(prev_inner, row_u64_0);
            &&& agg_step_inner_str_str__u64_u64_spec(final(st).inner@) == old_inner.insert(spec_key, new_inner)
            &&& final(st).projected@ == old(st).projected@.insert(
                spec_key,
                agg_step_project_str_str__u64_u64(new_inner),
            )
        }),
{
    let key = (k0.to_string(), k1.to_string());
    let mut prev = st.inner.remove(&key).unwrap_or((0u64, 0u64));
    let v0 = prev.0.checked_add(1).expect("Trusted overflow: ValidCols/requires violated");
    let v1 = prev.1.checked_add(row_u64_0).expect("Trusted overflow: ValidCols/requires violated");
    let new_inner = (v0, v1);
    let projected_val = (new_inner.0, new_inner.1);
    st.inner.insert(key.clone(), new_inner);
    st.projected.insert(key, projected_val);
}

// === Multi-agg fold bound assumptions (str_str__u64_u64) ===
// ASSUMPTION (catalog/user): under `valid_cols` + this open-spec fold, partial agg ≤ rem·cap.
// Not a Verus-proved induction — expert accepts under table/catalog assumptions.
// COUNT slot 0: ≤((cols.n - k)) as u64 filtered rows add ≤1 each.
#[verifier::external_body]
pub proof fn assume_method_spec_helper_slot0_count_leq_str_str__u64_u64(
    cols: &Cols,
    k: int,
    key: (Seq<char>, Seq<char>),
)
    requires
        valid_cols(cols),
        0 <= cols.n as int,
        0 <= k <= cols.n as int,
    ensures
        (if method_spec_helper(cols, k).contains_key(key) { method_spec_helper(cols, k)[key].0 } else { 0u64 }) <= ((cols.n - k)) as u64,
{
}

// ASSUMPTION (catalog/user): under `valid_cols` + this open-spec fold, partial agg ≤ rem·cap.
// Not a Verus-proved induction — expert accepts under table/catalog assumptions.
// SUM(native) slot 1: ≤((cols.n - k)) as u64 cells each < LEMMA_MAX_NATIVE_U32.
#[verifier::external_body]
pub proof fn assume_method_spec_helper_slot1_sum_native_leq_str_str__u64_u64(
    cols: &Cols,
    k: int,
    key: (Seq<char>, Seq<char>),
)
    requires
        valid_cols(cols),
        0 <= cols.n as int,
        0 <= k <= cols.n as int,
    ensures
        (if method_spec_helper(cols, k).contains_key(key) { method_spec_helper(cols, k)[key].1 } else { 0u64 }) <= ((cols.n - k)) as u64 * (LEMMA_MAX_NATIVE_U32 as u64),
{
}
// === HAVING map peel: vstd HashMapWithView / StringHashMap are single-field newtypes ===
// over std::collections::HashMap (same layout fact vstd uses). Transmute stays inside
// these helpers only. Semantic HAVING ensures live on apply_having_filter_exec_* (res@).
#[repr(C)]
struct HashMapWithViewPeel<K, V> {
    m: std::collections::HashMap<K, V>,
}

#[repr(C)]
struct StringHashMapPeel<V> {
    m: std::collections::HashMap<String, V>,
}

#[verifier::external_body]
pub exec fn hashmap_with_view_unwrap<K, V>(
    hm: HashMapWithView<K, V>,
) -> (m: std::collections::HashMap<K, V>)
    where
        K: vstd::view::View + std::cmp::Eq + std::hash::Hash,
    ensures
        true,
{
    let peeled: HashMapWithViewPeel<K, V> = unsafe { std::mem::transmute(hm) };
    peeled.m
}

#[verifier::external_body]
pub exec fn hashmap_with_view_wrap<K, V>(
    m: std::collections::HashMap<K, V>,
) -> (hm: HashMapWithView<K, V>)
    where
        K: vstd::view::View + std::cmp::Eq + std::hash::Hash,
    ensures
        true,
{
    let peeled = HashMapWithViewPeel { m };
    unsafe { std::mem::transmute(peeled) }
}

// === HAVING post-filter (str_str__u64_u64): exec map retain vs apply_having_filter ===
#[verifier::external_body]
pub exec fn apply_having_filter_exec_str_str__u64_u64(
    hm: HashMapWithView<(String, String), (u64, u64)>,
) -> (res: HashMapWithView<(String, String), (u64, u64)>)
    ensures
        res@
            == apply_having_filter(
                hm@,
                |k: (Seq<char>, Seq<char>), v: (u64, u64)| (v.0 > 10),
            ),
{
    {
    let std_hm = hashmap_with_view_unwrap(hm);
    let std_res: std::collections::HashMap<(String, String), (u64, u64)> = std_hm
        .into_iter()
        .filter(|(_k, v)| (v.0 > 10))
        .collect();
    hashmap_with_view_wrap(std_res)
}
}
} // verus!
