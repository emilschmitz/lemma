use vstd::prelude::*;
use std::collections::{HashMap, HashSet};

verus! {

// === Lemma global input bounds ===
pub const LEMMA_MAX_ROWS: usize = 65536;
pub const LEMMA_MAX_ROWS_CUBE: usize = 2047;
pub const LEMMA_MAX_ROWS_4: usize = 256;
pub const LEMMA_MAX_NATIVE_U32: u32 = 2147483648;
pub const LEMMA_MAX_STRING_LEN: usize = 128;
// Assumption-driven u64 cell cap (NOT implied by BIGINT type width).
pub const LEMMA_MAX_CELL_U64: u64 = 2147483648;
pub const LEMMA_MAX_MONEY_U64: u64 = LEMMA_MAX_CELL_U64;


// === Lemma global product bounds (host arithmetic) ===
#[verifier::external_body]
pub proof fn lemma_max_rows_times_native_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_sq_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_sq_times_native_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_NATIVE_U32 as int)
            <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS², then (rem_cap+1)·MONEY fits in u64 (uses join product bound).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS², then (rem_cap+1)·NATIVE_U32 fits (2-table join rem for SUM(native)).
#[verifier::external_body]
pub proof fn lemma_rem_cap_native_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

// ASSUMPTION (catalog/user): nested-loop rem ≤ ROWS² under valid_cols row caps.
// Not Verus-proved from fold induction — expert accepts under table assumptions.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_sq(
    n0: usize,
    n1: usize,
    i0: int,
    i1: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
    ensures
        ((n1 as int - i1) + (n0 as int - i0 - 1) * (n1 as int)) >= 0,
        (((n1 - i1) + (n0 - i0 - 1) * n1) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_cube_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_ROWS_CUBE as int)
            * (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_4_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

// rem_cap ≤ CUBE³ ⇒ (rem_cap+1)·MONEY fits (3-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS_4⁴ ⇒ (rem_cap+1)·MONEY fits (4-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS² ⇒ rem_cap+1 fits in u64 (COUNT / prev_le discharge).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS ⇒ rem_cap+1 fits (single-table suffix rem).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_rows(prev_cap: u64)
    requires
        prev_cap <= LEMMA_MAX_ROWS as u64,
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS³ ⇒ rem_cap+1 fits (3-table suffix rem with ROWS caps).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_pow3(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS⁴ ⇒ rem_cap+1 fits (4-table suffix rem with ROWS caps).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ CUBE³ ⇒ rem_cap+1 fits (3-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS_4⁴ ⇒ rem_cap+1 fits (4-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// ASSUMPTION (catalog/user): 3-table nested rem ≤ CUBE³ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_cube(
    n0: usize,
    n1: usize,
    n2: usize,
    i0: int,
    i1: int,
    i2: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS_CUBE,
        n1 <= LEMMA_MAX_ROWS_CUBE,
        n2 <= LEMMA_MAX_ROWS_CUBE,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
    ensures
        ((n2 as int - i2)
            + (n1 as int - i1 - 1) * (n2 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int)) >= 0,
        (((n2 - i2) + (n1 - i1 - 1) * n2 + (n0 - i0 - 1) * n1 * n2) as u64)
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
{
}

// ASSUMPTION (catalog/user): 4-table nested rem ≤ ROWS_4⁴ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_4(
    n0: usize,
    n1: usize,
    n2: usize,
    n3: usize,
    i0: int,
    i1: int,
    i2: int,
    i3: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS_4,
        n1 <= LEMMA_MAX_ROWS_4,
        n2 <= LEMMA_MAX_ROWS_4,
        n3 <= LEMMA_MAX_ROWS_4,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
        0 <= i3 <= n3 as int,
    ensures
        ((n3 as int - i3)
            + (n2 as int - i2 - 1) * (n3 as int)
            + (n1 as int - i1 - 1) * (n2 as int) * (n3 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int) * (n3 as int)) >= 0,
        (((n3 - i3) + (n2 - i2 - 1) * n3 + (n1 - i1 - 1) * n2 * n3
            + (n0 - i0 - 1) * n1 * n2 * n3) as u64)
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
{
}

// ASSUMPTION (catalog/user): 3-table suffix rem ≤ ROWS³ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_fold_suffix_rem_leq_rows_pow3(
    n0: usize,
    n1: usize,
    n2: usize,
    i0: int,
    i1: int,
    i2: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        n2 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
    ensures
        (((n2 as int - i2) + (n1 as int - i1 - 1) * (n2 as int) + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int)) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

// ASSUMPTION (catalog/user): 4-table suffix rem ≤ ROWS⁴ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_fold_suffix_rem_leq_rows_pow4(
    n0: usize,
    n1: usize,
    n2: usize,
    n3: usize,
    i0: int,
    i1: int,
    i2: int,
    i3: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        n2 <= LEMMA_MAX_ROWS,
        n3 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
        0 <= i3 <= n3 as int,
    ensures
        (((n3 as int - i3) + (n2 as int - i2 - 1) * (n3 as int) + (n1 as int - i1 - 1) * (n2 as int) * (n3 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int) * (n3 as int)) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_native_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

// === Discharge add_u64 / agg_add_* / agg_step_* checked_add requires ===
// COUNT / AVG-denom: prev <= n rows processed so far.
pub proof fn lemma_u64_add_one_fit(prev: u64, n: usize)
    requires
        prev <= n as u64,
        n <= LEMMA_MAX_ROWS,
    ensures
        (prev as int) + 1 <= u64::MAX as int,
{
}

// SUM(native u32 cell): prev <= n * cell_cap, cell < cell_cap, n <= LEMMA_MAX_ROWS.
#[verifier::external_body]
pub proof fn lemma_u64_add_native_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_NATIVE_U32 as u64),
        cell < LEMMA_MAX_NATIVE_U32 as u64,
        n <= LEMMA_MAX_ROWS,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// SUM(money u64 cell): requires global product bound (honest gate when constants allow).
#[verifier::external_body]
pub proof fn lemma_u64_add_cell_u64_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_CELL_U64 as u64),
        cell < LEMMA_MAX_CELL_U64,
        n <= LEMMA_MAX_ROWS,
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// COUNT with an explicit row-suffix / join-rem cap (elementary: prev ≤ cap ⇒ prev+1 fits).
#[verifier::external_body]
pub proof fn lemma_u64_add_one_prev_le(prev: u64, prev_cap: u64)
    requires
        prev <= prev_cap,
        (prev_cap as int) + 1 <= u64::MAX as int,
    ensures
        (prev as int) + 1 <= u64::MAX as int,
{
}

// SUM(money) with explicit rem-cap: prev ≤ cap·M, cell < M, (cap+1)·M fits ⇒ prev+cell fits.
// Same *kind* of fact as bounded int add (checkable from constants when cap ≤ ROWS²).
#[verifier::external_body]
pub proof fn lemma_u64_add_cell_u64_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_CELL_U64 as u64),
        cell < LEMMA_MAX_CELL_U64,
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// Native SUM with rem-cap (same shape as money).
#[verifier::external_body]
pub proof fn lemma_u64_add_native_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_NATIVE_U32 as u64),
        cell < LEMMA_MAX_NATIVE_U32 as u64,
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}


// === Deprecated aliases (money → cell_u64); prefer cell_u64 names ===
pub proof fn lemma_max_rows_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
    lemma_max_rows_times_cell_u64_fits_u64();
}

pub proof fn lemma_max_rows_sq_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
    lemma_max_rows_sq_times_cell_u64_fits_u64();
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_u64_add_money_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_MONEY_U64 as u64),
        cell < LEMMA_MAX_MONEY_U64,
        n <= LEMMA_MAX_ROWS,
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_u64_add_money_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_MONEY_U64 as u64),
        cell < LEMMA_MAX_MONEY_U64,
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_cube_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_ROWS_CUBE as int)
            * (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_4_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
}


// === Trusted arithmetic helpers ===
// TRUSTED: if (a as int) + (b as int) <= u64::MAX then add is mathematical +.
#[verifier::external_body]
pub exec fn add_u64(a: u64, b: u64) -> (res: u64)
    requires
        (a as int) + (b as int) <= u64::MAX as int,
    ensures
        res == a + b,
{
    a.checked_add(b).expect("Trusted overflow: ValidCols/requires violated")
}

// TRUSTED: if (a as int) * (b as int) <= u64::MAX then mul is mathematical *.
#[verifier::external_body]
pub exec fn mul_u64_u32(a: u64, b: u32) -> (res: u64)
    requires
        (a as int) * (b as int) <= u64::MAX as int,
    ensures
        res == a * (b as u64),
{
    a.checked_mul(b as u64).expect("Trusted overflow: ValidCols/requires violated")
}

// TRUSTED: if (a as int) - (b as int) fits in i64 then sub is mathematical -.
#[verifier::external_body]
pub exec fn sub_u64_to_i64(a: u64, b: u64) -> (res: i64)
    requires
        (a as int) - (b as int) >= i64::MIN as int,
        (a as int) - (b as int) <= i64::MAX as int,
    ensures
        res == (a as int) - (b as int),
{
    (a as i64) - (b as i64)
}

// TRUSTED: if (a as int) + (b as int) fits in i64 then add is mathematical +.
#[verifier::external_body]
pub exec fn add_i64(a: i64, b: i64) -> (res: i64)
    requires
        (a as int) + (b as int) >= i64::MIN as int,
        (a as int) + (b as int) <= i64::MAX as int,
    ensures
        res == a + b,
{
    a.checked_add(b).expect("Trusted overflow: ValidCols/requires violated")
}

// === CASE WHEN (simple int branches) ===
pub open spec fn case_when_u64(cond: bool, then_v: u64, else_v: u64) -> u64 {
    if cond { then_v } else { else_v }
}

#[verifier::external_body]
pub exec fn case_when_u64_exec(cond: bool, then_v: u64, else_v: u64) -> (res: u64)
    ensures res == case_when_u64(cond, then_v, else_v),
{
    if cond { then_v } else { else_v }
}

// === String LIKE helpers (basic % prefix/suffix/contains) ===
pub open spec fn str_like_prefix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_prefix_of(s)
}

pub open spec fn str_like_suffix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_suffix_of(s)
}

// Substring containment (open spec; empty lit matches any s).
pub open spec fn str_like_contains(s: Seq<char>, lit: Seq<char>) -> bool {
  if lit.len() == 0 {
    true
  } else {
    exists|i: int|
      0 <= i
      && i + lit.len() <= s.len()
      && #[trigger] s.subrange(i, i + lit.len()) == lit
  }
}

// TRUSTED: exec string prefix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_prefix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_prefix(s@, lit@),
{
    s.starts_with(lit)
}

// TRUSTED: exec string suffix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_suffix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_suffix(s@, lit@),
{
    s.ends_with(lit)
}

// TRUSTED: exec string contains check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_contains_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_contains(s@, lit@),
{
    s.contains(lit)
}

// === ILIKE + underscore LIKE (C-tier: ASCII / DuckDB-like exec path) ===
pub open spec fn ascii_lower_char(c: char) -> char {
    if 'A' <= c && c <= 'Z' {
        ((c as int) - ('A' as int) + ('a' as int)) as char
    } else {
        c
    }
}

pub open spec fn str_ascii_lower(s: Seq<char>) -> Seq<char> {
    str_ascii_lower_helper(s, 0)
}

pub open spec fn str_ascii_lower_helper(s: Seq<char>, i: int) -> Seq<char>
    decreases s.len() - i,
{
    if i >= s.len() {
        Seq::empty()
    } else {
        str_ascii_lower_helper(s, i + 1).insert(0, ascii_lower_char(s[i]))
    }
}

pub open spec fn str_like_underscore_match(s: Seq<char>, pat: Seq<char>) -> bool {
    str_like_underscore_match_rec(s, pat, 0, 0)
}

pub open spec fn str_like_underscore_match_rec(
    s: Seq<char>,
    pat: Seq<char>,
    si: int,
    pi: int,
) -> bool
    decreases pat.len() - pi,
{
    if pi >= pat.len() {
        si >= s.len()
    } else if pat[pi] == '%' {
        exists|k: int|
            si <= k
            && k <= s.len()
            && #[trigger] str_like_underscore_match_rec(s, pat, k, pi + 1)
    } else if pat[pi] == '_' {
        si < s.len() && str_like_underscore_match_rec(s, pat, si + 1, pi + 1)
    } else if si >= s.len() || s[si] != pat[pi] {
        false
    } else {
        str_like_underscore_match_rec(s, pat, si + 1, pi + 1)
    }
}

// C-tier: ASCII ILIKE (matches exec to_ascii_lowercase + underscore match).
pub open spec fn str_ilike_match(s: Seq<char>, pat: Seq<char>) -> bool {
    str_like_underscore_match(str_ascii_lower(s), str_ascii_lower(pat))
}

// TRUSTED: exec ILIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_ilike_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_ilike_match(s@, pat@),
{
    str_like_underscore_match_exec(&s.to_ascii_lowercase(), &pat.to_ascii_lowercase())
}

// TRUSTED: exec underscore LIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_underscore_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_like_underscore_match(s@, pat@),
{
    fn m(s: &[char], si: usize, p: &[char], pi: usize) -> bool {
        if pi >= p.len() {
            return si >= s.len();
        }
        if p[pi] == '%' {
            let mut k = si;
            while k <= s.len() {
                if m(s, k, p, pi + 1) {
                    return true;
                }
                k += 1;
            }
            return false;
        }
        if p[pi] == '_' {
            if si >= s.len() {
                return false;
            }
            return m(s, si + 1, p, pi + 1);
        }
        if si >= s.len() || s[si] != p[pi] {
            return false;
        }
        m(s, si + 1, p, pi + 1)
    }
    let sc: Vec<char> = s.chars().collect();
    let pc: Vec<char> = pat.chars().collect();
    m(&sc, 0, &pc, 0)
}

// === Scalar helpers (abs / case) ===
// abs on u64 cell: identity (non-negative type; SQL ABS on unsigned is a no-op).
pub open spec fn abs_u64(x: u64) -> u64 {
    x
}

#[verifier::external_body]
pub exec fn abs_u64_exec(x: u64) -> (res: u64)
    ensures res == abs_u64(x),
{
    x
}

// C-tier/ASCII dialect pin (same as ILIKE): lower/upper via per-char ASCII fold.
pub open spec fn ascii_upper_char(c: char) -> char {
    if 'a' <= c && c <= 'z' {
        ((c as int) - ('a' as int) + ('A' as int)) as char
    } else {
        c
    }
}

pub open spec fn str_ascii_upper(s: Seq<char>) -> Seq<char> {
    str_ascii_upper_helper(s, 0)
}

pub open spec fn str_ascii_upper_helper(s: Seq<char>, i: int) -> Seq<char>
    decreases s.len() - i,
{
    if i >= s.len() {
        Seq::empty()
    } else {
        str_ascii_upper_helper(s, i + 1).insert(0, ascii_upper_char(s[i]))
    }
}

pub open spec fn str_lower(s: Seq<char>) -> Seq<char> {
    str_ascii_lower(s)
}

pub open spec fn str_upper(s: Seq<char>) -> Seq<char> {
    str_ascii_upper(s)
}

#[verifier::external_body]
pub exec fn str_lower_exec(s: &str) -> (res: String)
    ensures res@ == str_lower(s@),
{
    s.to_ascii_lowercase()
}

#[verifier::external_body]
pub exec fn str_upper_exec(s: &str) -> (res: String)
    ensures res@ == str_upper(s@),
{
    s.to_ascii_uppercase()
}

// === Seq helpers (projection + LIMIT) ===
pub open spec fn spec_seq_take<A>(s: Seq<A>, n: int) -> Seq<A> {
    if n <= 0 {
        Seq::empty()
    } else if n >= s.len() {
        s
    } else {
        s.subrange(0, n)
    }
}

pub open spec fn spec_seq_concat<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_concat_helper(a, b, 0)
}

pub open spec fn spec_seq_concat_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        spec_seq_concat_helper(a.push(b[i]), b, i + 1)
    } else {
        a
    }
}

pub open spec fn spec_seq_union_distinct<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_union_distinct_helper(a, b, 0)
}

pub open spec fn spec_seq_union_distinct_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        let tail = spec_seq_union_distinct_helper(a, b, i + 1);
        if tail.contains(b[i]) {
            tail
        } else {
            tail.push(b[i])
        }
    } else {
        a
    }
}

pub open spec fn seq_sum_u64(s: Seq<u64>) -> u64 {
    seq_sum_u64_helper(s, 0)
}

pub open spec fn seq_sum_u64_helper(s: Seq<u64>, i: int) -> u64
    decreases s.len() - i,
{
    if i < s.len() {
        (seq_sum_u64_helper(s, i + 1) as int + s[i] as int) as u64
    } else {
        0
    }
}

// TRUSTED: multi-agg HashMap exec view bridge.
#[verifier::external_body]
pub open spec fn hashmap_multi_agg_view<K, V>(m: Map<K, V>) -> Map<K, V> {
    m
}


pub struct Cols_num {
    pub n: usize,
    pub adsh: Vec<String>,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub ddate: Vec<u32>,
    pub qtrs: Vec<u32>,
    pub uom: Vec<String>,
    pub coreg: Vec<String>,
    pub value: Vec<u64>,
    pub footnote: Vec<String>,
}

impl Cols_num {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_ddate(self, i: int) -> u32 {
        self.ddate[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_ddate_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_ddate(i as int),
    {
        self.ddate[i]
    }
    pub open spec fn get_qtrs(self, i: int) -> u32 {
        self.qtrs[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_qtrs_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_qtrs(i as int),
    {
        self.qtrs[i]
    }
    pub open spec fn get_uom(self, i: int) -> Seq<char> {
        self.uom[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_uom_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_uom(i as int),
    {
        self.uom[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_uom(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_uom(i as int) == lit@),
    {
        self.uom[i] == lit
    }
    pub open spec fn get_coreg(self, i: int) -> Seq<char> {
        self.coreg[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_coreg_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_coreg(i as int),
    {
        self.coreg[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_coreg(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_coreg(i as int) == lit@),
    {
        self.coreg[i] == lit
    }
    pub open spec fn get_value(self, i: int) -> u64 {
        self.value[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_value_exec(&self, i: usize) -> (res: u64)
        requires i < self.n,
        ensures res == self.get_value(i as int),
    {
        self.value[i]
    }
    pub open spec fn get_footnote(self, i: int) -> Seq<char> {
        self.footnote[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_footnote_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_footnote(i as int),
    {
        self.footnote[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_footnote(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_footnote(i as int) == lit@),
    {
        self.footnote[i] == lit
    }
}


pub open spec fn valid_cols_num(cols: &Cols_num) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.ddate.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.ddate[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.qtrs.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.qtrs[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.uom@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.uom[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.coreg@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.coreg[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.value.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.value[i] < LEMMA_MAX_CELL_U64
    &&& cols.footnote@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.footnote[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub struct Cols_sub {
    pub n: usize,
    pub adsh: Vec<String>,
    pub cik: Vec<u32>,
    pub name: Vec<String>,
    pub sic: Vec<u32>,
    pub countryba: Vec<String>,
    pub stprba: Vec<String>,
    pub cityba: Vec<String>,
    pub countryinc: Vec<String>,
    pub form: Vec<String>,
    pub period: Vec<u32>,
    pub fy: Vec<u32>,
    pub fp: Vec<String>,
    pub filed: Vec<u32>,
    pub accepted: Vec<String>,
    pub prevrpt: Vec<u32>,
    pub nciks: Vec<u32>,
    pub afs: Vec<String>,
    pub wksi: Vec<u32>,
    pub fye: Vec<String>,
    pub instance: Vec<String>,
}

impl Cols_sub {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_cik(self, i: int) -> u32 {
        self.cik[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_cik_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_cik(i as int),
    {
        self.cik[i]
    }
    pub open spec fn get_name(self, i: int) -> Seq<char> {
        self.name[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_name_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_name(i as int),
    {
        self.name[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_name(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_name(i as int) == lit@),
    {
        self.name[i] == lit
    }
    pub open spec fn get_sic(self, i: int) -> u32 {
        self.sic[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_sic_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_sic(i as int),
    {
        self.sic[i]
    }
    pub open spec fn get_countryba(self, i: int) -> Seq<char> {
        self.countryba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryba(i as int),
    {
        self.countryba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryba(i as int) == lit@),
    {
        self.countryba[i] == lit
    }
    pub open spec fn get_stprba(self, i: int) -> Seq<char> {
        self.stprba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_stprba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_stprba(i as int),
    {
        self.stprba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_stprba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_stprba(i as int) == lit@),
    {
        self.stprba[i] == lit
    }
    pub open spec fn get_cityba(self, i: int) -> Seq<char> {
        self.cityba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_cityba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_cityba(i as int),
    {
        self.cityba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_cityba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_cityba(i as int) == lit@),
    {
        self.cityba[i] == lit
    }
    pub open spec fn get_countryinc(self, i: int) -> Seq<char> {
        self.countryinc[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryinc_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryinc(i as int),
    {
        self.countryinc[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryinc(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryinc(i as int) == lit@),
    {
        self.countryinc[i] == lit
    }
    pub open spec fn get_form(self, i: int) -> Seq<char> {
        self.form[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_form_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_form(i as int),
    {
        self.form[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_form(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_form(i as int) == lit@),
    {
        self.form[i] == lit
    }
    pub open spec fn get_period(self, i: int) -> u32 {
        self.period[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_period_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_period(i as int),
    {
        self.period[i]
    }
    pub open spec fn get_fy(self, i: int) -> u32 {
        self.fy[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_fy_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_fy(i as int),
    {
        self.fy[i]
    }
    pub open spec fn get_fp(self, i: int) -> Seq<char> {
        self.fp[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_fp_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_fp(i as int),
    {
        self.fp[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_fp(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_fp(i as int) == lit@),
    {
        self.fp[i] == lit
    }
    pub open spec fn get_filed(self, i: int) -> u32 {
        self.filed[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_filed_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_filed(i as int),
    {
        self.filed[i]
    }
    pub open spec fn get_accepted(self, i: int) -> Seq<char> {
        self.accepted[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_accepted_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_accepted(i as int),
    {
        self.accepted[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_accepted(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_accepted(i as int) == lit@),
    {
        self.accepted[i] == lit
    }
    pub open spec fn get_prevrpt(self, i: int) -> u32 {
        self.prevrpt[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_prevrpt_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_prevrpt(i as int),
    {
        self.prevrpt[i]
    }
    pub open spec fn get_nciks(self, i: int) -> u32 {
        self.nciks[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_nciks_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_nciks(i as int),
    {
        self.nciks[i]
    }
    pub open spec fn get_afs(self, i: int) -> Seq<char> {
        self.afs[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_afs_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_afs(i as int),
    {
        self.afs[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_afs(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_afs(i as int) == lit@),
    {
        self.afs[i] == lit
    }
    pub open spec fn get_wksi(self, i: int) -> u32 {
        self.wksi[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_wksi_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_wksi(i as int),
    {
        self.wksi[i]
    }
    pub open spec fn get_fye(self, i: int) -> Seq<char> {
        self.fye[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_fye_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_fye(i as int),
    {
        self.fye[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_fye(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_fye(i as int) == lit@),
    {
        self.fye[i] == lit
    }
    pub open spec fn get_instance(self, i: int) -> Seq<char> {
        self.instance[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_instance_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_instance(i as int),
    {
        self.instance[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_instance(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_instance(i as int) == lit@),
    {
        self.instance[i] == lit
    }
    #[verifier::external_body]
    pub exec fn agg_push_cik_name(
        &self,
        agg: &mut HashMapWithView<(u32, String), u64>,
        i: usize,
        delta: u64,
    )
        requires
            i < self.n &&
        delta < LEMMA_MAX_CELL_U64 &&
        (if old(agg)@.contains_key((self.get_cik(i as int), self.get_name(i as int))) { old(agg)@[(self.get_cik(i as int), self.get_name(i as int))] } else { 0u64 } as int) + ((delta as int) as int) <= u64::MAX as int,
        ensures
            final(agg)@ == old(agg)@.insert(
        (self.get_cik(i as int), self.get_name(i as int)),
        if old(agg)@.contains_key((self.get_cik(i as int), self.get_name(i as int))) {
            (old(agg)@[(self.get_cik(i as int), self.get_name(i as int))] as int + delta as int) as u64
        } else {
            delta
        },
    ),
    {
        let key = (self.get_cik_exec(i), self.get_name_exec(i));
        let prev = agg.get(&key).copied().unwrap_or(0u64);
        let next = prev.checked_add(delta).expect("Trusted overflow: requires violated");
        agg.insert(key, next);
    }
}


pub open spec fn valid_cols_sub(cols: &Cols_sub) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.cik.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.cik[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.name@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.name[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.sic.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.sic[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.countryba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.stprba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.stprba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.cityba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.cityba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.countryinc@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryinc[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.form@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.form[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.period.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.period[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fy.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.fy[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fp@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.fp[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.filed.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.filed[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.accepted@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.accepted[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.prevrpt.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.prevrpt[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.nciks.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.nciks[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.afs@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.afs[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.wksi.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.wksi[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fye@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.fye[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.instance@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.instance[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub open spec fn join_method_spec_helper(num: &Cols_num, sub: &Cols_sub, i0: int, i1: int) -> (res: Map<(Seq<char>, u32), u64>)
    decreases num.n - i0, sub.n - i1,
{
    if i0 < num.n {
        if i1 < sub.n {
            let tail = join_method_spec_helper(num, sub, i0, i1 + 1);
            if (num.adsh[i0 as int]@ == sub.adsh[i1 as int]@) && (((num.uom[i0 as int]@ == "USD"@ && sub.fy[i1 as int] == 2022) && true)) {
                let key = (sub.name[i1 as int]@, sub.cik[i1 as int]);
            let val = if tail.contains_key(key) { tail[key] } else { 0u64 };
            tail.insert(key, (val as int + (num.value[i0 as int]) as int) as u64)
            } else {
                tail
            }
        } else {
            join_method_spec_helper(num, sub, i0 + 1, 0)
        }
    } else {
        Map::empty()
    }
}

pub open spec fn apply_having_filter<K, V>(m: Map<K, V>, pred: spec_fn(K, V) -> bool) -> Map<K, V> {
    m.filter_keys(|k| pred(k, m[k]))
}

pub open spec fn subquery_having_sq1_derived_avg_sub_helper(num: &Cols_num, sub: &Cols_sub, i0: int, i1: int) -> (res: Map<u32, u64>)
    decreases num.n - i0, sub.n - i1,
{
    if i0 < num.n {
        if i1 < sub.n {
            let tail = subquery_having_sq1_derived_avg_sub_helper(num, sub, i0, i1 + 1);
            if (num.adsh[i0 as int]@ == sub.adsh[i1 as int]@) && (((num.uom[i0 as int]@ == "USD"@ && sub.fy[i1 as int] == 2022) && true)) {
                let key = sub.cik[i1 as int];
            let val = if tail.contains_key(key) { tail[key] } else { 0u64 };
            tail.insert(key, (val as int + (num.value[i0 as int]) as int) as u64)
            } else {
                tail
            }
        } else {
            subquery_having_sq1_derived_avg_sub_helper(num, sub, i0 + 1, 0)
        }
    } else {
        Map::empty()
    }
}

pub open spec fn subquery_having_sq1_derived_avg_sub_spec(num: &Cols_num, sub: &Cols_sub) -> Map<u32, u64>
    recommends
        valid_cols_num(num),
        valid_cols_sub(sub),
{
    subquery_having_sq1_derived_avg_sub_helper(num, sub, 0, 0)
}

pub open spec fn subquery_having_sq1_spec(num: &Cols_num, sub: &Cols_sub) -> u64
    recommends valid_cols_num(num), valid_cols_sub(sub),
{
    {
    let m = subquery_having_sq1_derived_avg_sub_spec(num, sub);
    let s = m.values().fold(0u64, |acc, v| (acc as int + v as int) as u64);
    let c = m.len() as u64;
    if c == 0 { 0 } else { s / c }
}
}

pub open spec fn method_spec(num: &Cols_num, sub: &Cols_sub) -> Map<(Seq<char>, u32), u64>
    recommends
        valid_cols_num(num),
        valid_cols_sub(sub),
{
    {
    let m = join_method_spec_helper(num, sub, 0, 0);
    apply_having_filter(m, |k: (Seq<char>, u32), v: u64| (v > subquery_having_sq1_spec(num, sub)))
}
}

// Note: ORDER BY (total_value DESC), LIMIT 50, OFFSET 0 are not part of method_spec (((Seq<char>, u32), u64)); agent may apply in run_query.
// === Agent: use TRUSTED helpers below (vstd map/set @ views).
// Maps: agg_new_* / agg_add_* / agg_put_*; ensures res@ == method_spec.
// Multi-agg steps: agg_step_state_new_* / agg_step_* (+ agg_step_apply_row_* spec).
// HAVING: host post-filter exec helper (ensures vs apply_having_filter).
// Distinct sets: hashset_*_as_map + set_new_* / set_insert_* (COUNT_DISTINCT state).
// Seqs: seq_new_* / seq_push_* when present; else Vec@ directly.
use vstd::hash_map::{HashMapWithView, StringHashMap};
use vstd::hash_set::HashSetWithView;

// === TRUSTED structural map helpers (vstd view @ + agg_new + agg_put/agg_add) ===
#[verifier::external_body]
pub exec fn agg_new_str_u32__u64() -> (hm: HashMapWithView<(String, u32), u64>)
    ensures hm@ == Map::empty(),
{
    HashMapWithView::new()
}

#[verifier::external_body]
pub exec fn agg_add_str_u32__u64(hm: &mut HashMapWithView<(String, u32), u64>, k0: &str, k1: u32, delta: u64)
    requires
        delta < LEMMA_MAX_CELL_U64 &&
        (if old(hm)@.contains_key((k0@, k1)) { old(hm)@[(k0@, k1)] } else { 0u64 } as int) + ((delta as int)) <= u64::MAX as int,
    ensures
        final(hm)@ == old(hm)@.insert(
        (k0@, k1),
        if old(hm)@.contains_key((k0@, k1)) {
            (old(hm)@[(k0@, k1)] as int + delta as int) as u64
        } else {
            delta
        },
    ),
{

    let key = (k0.to_string(), k1);
    let prev = hm.get(&key).copied().unwrap_or(0);
    hm.insert(key, prev.checked_add(delta).expect("Trusted overflow: ValidCols/requires violated"));
}

// === Scalar map fold bound assumptions (str_u32_u64) ===
// ASSUMPTION (catalog/user): under `valid_cols` + this open-spec fold, partial agg ≤ rem·cap.
// Not a Verus-proved induction — expert accepts under table/catalog assumptions.
// SUM(u64 cell): ≤((sub.n - i1) + (num.n - i0 - 1) * sub.n) as u64 cells each < LEMMA_MAX_CELL_U64.
#[verifier::external_body]
pub proof fn assume_join_method_spec_helper_sum_cell_u64_leq_str_u32_u64(
    num: &Cols_num,
    sub: &Cols_sub,
    i0: int,
    i1: int,
    key: (Seq<char>, u32),
)
    requires
        valid_cols_num(num),
        valid_cols_sub(sub),
        0 <= num.n as int,
        0 <= sub.n as int,
        0 <= i0 <= num.n as int,
        0 <= i1 <= sub.n as int,
    ensures
        (if join_method_spec_helper(num, sub, i0, i1).contains_key(key) { join_method_spec_helper(num, sub, i0, i1)[key] } else { 0u64 }) <= ((sub.n - i1) + (num.n - i0 - 1) * sub.n) as u64 * (LEMMA_MAX_CELL_U64 as u64),
{
}
// === HAVING map peel: vstd HashMapWithView / StringHashMap are single-field newtypes ===
// over std::collections::HashMap (same layout fact vstd uses). Transmute stays inside
// these helpers only. Semantic HAVING ensures live on apply_having_filter_exec_* (res@).
#[repr(C)]
struct HashMapWithViewPeel<K, V> {
    m: std::collections::HashMap<K, V>,
}

#[repr(C)]
struct StringHashMapPeel<V> {
    m: std::collections::HashMap<String, V>,
}

#[verifier::external_body]
pub exec fn hashmap_with_view_unwrap<K, V>(
    hm: HashMapWithView<K, V>,
) -> (m: std::collections::HashMap<K, V>)
    where
        K: vstd::view::View + std::cmp::Eq + std::hash::Hash,
    ensures
        true,
{
    let peeled: HashMapWithViewPeel<K, V> = unsafe { std::mem::transmute(hm) };
    peeled.m
}

#[verifier::external_body]
pub exec fn hashmap_with_view_wrap<K, V>(
    m: std::collections::HashMap<K, V>,
) -> (hm: HashMapWithView<K, V>)
    where
        K: vstd::view::View + std::cmp::Eq + std::hash::Hash,
    ensures
        true,
{
    let peeled = HashMapWithViewPeel { m };
    unsafe { std::mem::transmute(peeled) }
}

// === HAVING post-filter (str_u32_u64): exec map retain vs apply_having_filter ===
#[verifier::external_body]
pub exec fn apply_having_filter_exec_str_u32_u64(
    hm: HashMapWithView<(String, u32), u64>,
    num: &Cols_num,
    sub: &Cols_sub,
) -> (res: HashMapWithView<(String, u32), u64>)
    requires
        valid_cols_num(num),
        valid_cols_sub(sub),
    ensures
        res@
            == apply_having_filter(
                hm@,
                |k: (Seq<char>, u32), v: u64| (v > subquery_having_sq1_spec(num, sub)),
            ),
{
    {
    let std_hm = hashmap_with_view_unwrap(hm);
    let std_res: std::collections::HashMap<(String, u32), u64> = std_hm
        .into_iter()
        .filter(|(_k, v)| (*v > subquery_having_sq1_spec(num, sub)))
        .collect();
    hashmap_with_view_wrap(std_res)
}
}
} // verus!
