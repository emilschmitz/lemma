SELECT s.name, s.sic, t.tlabel, p.stmt, p.plabel,
       SUM(n.value) AS total_value, COUNT(*) AS cnt
FROM num n
JOIN sub s ON n.adsh = s.adsh
JOIN tag t ON n.tag = t.tag AND n.version = t.version
JOIN pre p ON n.adsh = p.adsh AND n.tag = p.tag AND n.version = p.version
WHERE n.uom = 'USD' AND s.form = '10-K' AND p.stmt = 'BS'
      AND n.value IS NOT NULL AND t.abstract = 0
GROUP BY s.name, s.sic, t.tlabel, p.stmt, p.plabel
HAVING COUNT(*) > 1
ORDER BY total_value DESC
LIMIT 100;
