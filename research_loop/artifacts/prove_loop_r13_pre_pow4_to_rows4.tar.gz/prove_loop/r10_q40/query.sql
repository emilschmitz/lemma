SELECT s.cik, s.name, s.fy, SUM(n.value) AS total_value
FROM num n
JOIN sub s ON n.adsh = s.adsh
WHERE n.tag = 'Assets' AND n.uom = 'USD'
      AND n.qtrs = 0 AND s.fp = 'FY' AND n.value IS NOT NULL
GROUP BY s.cik, s.name, s.fy
ORDER BY s.cik, s.fy
LIMIT 100;
