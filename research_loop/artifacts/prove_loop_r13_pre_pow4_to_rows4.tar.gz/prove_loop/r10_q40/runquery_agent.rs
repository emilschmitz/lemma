//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.cik, s.name, s.fy, SUM(n.value) AS total_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.tag = 'Assets' AND n.uom = 'USD'
//!         AND n.qtrs = 0 AND s.fp = 'FY' AND n.value IS NOT NULL
//!   GROUP BY s.cik, s.name, s.fy
//!   ORDER BY s.cik, s.fy
//!   LIMIT 100;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(u32, Seq<char>, u32), u64>
// Trusted exec↔spec views in context/ro/spec.rs (use one in ensures): hashmap_u32_str_u32__u64_view
// Nested reverse scan matches join_method_spec_helper; ORDER BY/LIMIT are outside method_spec.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: HashMap<(u32, String, u32), u64>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures hashmap_u32_str_u32__u64_view(res@) == method_spec(num, sub),
{
    let mut hm = agg_new_u32_str_u32__u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            hashmap_u32_str_u32__u64_view(hm@) == join_method_spec_helper(num, sub, i0 as int, 0),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(join_method_spec_helper(num, sub, i0 as int, sub.n as int)
                == join_method_spec_helper(num, sub, (i0 + 1) as int, 0));
            assert(hashmap_u32_str_u32__u64_view(hm@)
                == join_method_spec_helper(num, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                valid_cols_num(num),
                valid_cols_sub(sub),
                hashmap_u32_str_u32__u64_view(hm@)
                    == join_method_spec_helper(num, sub, i0 as int, i1 as int),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh_s = sub.get_adsh_exec(i1);
            let qtrs = num.get_qtrs_exec(i0);
            if num.eq_at_adsh(i0, adsh_s.as_str())
                && num.eq_at_tag(i0, "Assets")
                && num.eq_at_uom(i0, "USD")
                && qtrs == 0
                && sub.eq_at_fp(i1, "FY")
            {
                let cik = sub.get_cik_exec(i1);
                let name = sub.get_name_exec(i1);
                let fy = sub.get_fy_exec(i1);
                let value = num.get_value_exec(i0);
                agg_add_u32_str_u32__u64(&mut hm, cik, name.as_str(), fy, value);
                proof {
                    let ghost tail = join_method_spec_helper(num, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = (sub.cik[i1 as int], sub.name[i1 as int]@, sub.fy[i1 as int]);
                    let ghost val = if tail.contains_key(key) { tail[key] } else { 0u64 };
                    let ghost expected = tail.insert(key, (val as int + (num.value[i0 as int]) as int) as u64);
                    assert(expected == join_method_spec_helper(num, sub, i0 as int, i1 as int));
                    assert(hashmap_u32_str_u32__u64_view(hm@)
                        == join_method_spec_helper(num, sub, i0 as int, i1 as int));
                }
            } else {
                proof {
                    assert(
                        join_method_spec_helper(num, sub, i0 as int, i1 as int)
                            == join_method_spec_helper(num, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(hashmap_u32_str_u32__u64_view(hm@)
                == join_method_spec_helper(num, sub, i0 as int, 0));
        }
    }
    proof {
        assert(hashmap_u32_str_u32__u64_view(hm@) == join_method_spec_helper(num, sub, 0, 0));
        assert(hashmap_u32_str_u32__u64_view(hm@) == method_spec(num, sub));
    }
    hm
}
// AGENT_EDIT_END

} // verus!
