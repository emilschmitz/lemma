//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT t.tlabel, t.datatype, COUNT(*) AS usage_count,
//!          COUNT(DISTINCT p.adsh) AS filing_count
//!   FROM pre p
//!   JOIN tag t ON p.tag = t.tag AND p.version = t.version
//!   WHERE p.stmt = 'EQ' AND t.tlabel IS NOT NULL
//!   GROUP BY t.tlabel, t.datatype
//!   HAVING COUNT(*) > 5
//!   ORDER BY usage_count DESC
//!   LIMIT 50;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START



// MethodSpec returns: Map<(Seq<char>, Seq<char>), (u64, u64)>
// Trusted: hashmap_str_str__u64_u64_view / agg_step_* / apply_having_filter_exec_*
// Nested reverse scan matches multi_agg_helper; HAVING via apply_having_filter_exec_*.
pub exec fn run_query(pre: &Cols_pre, tag: &Cols_tag) -> (res: HashMapWithView<(String, String), (u64, u64)>)
    requires valid_cols_pre(pre), valid_cols_tag(tag),
    ensures res@ == method_spec(pre, tag),
{
    let mut st = agg_step_state_new_str_str__u64_u64();
    let mut i0: usize = pre.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= pre.n,
            i1 == 0,
            valid_cols_pre(pre),
            valid_cols_tag(tag),
            agg_step_inner_str_str__u64_u64_spec(st.inner@) == multi_agg_helper(pre, tag, i0 as int, 0),
            st.projected@
                == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                    |v: (u64, Map<Seq<char>, bool>)| agg_step_project_str_str__u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = tag.n;
        proof {
            assert(multi_agg_helper(pre, tag, i0 as int, tag.n as int)
                == multi_agg_helper(pre, tag, (i0 + 1) as int, 0));
            assert(agg_step_inner_str_str__u64_u64_spec(st.inner@)
                == multi_agg_helper(pre, tag, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < pre.n,
                i1 <= tag.n,
                valid_cols_pre(pre),
                valid_cols_tag(tag),
                agg_step_inner_str_str__u64_u64_spec(st.inner@)
                    == multi_agg_helper(pre, tag, i0 as int, i1 as int),
                st.projected@
                    == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                        |v: (u64, Map<Seq<char>, bool>)| agg_step_project_str_str__u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let tag_s = tag.get_tag_exec(i1);
            let ver_s = tag.get_version_exec(i1);
            if pre.eq_at_tag(i0, tag_s.as_str())
                && pre.eq_at_version(i0, ver_s.as_str())
                && pre.eq_at_stmt(i0, "EQ")
                && !tag.eq_at_tlabel(i1, "")
            {
                let tlabel = tag.get_tlabel_exec(i1);
                let datatype = tag.get_datatype_exec(i1);
                let adsh = pre.get_adsh_exec(i0);
                proof {
                    let ghost i0g = i0 as int;
                    let ghost i1g = (i1 + 1) as int;
                    let ghost rem = (((tag.n - i1g) + (pre.n - i0g - 1) * tag.n)) as u64;
                    assert(pre.n <= LEMMA_MAX_ROWS);
                    assert(tag.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(pre.n, tag.n, i0g, i1g);
                    let ghost tail = multi_agg_helper(pre, tag, i0 as int, (i1 + 1) as int);
                    let ghost key = (tag.tlabel[i1 as int]@, tag.datatype[i1 as int]@);
                    let ghost prev = if tail.contains_key(key) { tail[key] } else { (0u64, Map::empty()) };
                    let ghost rem = (((tag.n - i1g) + (pre.n - i0g - 1) * tag.n)) as u64;
                    assume_multi_agg_helper_slot0_count_leq_str_str__u64_u64(pre, tag, i0g, i1g, key);
                    assert(prev.0 <= rem);
                    assert(pre.n <= LEMMA_MAX_ROWS);
                    assert(tag.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(pre.n, tag.n, i0g, i1g);
                    lemma_rem_cap_one_add_fits(rem);
                    lemma_u64_add_one_prev_le(prev.0, rem);
                }
                agg_step_str_str__u64_u64(
                    &mut st,
                    tlabel.as_str(),
                    datatype.as_str(),
                    adsh.as_str(),
                );
            } else {
                proof {
                    assert(
                        multi_agg_helper(pre, tag, i0 as int, i1 as int)
                            == multi_agg_helper(pre, tag, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_str__u64_u64_spec(st.inner@)
                    == multi_agg_helper(pre, tag, i0 as int, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_str__u64_u64_spec(st.inner@) == multi_agg_helper(pre, tag, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(pre, tag, 0, 0).map_values(
                    |v: (u64, Map<Seq<char>, bool>)| agg_step_project_str_str__u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(pre, tag, 0, 0).map_values(
                    |v: (u64, Map<Seq<char>, bool>)| (v.0, v.1.dom().len() as u64),
                )
        );
    }
    apply_having_filter_exec_str_str__u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
