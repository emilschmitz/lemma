SELECT s.sic, COUNT(DISTINCT s.cik) AS num_companies,
       COUNT(*) AS num_values,
       SUM(n.value) AS total_value,
       AVG(n.value) AS avg_value,
       MIN(n.value) AS min_value,
       MAX(n.value) AS max_value
FROM num n
JOIN sub s ON n.adsh = s.adsh
WHERE n.uom = 'shares' AND s.fy = 2024
      AND s.sic IS NOT NULL AND n.value IS NOT NULL AND n.value > 0
GROUP BY s.sic
HAVING COUNT(DISTINCT s.cik) >= 3
ORDER BY total_value DESC
LIMIT 500;
