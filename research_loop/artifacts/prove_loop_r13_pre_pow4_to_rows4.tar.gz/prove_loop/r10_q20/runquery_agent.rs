//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.sic, COUNT(DISTINCT s.cik) AS num_companies,
//!          COUNT(*) AS num_values,
//!          SUM(n.value) AS total_value,
//!          AVG(n.value) AS avg_value,
//!          MIN(n.value) AS min_value,
//!          MAX(n.value) AS max_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.uom = 'shares' AND s.fy = 2024
//!         AND s.sic IS NOT NULL AND n.value IS NOT NULL AND n.value > 0
//!   GROUP BY s.sic
//!   HAVING COUNT(DISTINCT s.cik) >= 3
//!   ORDER BY total_value DESC
//!   LIMIT 500;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<u32, (u64, u64, u64, u64, u64, u64)>
// Nested reverse scan matches multi_agg_helper; HAVING via apply_having_filter_exec_*.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: HashMap<u32, (u64, u64, u64, u64, u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures hashmap_u32__u64_u64_u64_u64_u64_u64_view(res@) == method_spec(num, sub),
{
    let mut st = agg_step_state_new_u32__u64_u64_u64_u64_u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, 0),
            hashmap_u32__u64_u64_u64_u64_u64_u64_view(st.projected@)
                == agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64, u64, u64, u64)|
                        agg_step_project_u32__u64_u64_u64_u64_u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, i0 as int, sub.n as int)
                == multi_agg_helper(num, sub, (i0 + 1) as int, 0));
            assert(agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                valid_cols_num(num),
                valid_cols_sub(sub),
                agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, i1 as int),
                hashmap_u32__u64_u64_u64_u64_u64_u64_view(st.projected@)
                    == agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@).map_values(
                        |v: (Map<u32, bool>, u64, u64, u64, u64, u64, u64)|
                            agg_step_project_u32__u64_u64_u64_u64_u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh = sub.get_adsh_exec(i1);
            let fy = sub.get_fy_exec(i1);
            let val = num.get_value_exec(i0);
            if num.eq_at_adsh(i0, adsh.as_str())
                && num.eq_at_uom(i0, "shares")
                && fy == 2024
                && val > 0
            {
                let sic = sub.get_sic_exec(i1);
                let cik = sub.get_cik_exec(i1);
                agg_step_u32__u64_u64_u64_u64_u64_u64(&mut st, sic, cik, val);
                proof {
                    let ghost tail = multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = sub.sic[i1 as int];
                    let ghost prev = if tail.contains_key(key) {
                        tail[key]
                    } else {
                        (Map::empty(), 0u64, 0u64, 0u64, 0u64, u64::MAX, 0u64)
                    };
                    let ghost expected = agg_step_apply_row_u32__u64_u64_u64_u64_u64_u64(
                        prev,
                        sub.cik[i1 as int],
                        num.value[i0 as int],
                    );
                    assert(expected == multi_agg_helper(num, sub, i0 as int, i1 as int)[key]);
                    assert(
                        agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@)
                            == multi_agg_helper(num, sub, i0 as int, i1 as int)
                    );
                }
            } else {
                proof {
                    assert(
                        multi_agg_helper(num, sub, i0 as int, i1 as int)
                            == multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_u32__u64_u64_u64_u64_u64_u64_view(st.inner@)
            == multi_agg_helper(num, sub, 0, 0));
        assert(
            hashmap_u32__u64_u64_u64_u64_u64_u64_view(st.projected@)
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64, u64, u64, u64)|
                        agg_step_project_u32__u64_u64_u64_u64_u64_u64(v),
                )
        );
        assert(
            hashmap_u32__u64_u64_u64_u64_u64_u64_view(st.projected@)
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64, u64, u64, u64)|
                        (v.0.dom().len() as u64, v.1, v.2, if v.4 == 0 { 0 } else { v.3 / v.4 }, v.5, v.6),
                )
        );
    }
    apply_having_filter_exec_u32__u64_u64_u64_u64_u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
