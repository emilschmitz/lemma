SELECT s.name, t.tlabel, SUM(n.value) AS total_value,
       COUNT(*) AS cnt
FROM num n
JOIN sub s ON n.adsh = s.adsh
JOIN tag t ON n.tag = t.tag AND n.version = t.version
WHERE n.uom = 'pure' AND s.fy = 2023
      AND s.sic BETWEEN 2000 AND 3999
      AND n.value IS NOT NULL AND t.abstract = 0
GROUP BY s.name, t.tlabel
HAVING SUM(n.value) > 1000
ORDER BY total_value DESC
LIMIT 1000;
