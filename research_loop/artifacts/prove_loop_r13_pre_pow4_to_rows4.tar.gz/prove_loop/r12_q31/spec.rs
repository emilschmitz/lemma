use vstd::prelude::*;
use std::collections::{HashMap, HashSet};

verus! {

// === Lemma global input bounds (all queries) ===
pub const LEMMA_MAX_ROWS: usize = 2147483648;
pub const LEMMA_MAX_NATIVE_U32: u32 = 2147483648;
pub const LEMMA_MAX_MONEY_U64: u64 = 1099511627776;
pub const LEMMA_MAX_STRING_LEN: usize = 128;


// === Trusted arithmetic helpers ===
// TRUSTED: rustc wrapping_add; sound when ValidCols row/cell bounds apply (no overflow).
#[verifier::external_body]
pub exec fn add_u64(a: u64, b: u64) -> (res: u64)
    ensures res == a + b,
{
    a.wrapping_add(b)
}

// TRUSTED: rustc wrapping_mul; sound when ValidCols bounds apply.
#[verifier::external_body]
pub exec fn mul_u64_u32(a: u64, b: u32) -> (res: u64)
    ensures res == a * (b as u64),
{
    a.wrapping_mul(b as u64)
}

// TRUSTED: signed difference on bounded u64 cells.
#[verifier::external_body]
pub exec fn sub_u64_to_i64(a: u64, b: u64) -> (res: i64)
    ensures res == (a as int) - (b as int),
{
    (a as i64) - (b as i64)
}

// TRUSTED: rustc wrapping_add on i64.
#[verifier::external_body]
pub exec fn add_i64(a: i64, b: i64) -> (res: i64)
    ensures res == a + b,
{
    a.wrapping_add(b)
}

// === CASE WHEN (simple int branches) ===
pub open spec fn case_when_u64(cond: bool, then_v: u64, else_v: u64) -> u64 {
    if cond { then_v } else { else_v }
}

#[verifier::external_body]
pub exec fn case_when_u64_exec(cond: bool, then_v: u64, else_v: u64) -> (res: u64)
    ensures res == case_when_u64(cond, then_v, else_v),
{
    if cond { then_v } else { else_v }
}

// === String LIKE helpers (basic % prefix/suffix/contains) ===
pub open spec fn str_like_prefix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_prefix_of(s)
}

pub open spec fn str_like_suffix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_suffix_of(s)
}

// TRUSTED axiom: substring containment (exists quantifier needs manual triggers).
#[verifier::external_body]
pub open spec fn str_like_contains(s: Seq<char>, lit: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED: exec string prefix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_prefix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_prefix(s@, lit@),
{
    s.starts_with(lit)
}

// TRUSTED: exec string suffix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_suffix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_suffix(s@, lit@),
{
    s.ends_with(lit)
}

// TRUSTED: exec string contains check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_contains_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_contains(s@, lit@),
{
    s.contains(lit)
}

// === ILIKE + underscore LIKE (TRUSTED pattern match) ===
// TRUSTED axiom: case-insensitive SQL LIKE/ILIKE pattern (%, _ wildcards).
#[verifier::external_body]
pub open spec fn str_ilike_match(s: Seq<char>, pat: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED axiom: case-sensitive LIKE with _ single-char wildcard.
#[verifier::external_body]
pub open spec fn str_like_underscore_match(s: Seq<char>, pat: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED: exec ILIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_ilike_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_ilike_match(s@, pat@),
{
    str_like_underscore_match_exec(&s.to_ascii_lowercase(), &pat.to_ascii_lowercase())
}

// TRUSTED: exec underscore LIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_underscore_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_like_underscore_match(s@, pat@),
{
    fn m(s: &[char], si: usize, p: &[char], pi: usize) -> bool {
        if pi >= p.len() {
            return si >= s.len();
        }
        if p[pi] == '%' {
            let mut k = si;
            while k <= s.len() {
                if m(s, k, p, pi + 1) {
                    return true;
                }
                k += 1;
            }
            return false;
        }
        if p[pi] == '_' {
            if si >= s.len() {
                return false;
            }
            return m(s, si + 1, p, pi + 1);
        }
        if si >= s.len() || s[si] != p[pi] {
            return false;
        }
        m(s, si + 1, p, pi + 1)
    }
    let sc: Vec<char> = s.chars().collect();
    let pc: Vec<char> = pat.chars().collect();
    m(&sc, 0, &pc, 0)
}

// === Scalar helpers (abs / case) ===
// TRUSTED: abs on bounded u64 cell.
#[verifier::external_body]
pub open spec fn abs_u64(x: u64) -> u64 {
    arbitrary()
}

#[verifier::external_body]
pub exec fn abs_u64_exec(x: u64) -> (res: u64)
    ensures res == abs_u64(x),
{
    if x > (0u64) { x } else { 0u64.wrapping_sub(x) }
}

// TRUSTED axiom: ASCII lower/upper on Seq<char>.
#[verifier::external_body]
pub open spec fn str_lower(s: Seq<char>) -> Seq<char> {
    arbitrary()
}

#[verifier::external_body]
pub open spec fn str_upper(s: Seq<char>) -> Seq<char> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn str_lower_exec(s: &str) -> (res: String)
    ensures res@ == str_lower(s@),
{
    s.to_ascii_lowercase()
}

#[verifier::external_body]
pub exec fn str_upper_exec(s: &str) -> (res: String)
    ensures res@ == str_upper(s@),
{
    s.to_ascii_uppercase()
}

// === Seq helpers (projection + LIMIT) ===
pub open spec fn spec_seq_take<A>(s: Seq<A>, n: int) -> Seq<A> {
    if n <= 0 {
        Seq::empty()
    } else if n >= s.len() {
        s
    } else {
        s.subrange(0, n)
    }
}

pub open spec fn spec_seq_concat<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_concat_helper(a, b, 0)
}

pub open spec fn spec_seq_concat_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        spec_seq_concat_helper(a.push(b[i]), b, i + 1)
    } else {
        a
    }
}

pub open spec fn spec_seq_union_distinct<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_union_distinct_helper(a, b, 0)
}

pub open spec fn spec_seq_union_distinct_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        let tail = spec_seq_union_distinct_helper(a, b, i + 1);
        if tail.contains(b[i]) {
            tail
        } else {
            tail.push(b[i])
        }
    } else {
        a
    }
}

pub open spec fn seq_sum_u64(s: Seq<u64>) -> u64 {
    seq_sum_u64_helper(s, 0)
}

pub open spec fn seq_sum_u64_helper(s: Seq<u64>, i: int) -> u64
    decreases s.len() - i,
{
    if i < s.len() {
        (seq_sum_u64_helper(s, i + 1) as int + s[i] as int) as u64
    } else {
        0
    }
}

// TRUSTED: multi-agg HashMap exec view bridge.
#[verifier::external_body]
pub open spec fn hashmap_multi_agg_view<K, V>(m: Map<K, V>) -> Map<K, V> {
    m
}


pub struct Cols_sub {
    pub n: usize,
    pub adsh: Vec<String>,
    pub cik: Vec<u32>,
    pub name: Vec<String>,
    pub sic: Vec<u32>,
    pub countryba: Vec<String>,
    pub stprba: Vec<String>,
    pub cityba: Vec<String>,
    pub countryinc: Vec<String>,
    pub form: Vec<String>,
    pub period: Vec<u32>,
    pub fy: Vec<u32>,
    pub fp: Vec<String>,
    pub filed: Vec<u32>,
    pub accepted: Vec<String>,
    pub prevrpt: Vec<u32>,
    pub nciks: Vec<u32>,
    pub afs: Vec<String>,
    pub wksi: Vec<u32>,
    pub fye: Vec<String>,
    pub instance: Vec<String>,
}

impl Cols_sub {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_cik(self, i: int) -> u32 {
        self.cik[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_cik_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_cik(i as int),
    {
        self.cik[i]
    }
    pub open spec fn get_name(self, i: int) -> Seq<char> {
        self.name[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_name_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_name(i as int),
    {
        self.name[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_name(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_name(i as int) == lit@),
    {
        self.name[i] == lit
    }
    pub open spec fn get_sic(self, i: int) -> u32 {
        self.sic[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_sic_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_sic(i as int),
    {
        self.sic[i]
    }
    pub open spec fn get_countryba(self, i: int) -> Seq<char> {
        self.countryba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryba(i as int),
    {
        self.countryba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryba(i as int) == lit@),
    {
        self.countryba[i] == lit
    }
    pub open spec fn get_stprba(self, i: int) -> Seq<char> {
        self.stprba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_stprba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_stprba(i as int),
    {
        self.stprba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_stprba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_stprba(i as int) == lit@),
    {
        self.stprba[i] == lit
    }
    pub open spec fn get_cityba(self, i: int) -> Seq<char> {
        self.cityba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_cityba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_cityba(i as int),
    {
        self.cityba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_cityba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_cityba(i as int) == lit@),
    {
        self.cityba[i] == lit
    }
    pub open spec fn get_countryinc(self, i: int) -> Seq<char> {
        self.countryinc[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryinc_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryinc(i as int),
    {
        self.countryinc[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryinc(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryinc(i as int) == lit@),
    {
        self.countryinc[i] == lit
    }
    pub open spec fn get_form(self, i: int) -> Seq<char> {
        self.form[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_form_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_form(i as int),
    {
        self.form[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_form(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_form(i as int) == lit@),
    {
        self.form[i] == lit
    }
    pub open spec fn get_period(self, i: int) -> u32 {
        self.period[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_period_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_period(i as int),
    {
        self.period[i]
    }
    pub open spec fn get_fy(self, i: int) -> u32 {
        self.fy[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_fy_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_fy(i as int),
    {
        self.fy[i]
    }
    pub open spec fn get_fp(self, i: int) -> Seq<char> {
        self.fp[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_fp_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_fp(i as int),
    {
        self.fp[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_fp(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_fp(i as int) == lit@),
    {
        self.fp[i] == lit
    }
    pub open spec fn get_filed(self, i: int) -> u32 {
        self.filed[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_filed_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_filed(i as int),
    {
        self.filed[i]
    }
    pub open spec fn get_accepted(self, i: int) -> Seq<char> {
        self.accepted[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_accepted_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_accepted(i as int),
    {
        self.accepted[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_accepted(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_accepted(i as int) == lit@),
    {
        self.accepted[i] == lit
    }
    pub open spec fn get_prevrpt(self, i: int) -> u32 {
        self.prevrpt[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_prevrpt_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_prevrpt(i as int),
    {
        self.prevrpt[i]
    }
    pub open spec fn get_nciks(self, i: int) -> u32 {
        self.nciks[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_nciks_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_nciks(i as int),
    {
        self.nciks[i]
    }
    pub open spec fn get_afs(self, i: int) -> Seq<char> {
        self.afs[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_afs_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_afs(i as int),
    {
        self.afs[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_afs(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_afs(i as int) == lit@),
    {
        self.afs[i] == lit
    }
    pub open spec fn get_wksi(self, i: int) -> u32 {
        self.wksi[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_wksi_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_wksi(i as int),
    {
        self.wksi[i]
    }
    pub open spec fn get_fye(self, i: int) -> Seq<char> {
        self.fye[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_fye_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_fye(i as int),
    {
        self.fye[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_fye(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_fye(i as int) == lit@),
    {
        self.fye[i] == lit
    }
    pub open spec fn get_instance(self, i: int) -> Seq<char> {
        self.instance[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_instance_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_instance(i as int),
    {
        self.instance[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_instance(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_instance(i as int) == lit@),
    {
        self.instance[i] == lit
    }
}


pub open spec fn valid_cols_sub(cols: &Cols_sub) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.cik.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.cik[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.name@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.name[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.sic.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.sic[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.countryba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.stprba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.stprba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.cityba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.cityba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.countryinc@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryinc[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.form@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.form[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.period.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.period[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fy.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.fy[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fp@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.fp[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.filed.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.filed[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.accepted@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.accepted[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.prevrpt.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.prevrpt[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.nciks.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.nciks[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.afs@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.afs[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.wksi.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.wksi[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fye@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.fye[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.instance@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.instance[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub struct Cols_num {
    pub n: usize,
    pub adsh: Vec<String>,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub ddate: Vec<u32>,
    pub qtrs: Vec<u32>,
    pub uom: Vec<String>,
    pub coreg: Vec<String>,
    pub value: Vec<u64>,
    pub footnote: Vec<String>,
}

impl Cols_num {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_ddate(self, i: int) -> u32 {
        self.ddate[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_ddate_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_ddate(i as int),
    {
        self.ddate[i]
    }
    pub open spec fn get_qtrs(self, i: int) -> u32 {
        self.qtrs[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_qtrs_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_qtrs(i as int),
    {
        self.qtrs[i]
    }
    pub open spec fn get_uom(self, i: int) -> Seq<char> {
        self.uom[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_uom_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_uom(i as int),
    {
        self.uom[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_uom(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_uom(i as int) == lit@),
    {
        self.uom[i] == lit
    }
    pub open spec fn get_coreg(self, i: int) -> Seq<char> {
        self.coreg[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_coreg_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_coreg(i as int),
    {
        self.coreg[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_coreg(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_coreg(i as int) == lit@),
    {
        self.coreg[i] == lit
    }
    pub open spec fn get_value(self, i: int) -> u64 {
        self.value[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_value_exec(&self, i: usize) -> (res: u64)
        requires i < self.n,
        ensures res == self.get_value(i as int),
    {
        self.value[i]
    }
    pub open spec fn get_footnote(self, i: int) -> Seq<char> {
        self.footnote[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_footnote_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_footnote(i as int),
    {
        self.footnote[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_footnote(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_footnote(i as int) == lit@),
    {
        self.footnote[i] == lit
    }
}


pub open spec fn valid_cols_num(cols: &Cols_num) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.ddate.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.ddate[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.qtrs.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.qtrs[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.uom@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.uom[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.coreg@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.coreg[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.value.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.value[i] < LEMMA_MAX_MONEY_U64
    &&& cols.footnote@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.footnote[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub open spec fn join_projection_helper(num: &Cols_num, sub: &Cols_sub, i0: int, i1: int) -> (res: Seq<(Seq<char>, Seq<char>, u64)>)
    decreases num.n - i0, sub.n - i1,
{
    if i0 < num.n {
        if i1 < sub.n {
            let tail = join_projection_helper(num, sub, i0, i1 + 1);
            if (num.adsh[i0 as int]@ == sub.adsh[i1 as int]@) && ((((num.uom[i0 as int]@ == "pure"@ && sub.fy[i1 as int] == 2024) && true) && num.value[i0 as int] == subquery_sq1_spec(num, num.tag[i0 as int]@, num.adsh[i0 as int]@))) {
                tail.push((sub.name[i1 as int]@, num.tag[i0 as int]@, num.value[i0 as int]))
            } else {
                tail
            }
        } else {
            join_projection_helper(num, sub, i0 + 1, 0)
        }
    } else {
        Seq::empty()
    }
}

pub open spec fn subquery_sq1_helper(num: &Cols_num, outer_tag: Seq<char>, outer_adsh: Seq<char>, k: int) -> (res: u64)
    recommends valid_cols_num(num),
    decreases num.n - k,
{
    if k < num.n {
        let tail = subquery_sq1_helper(num, outer_tag, outer_adsh, k + 1);
        if ((num.get_tag(k) == outer_tag && num.get_adsh(k) == outer_adsh) && num.get_uom(k) == "pure"@) {
            let t = ((num.get_value(k) as int)) as u64; if t > tail { t } else { tail }
        } else {
            tail
        }
    } else {
        0
    }
}

pub open spec fn subquery_sq1_spec(num: &Cols_num, outer_tag: Seq<char>, outer_adsh: Seq<char>) -> u64
    recommends valid_cols_num(num),
{
    subquery_sq1_helper(num, outer_tag, outer_adsh, 0)
}

pub open spec fn method_spec(num: &Cols_num, sub: &Cols_sub) -> Seq<(Seq<char>, Seq<char>, u64)>
    recommends
        valid_cols_num(num),
        valid_cols_sub(sub),
{
    spec_seq_take(join_projection_helper(num, sub, 0, 0), 50)
}

// Note: ORDER BY (value DESC), LIMIT 50, OFFSET 0 are not part of method_spec ((Seq<char>, Seq<char>, u64)); agent may apply in run_query.
// === Agent: use TRUSTED helpers below for opaque views.
// Maps: agg_new_* / agg_add_* (wrapping) / agg_put_* (set projected tuple).
// Multi-agg steps: agg_step_state_new_* / agg_step_* (+ agg_step_apply_row_* spec).
// HAVING: host post-filter exec helper (ensures vs apply_having_filter).
// Distinct sets: hashset_*_view + set_new_* / set_insert_* (COUNT_DISTINCT state).
// Seqs: seq_new_* / seq_push_* when present. Raw HashMap::new()/Vec::new()
// will not prove against opaque hashmap_*/vec_*_view.
// === TRUSTED structural seq helpers (view + seq_new + seq_push) ===
#[verifier::external_body]
pub open spec fn vec_str_str_u64_view(s: Seq<(String, String, u64)>) -> Seq<(Seq<char>, Seq<char>, u64)> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn seq_new_str_str_u64() -> (s: Vec<(String, String, u64)>)
    ensures vec_str_str_u64_view(s@) == Seq::empty(),
{
    Vec::new()
}

#[verifier::external_body]
pub exec fn seq_push_str_str_u64(s: &mut Vec<(String, String, u64)>, e0: &str, e1: &str, e2: u64)
    ensures vec_str_str_u64_view(final(s)@) == vec_str_str_u64_view(old(s)@).push((e0@, e1@, e2)),
{
    s.push((e0.to_string(), e1.to_string(), e2));
}
} // verus!
