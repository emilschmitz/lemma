SELECT s.name, p.stmt, t.tlabel, p.line, p.plabel
FROM pre p
JOIN sub s ON p.adsh = s.adsh
JOIN tag t ON p.tag = t.tag AND p.version = t.version
WHERE s.form = '8-K' AND p.stmt = 'IS'
      AND t.custom = 0
ORDER BY s.name, p.line
LIMIT 1000;
