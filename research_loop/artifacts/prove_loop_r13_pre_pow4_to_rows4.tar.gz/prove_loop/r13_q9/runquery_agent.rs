//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.name, p.stmt, t.tlabel, p.line, p.plabel
//!   FROM pre p
//!   JOIN sub s ON p.adsh = s.adsh
//!   JOIN tag t ON p.tag = t.tag AND p.version = t.version
//!   WHERE s.form = '8-K' AND p.stmt = 'IS'
//!         AND t.custom = 0
//!   ORDER BY s.name, p.line
//!   LIMIT 1000;
//!

use vstd::prelude::*;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Seq<(Seq<char>, Seq<char>, Seq<char>, u32, Seq<char>)>
// Reverse nested scan matches join_projection_helper; LIMIT via spec_seq_take / early stop.
pub exec fn run_query(pre: &Cols_pre, sub: &Cols_sub, tag: &Cols_tag) -> (res: Vec<(String, String, String, u32, String)>)
    requires valid_cols_pre(pre), valid_cols_sub(sub), valid_cols_tag(tag),
    ensures vec_str_str_str_u32_str_view(res@) == method_spec(pre, sub, tag),
{
    let mut out = seq_new_str_str_str_u32_str();
    let mut taken: usize = 0;
    let mut i0: usize = pre.n;
    let mut i1: usize = 0;
    let mut i2: usize = 0;
    while i0 > 0
        invariant
            i0 <= pre.n,
            i1 == 0,
            i2 == 0,
            taken <= 1000,
            valid_cols_pre(pre),
            valid_cols_sub(sub),
            valid_cols_tag(tag),
            taken as int == vec_str_str_str_u32_str_view(out@).len(),
            vec_str_str_str_u32_str_view(out@)
                == spec_seq_take(join_projection_helper(pre, sub, tag, i0 as int, 0, 0), 1000),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(join_projection_helper(pre, sub, tag, i0 as int, sub.n as int, 0)
                == join_projection_helper(pre, sub, tag, (i0 + 1) as int, 0, 0));
            assert(vec_str_str_str_u32_str_view(out@)
                == spec_seq_take(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, 0), 1000));
        }
        while i1 > 0
            invariant
                i0 < pre.n,
                i1 <= sub.n,
                i2 == 0,
                taken <= 1000,
                valid_cols_pre(pre),
                valid_cols_sub(sub),
                valid_cols_tag(tag),
                taken as int == vec_str_str_str_u32_str_view(out@).len(),
                vec_str_str_str_u32_str_view(out@)
                    == spec_seq_take(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, 0), 1000),
            decreases i1,
        {
            i1 = i1 - 1;
            i2 = tag.n;
            proof {
                assert(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, tag.n as int)
                    == join_projection_helper(pre, sub, tag, i0 as int, (i1 + 1) as int, 0));
                assert(vec_str_str_str_u32_str_view(out@)
                    == spec_seq_take(
                        join_projection_helper(pre, sub, tag, i0 as int, i1 as int, i2 as int),
                        1000,
                    ));
            }
            while i2 > 0
                invariant
                    i0 < pre.n,
                    i1 < sub.n,
                    i2 <= tag.n,
                    taken <= 1000,
                    valid_cols_pre(pre),
                    valid_cols_sub(sub),
                    valid_cols_tag(tag),
                    taken as int == vec_str_str_str_u32_str_view(out@).len(),
                    vec_str_str_str_u32_str_view(out@)
                        == spec_seq_take(
                            join_projection_helper(pre, sub, tag, i0 as int, i1 as int, i2 as int),
                            1000,
                        ),
                decreases i2,
            {
                i2 = i2 - 1;
                let adsh_s = sub.get_adsh_exec(i1);
                let tag_t = tag.get_tag_exec(i2);
                let ver_t = tag.get_version_exec(i2);
                let custom_t = tag.get_custom_exec(i2);
                if pre.eq_at_adsh(i0, adsh_s.as_str())
                    && pre.eq_at_tag(i0, tag_t.as_str())
                    && pre.eq_at_version(i0, ver_t.as_str())
                    && sub.eq_at_form(i1, "8-K")
                    && pre.eq_at_stmt(i0, "IS")
                    && custom_t == 0
                {
                    if taken < 1000 {
                        let name_s = sub.get_name_exec(i1);
                        let stmt_p = pre.get_stmt_exec(i0);
                        let tlabel_t = tag.get_tlabel_exec(i2);
                        let line_p = pre.get_line_exec(i0);
                        let plabel_p = pre.get_plabel_exec(i0);
                        seq_push_str_str_str_u32_str(
                            &mut out,
                            name_s.as_str(),
                            stmt_p.as_str(),
                            tlabel_t.as_str(),
                            line_p,
                            plabel_p.as_str(),
                        );
                        taken = taken + 1;
                        proof {
                            let ghost tail = join_projection_helper(
                                pre, sub, tag, i0 as int, i1 as int, (i2 + 1) as int,
                            );
                            let ghost row = (
                                sub.name[i1 as int]@,
                                pre.stmt[i0 as int]@,
                                tag.tlabel[i2 as int]@,
                                pre.line[i0 as int],
                                pre.plabel[i0 as int]@,
                            );
                            assert(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, i2 as int)
                                == tail.push(row));
                            assert(vec_str_str_str_u32_str_view(out@)
                                == spec_seq_take(tail.push(row), 1000));
                        }
                    } else {
                        proof {
                            let ghost tail = join_projection_helper(
                                pre, sub, tag, i0 as int, i1 as int, (i2 + 1) as int,
                            );
                            let ghost row = (
                                sub.name[i1 as int]@,
                                pre.stmt[i0 as int]@,
                                tag.tlabel[i2 as int]@,
                                pre.line[i0 as int],
                                pre.plabel[i0 as int]@,
                            );
                            assert(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, i2 as int)
                                == tail.push(row));
                            assert(taken == 1000);
                            assert(vec_str_str_str_u32_str_view(out@)
                                == spec_seq_take(tail, 1000));
                            assert(spec_seq_take(tail.push(row), 1000)
                                == spec_seq_take(tail, 1000));
                        }
                    }
                } else {
                    proof {
                        assert(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, i2 as int)
                            == join_projection_helper(
                                pre, sub, tag, i0 as int, i1 as int, (i2 + 1) as int,
                            ));
                    }
                }
            }
            proof {
                assert(i2 == 0);
                assert(vec_str_str_str_u32_str_view(out@)
                    == spec_seq_take(join_projection_helper(pre, sub, tag, i0 as int, i1 as int, 0), 1000));
            }
        }
        proof {
            assert(i1 == 0);
            assert(vec_str_str_str_u32_str_view(out@)
                == spec_seq_take(join_projection_helper(pre, sub, tag, i0 as int, 0, 0), 1000));
        }
    }
    proof {
        assert(vec_str_str_str_u32_str_view(out@)
            == spec_seq_take(join_projection_helper(pre, sub, tag, 0, 0, 0), 1000));
        assert(vec_str_str_str_u32_str_view(out@) == method_spec(pre, sub, tag));
    }
    out
}
// AGENT_EDIT_END

} // verus!
