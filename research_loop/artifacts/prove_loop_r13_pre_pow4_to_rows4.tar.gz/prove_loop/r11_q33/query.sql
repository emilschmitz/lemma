SELECT s1.cik, s1.name,
       COUNT(DISTINCT s1.fy) AS years_filed,
       MIN(s1.fy) AS first_year, MAX(s1.fy) AS last_year,
       COUNT(*) AS total_filings
FROM sub s1
WHERE s1.form = '10-K' AND s1.fy IS NOT NULL
GROUP BY s1.cik, s1.name
HAVING COUNT(DISTINCT s1.fy) >= 2
ORDER BY total_filings DESC
LIMIT 200;
