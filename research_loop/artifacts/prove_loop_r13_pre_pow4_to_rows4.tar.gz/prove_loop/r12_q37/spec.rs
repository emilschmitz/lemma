use vstd::prelude::*;
use std::collections::{HashMap, HashSet};

verus! {

// === Lemma global input bounds (all queries) ===
pub const LEMMA_MAX_ROWS: usize = 2147483648;
pub const LEMMA_MAX_NATIVE_U32: u32 = 2147483648;
pub const LEMMA_MAX_MONEY_U64: u64 = 1099511627776;
pub const LEMMA_MAX_STRING_LEN: usize = 128;


// === Trusted arithmetic helpers ===
// TRUSTED: rustc wrapping_add; sound when ValidCols row/cell bounds apply (no overflow).
#[verifier::external_body]
pub exec fn add_u64(a: u64, b: u64) -> (res: u64)
    ensures res == a + b,
{
    a.wrapping_add(b)
}

// TRUSTED: rustc wrapping_mul; sound when ValidCols bounds apply.
#[verifier::external_body]
pub exec fn mul_u64_u32(a: u64, b: u32) -> (res: u64)
    ensures res == a * (b as u64),
{
    a.wrapping_mul(b as u64)
}

// TRUSTED: signed difference on bounded u64 cells.
#[verifier::external_body]
pub exec fn sub_u64_to_i64(a: u64, b: u64) -> (res: i64)
    ensures res == (a as int) - (b as int),
{
    (a as i64) - (b as i64)
}

// TRUSTED: rustc wrapping_add on i64.
#[verifier::external_body]
pub exec fn add_i64(a: i64, b: i64) -> (res: i64)
    ensures res == a + b,
{
    a.wrapping_add(b)
}

// === CASE WHEN (simple int branches) ===
pub open spec fn case_when_u64(cond: bool, then_v: u64, else_v: u64) -> u64 {
    if cond { then_v } else { else_v }
}

#[verifier::external_body]
pub exec fn case_when_u64_exec(cond: bool, then_v: u64, else_v: u64) -> (res: u64)
    ensures res == case_when_u64(cond, then_v, else_v),
{
    if cond { then_v } else { else_v }
}

// === String LIKE helpers (basic % prefix/suffix/contains) ===
pub open spec fn str_like_prefix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_prefix_of(s)
}

pub open spec fn str_like_suffix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_suffix_of(s)
}

// TRUSTED axiom: substring containment (exists quantifier needs manual triggers).
#[verifier::external_body]
pub open spec fn str_like_contains(s: Seq<char>, lit: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED: exec string prefix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_prefix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_prefix(s@, lit@),
{
    s.starts_with(lit)
}

// TRUSTED: exec string suffix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_suffix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_suffix(s@, lit@),
{
    s.ends_with(lit)
}

// TRUSTED: exec string contains check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_contains_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_contains(s@, lit@),
{
    s.contains(lit)
}

// === ILIKE + underscore LIKE (TRUSTED pattern match) ===
// TRUSTED axiom: case-insensitive SQL LIKE/ILIKE pattern (%, _ wildcards).
#[verifier::external_body]
pub open spec fn str_ilike_match(s: Seq<char>, pat: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED axiom: case-sensitive LIKE with _ single-char wildcard.
#[verifier::external_body]
pub open spec fn str_like_underscore_match(s: Seq<char>, pat: Seq<char>) -> bool {
    arbitrary()
}

// TRUSTED: exec ILIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_ilike_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_ilike_match(s@, pat@),
{
    str_like_underscore_match_exec(&s.to_ascii_lowercase(), &pat.to_ascii_lowercase())
}

// TRUSTED: exec underscore LIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_underscore_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_like_underscore_match(s@, pat@),
{
    fn m(s: &[char], si: usize, p: &[char], pi: usize) -> bool {
        if pi >= p.len() {
            return si >= s.len();
        }
        if p[pi] == '%' {
            let mut k = si;
            while k <= s.len() {
                if m(s, k, p, pi + 1) {
                    return true;
                }
                k += 1;
            }
            return false;
        }
        if p[pi] == '_' {
            if si >= s.len() {
                return false;
            }
            return m(s, si + 1, p, pi + 1);
        }
        if si >= s.len() || s[si] != p[pi] {
            return false;
        }
        m(s, si + 1, p, pi + 1)
    }
    let sc: Vec<char> = s.chars().collect();
    let pc: Vec<char> = pat.chars().collect();
    m(&sc, 0, &pc, 0)
}

// === Scalar helpers (abs / case) ===
// TRUSTED: abs on bounded u64 cell.
#[verifier::external_body]
pub open spec fn abs_u64(x: u64) -> u64 {
    arbitrary()
}

#[verifier::external_body]
pub exec fn abs_u64_exec(x: u64) -> (res: u64)
    ensures res == abs_u64(x),
{
    if x > (0u64) { x } else { 0u64.wrapping_sub(x) }
}

// TRUSTED axiom: ASCII lower/upper on Seq<char>.
#[verifier::external_body]
pub open spec fn str_lower(s: Seq<char>) -> Seq<char> {
    arbitrary()
}

#[verifier::external_body]
pub open spec fn str_upper(s: Seq<char>) -> Seq<char> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn str_lower_exec(s: &str) -> (res: String)
    ensures res@ == str_lower(s@),
{
    s.to_ascii_lowercase()
}

#[verifier::external_body]
pub exec fn str_upper_exec(s: &str) -> (res: String)
    ensures res@ == str_upper(s@),
{
    s.to_ascii_uppercase()
}

// === Seq helpers (projection + LIMIT) ===
pub open spec fn spec_seq_take<A>(s: Seq<A>, n: int) -> Seq<A> {
    if n <= 0 {
        Seq::empty()
    } else if n >= s.len() {
        s
    } else {
        s.subrange(0, n)
    }
}

pub open spec fn spec_seq_concat<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_concat_helper(a, b, 0)
}

pub open spec fn spec_seq_concat_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        spec_seq_concat_helper(a.push(b[i]), b, i + 1)
    } else {
        a
    }
}

pub open spec fn spec_seq_union_distinct<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_union_distinct_helper(a, b, 0)
}

pub open spec fn spec_seq_union_distinct_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        let tail = spec_seq_union_distinct_helper(a, b, i + 1);
        if tail.contains(b[i]) {
            tail
        } else {
            tail.push(b[i])
        }
    } else {
        a
    }
}

pub open spec fn seq_sum_u64(s: Seq<u64>) -> u64 {
    seq_sum_u64_helper(s, 0)
}

pub open spec fn seq_sum_u64_helper(s: Seq<u64>, i: int) -> u64
    decreases s.len() - i,
{
    if i < s.len() {
        (seq_sum_u64_helper(s, i + 1) as int + s[i] as int) as u64
    } else {
        0
    }
}

// TRUSTED: multi-agg HashMap exec view bridge.
#[verifier::external_body]
pub open spec fn hashmap_multi_agg_view<K, V>(m: Map<K, V>) -> Map<K, V> {
    m
}


pub struct Cols_sub {
    pub n: usize,
    pub adsh: Vec<String>,
    pub cik: Vec<u32>,
    pub name: Vec<String>,
    pub sic: Vec<u32>,
    pub countryba: Vec<String>,
    pub stprba: Vec<String>,
    pub cityba: Vec<String>,
    pub countryinc: Vec<String>,
    pub form: Vec<String>,
    pub period: Vec<u32>,
    pub fy: Vec<u32>,
    pub fp: Vec<String>,
    pub filed: Vec<u32>,
    pub accepted: Vec<String>,
    pub prevrpt: Vec<u32>,
    pub nciks: Vec<u32>,
    pub afs: Vec<String>,
    pub wksi: Vec<u32>,
    pub fye: Vec<String>,
    pub instance: Vec<String>,
}

impl Cols_sub {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_cik(self, i: int) -> u32 {
        self.cik[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_cik_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_cik(i as int),
    {
        self.cik[i]
    }
    pub open spec fn get_name(self, i: int) -> Seq<char> {
        self.name[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_name_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_name(i as int),
    {
        self.name[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_name(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_name(i as int) == lit@),
    {
        self.name[i] == lit
    }
    pub open spec fn get_sic(self, i: int) -> u32 {
        self.sic[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_sic_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_sic(i as int),
    {
        self.sic[i]
    }
    pub open spec fn get_countryba(self, i: int) -> Seq<char> {
        self.countryba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryba(i as int),
    {
        self.countryba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryba(i as int) == lit@),
    {
        self.countryba[i] == lit
    }
    pub open spec fn get_stprba(self, i: int) -> Seq<char> {
        self.stprba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_stprba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_stprba(i as int),
    {
        self.stprba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_stprba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_stprba(i as int) == lit@),
    {
        self.stprba[i] == lit
    }
    pub open spec fn get_cityba(self, i: int) -> Seq<char> {
        self.cityba[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_cityba_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_cityba(i as int),
    {
        self.cityba[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_cityba(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_cityba(i as int) == lit@),
    {
        self.cityba[i] == lit
    }
    pub open spec fn get_countryinc(self, i: int) -> Seq<char> {
        self.countryinc[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_countryinc_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_countryinc(i as int),
    {
        self.countryinc[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_countryinc(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_countryinc(i as int) == lit@),
    {
        self.countryinc[i] == lit
    }
    pub open spec fn get_form(self, i: int) -> Seq<char> {
        self.form[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_form_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_form(i as int),
    {
        self.form[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_form(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_form(i as int) == lit@),
    {
        self.form[i] == lit
    }
    pub open spec fn get_period(self, i: int) -> u32 {
        self.period[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_period_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_period(i as int),
    {
        self.period[i]
    }
    pub open spec fn get_fy(self, i: int) -> u32 {
        self.fy[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_fy_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_fy(i as int),
    {
        self.fy[i]
    }
    pub open spec fn get_fp(self, i: int) -> Seq<char> {
        self.fp[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_fp_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_fp(i as int),
    {
        self.fp[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_fp(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_fp(i as int) == lit@),
    {
        self.fp[i] == lit
    }
    pub open spec fn get_filed(self, i: int) -> u32 {
        self.filed[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_filed_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_filed(i as int),
    {
        self.filed[i]
    }
    pub open spec fn get_accepted(self, i: int) -> Seq<char> {
        self.accepted[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_accepted_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_accepted(i as int),
    {
        self.accepted[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_accepted(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_accepted(i as int) == lit@),
    {
        self.accepted[i] == lit
    }
    pub open spec fn get_prevrpt(self, i: int) -> u32 {
        self.prevrpt[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_prevrpt_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_prevrpt(i as int),
    {
        self.prevrpt[i]
    }
    pub open spec fn get_nciks(self, i: int) -> u32 {
        self.nciks[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_nciks_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_nciks(i as int),
    {
        self.nciks[i]
    }
    pub open spec fn get_afs(self, i: int) -> Seq<char> {
        self.afs[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_afs_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_afs(i as int),
    {
        self.afs[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_afs(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_afs(i as int) == lit@),
    {
        self.afs[i] == lit
    }
    pub open spec fn get_wksi(self, i: int) -> u32 {
        self.wksi[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_wksi_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_wksi(i as int),
    {
        self.wksi[i]
    }
    pub open spec fn get_fye(self, i: int) -> Seq<char> {
        self.fye[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_fye_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_fye(i as int),
    {
        self.fye[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_fye(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_fye(i as int) == lit@),
    {
        self.fye[i] == lit
    }
    pub open spec fn get_instance(self, i: int) -> Seq<char> {
        self.instance[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_instance_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_instance(i as int),
    {
        self.instance[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_instance(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_instance(i as int) == lit@),
    {
        self.instance[i] == lit
    }
}


pub open spec fn valid_cols_sub(cols: &Cols_sub) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.cik.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.cik[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.name@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.name[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.sic.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.sic[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.countryba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.stprba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.stprba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.cityba@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.cityba[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.countryinc@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.countryinc[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.form@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.form[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.period.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.period[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fy.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.fy[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fp@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.fp[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.filed.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.filed[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.accepted@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.accepted[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.prevrpt.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.prevrpt[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.nciks.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.nciks[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.afs@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.afs[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.wksi.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.wksi[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.fye@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.fye[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.instance@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.instance[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub struct Cols_num {
    pub n: usize,
    pub adsh: Vec<String>,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub ddate: Vec<u32>,
    pub qtrs: Vec<u32>,
    pub uom: Vec<String>,
    pub coreg: Vec<String>,
    pub value: Vec<u64>,
    pub footnote: Vec<String>,
}

impl Cols_num {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_ddate(self, i: int) -> u32 {
        self.ddate[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_ddate_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_ddate(i as int),
    {
        self.ddate[i]
    }
    pub open spec fn get_qtrs(self, i: int) -> u32 {
        self.qtrs[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_qtrs_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_qtrs(i as int),
    {
        self.qtrs[i]
    }
    pub open spec fn get_uom(self, i: int) -> Seq<char> {
        self.uom[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_uom_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_uom(i as int),
    {
        self.uom[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_uom(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_uom(i as int) == lit@),
    {
        self.uom[i] == lit
    }
    pub open spec fn get_coreg(self, i: int) -> Seq<char> {
        self.coreg[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_coreg_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_coreg(i as int),
    {
        self.coreg[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_coreg(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_coreg(i as int) == lit@),
    {
        self.coreg[i] == lit
    }
    pub open spec fn get_value(self, i: int) -> u64 {
        self.value[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_value_exec(&self, i: usize) -> (res: u64)
        requires i < self.n,
        ensures res == self.get_value(i as int),
    {
        self.value[i]
    }
    pub open spec fn get_footnote(self, i: int) -> Seq<char> {
        self.footnote[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_footnote_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_footnote(i as int),
    {
        self.footnote[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_footnote(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_footnote(i as int) == lit@),
    {
        self.footnote[i] == lit
    }
}


pub open spec fn valid_cols_num(cols: &Cols_num) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.ddate.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.ddate[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.qtrs.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.qtrs[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.uom@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.uom[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.coreg@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.coreg[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.value.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.value[i] < LEMMA_MAX_MONEY_U64
    &&& cols.footnote@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.footnote[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub struct Cols_tag {
    pub n: usize,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub custom: Vec<u32>,
    pub r#abstract: Vec<u32>,
    pub datatype: Vec<String>,
    pub iord: Vec<String>,
    pub crdr: Vec<String>,
    pub tlabel: Vec<String>,
    pub doc: Vec<String>,
}

impl Cols_tag {
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_custom(self, i: int) -> u32 {
        self.custom[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_custom_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_custom(i as int),
    {
        self.custom[i]
    }
    pub open spec fn get_abstract(self, i: int) -> u32 {
        self.r#abstract[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_abstract_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_abstract(i as int),
    {
        self.r#abstract[i]
    }
    pub open spec fn get_datatype(self, i: int) -> Seq<char> {
        self.datatype[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_datatype_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_datatype(i as int),
    {
        self.datatype[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_datatype(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_datatype(i as int) == lit@),
    {
        self.datatype[i] == lit
    }
    pub open spec fn get_iord(self, i: int) -> Seq<char> {
        self.iord[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_iord_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_iord(i as int),
    {
        self.iord[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_iord(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_iord(i as int) == lit@),
    {
        self.iord[i] == lit
    }
    pub open spec fn get_crdr(self, i: int) -> Seq<char> {
        self.crdr[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_crdr_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_crdr(i as int),
    {
        self.crdr[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_crdr(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_crdr(i as int) == lit@),
    {
        self.crdr[i] == lit
    }
    pub open spec fn get_tlabel(self, i: int) -> Seq<char> {
        self.tlabel[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tlabel_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tlabel(i as int),
    {
        self.tlabel[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tlabel(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tlabel(i as int) == lit@),
    {
        self.tlabel[i] == lit
    }
    pub open spec fn get_doc(self, i: int) -> Seq<char> {
        self.doc[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_doc_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_doc(i as int),
    {
        self.doc[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_doc(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_doc(i as int) == lit@),
    {
        self.doc[i] == lit
    }
}


pub open spec fn valid_cols_tag(cols: &Cols_tag) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.custom.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.custom[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.r#abstract.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.r#abstract[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.datatype@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.datatype[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.iord@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.iord[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.crdr@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.crdr[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.tlabel@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tlabel[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.doc@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.doc[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub struct Cols_pre {
    pub n: usize,
    pub adsh: Vec<String>,
    pub report: Vec<u32>,
    pub line: Vec<u32>,
    pub stmt: Vec<String>,
    pub inpth: Vec<u32>,
    pub rfile: Vec<String>,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub plabel: Vec<String>,
    pub negating: Vec<u32>,
}

impl Cols_pre {
    pub open spec fn get_adsh(self, i: int) -> Seq<char> {
        self.adsh[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_adsh_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_adsh(i as int),
    {
        self.adsh[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_adsh(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_adsh(i as int) == lit@),
    {
        self.adsh[i] == lit
    }
    pub open spec fn get_report(self, i: int) -> u32 {
        self.report[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_report_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_report(i as int),
    {
        self.report[i]
    }
    pub open spec fn get_line(self, i: int) -> u32 {
        self.line[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_line_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_line(i as int),
    {
        self.line[i]
    }
    pub open spec fn get_stmt(self, i: int) -> Seq<char> {
        self.stmt[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_stmt_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_stmt(i as int),
    {
        self.stmt[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_stmt(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_stmt(i as int) == lit@),
    {
        self.stmt[i] == lit
    }
    pub open spec fn get_inpth(self, i: int) -> u32 {
        self.inpth[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_inpth_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_inpth(i as int),
    {
        self.inpth[i]
    }
    pub open spec fn get_rfile(self, i: int) -> Seq<char> {
        self.rfile[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_rfile_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_rfile(i as int),
    {
        self.rfile[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_rfile(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_rfile(i as int) == lit@),
    {
        self.rfile[i] == lit
    }
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_plabel(self, i: int) -> Seq<char> {
        self.plabel[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_plabel_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_plabel(i as int),
    {
        self.plabel[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_plabel(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_plabel(i as int) == lit@),
    {
        self.plabel[i] == lit
    }
    pub open spec fn get_negating(self, i: int) -> u32 {
        self.negating[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_negating_exec(&self, i: usize) -> (res: u32)
        requires i < self.n,
        ensures res == self.get_negating(i as int),
    {
        self.negating[i]
    }
}


pub open spec fn valid_cols_pre(cols: &Cols_pre) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.adsh@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.adsh[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.report.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.report[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.line.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.line[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.stmt@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.stmt[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.inpth.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.inpth[i] < LEMMA_MAX_NATIVE_U32
    &&& cols.rfile@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.rfile[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.plabel@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.plabel[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.negating.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.negating[i] < LEMMA_MAX_NATIVE_U32
}

pub open spec fn multi_agg_helper(num: &Cols_num, sub: &Cols_sub, tag: &Cols_tag, pre: &Cols_pre, i0: int, i1: int, i2: int, i3: int) -> (res: Map<(Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), (u64, u64)>)
    decreases num.n - i0, sub.n - i1, tag.n - i2, pre.n - i3,
{
    if i0 < num.n {
        if i1 < sub.n {
            if i2 < tag.n {
                if i3 < pre.n {
                    let tail = multi_agg_helper(num, sub, tag, pre, i0, i1, i2, i3 + 1);
                    if (num.adsh[i0 as int]@ == sub.adsh[i1 as int]@ && num.tag[i0 as int]@ == tag.tag[i2 as int]@ && num.version[i0 as int]@ == tag.version[i2 as int]@ && num.adsh[i0 as int]@ == pre.adsh[i3 as int]@ && num.tag[i0 as int]@ == pre.tag[i3 as int]@ && num.version[i0 as int]@ == pre.version[i3 as int]@) && (((((num.uom[i0 as int]@ == "shares"@ && sub.form[i1 as int]@ == "10-K"@) && pre.stmt[i3 as int]@ == "BS"@) && true) && tag.r#abstract[i2 as int] == 0)) {
                        let key = (sub.name[i1 as int]@, sub.sic[i1 as int], tag.tlabel[i2 as int]@, pre.stmt[i3 as int]@, pre.plabel[i3 as int]@);
            let prev = if tail.contains_key(key) { tail[key] } else { (0u64, 0u64) };
            let s0 = (prev.0 as int + num.value[i0 as int] as int) as u64;
            let s1 = (prev.1 as int + 1) as u64;
            tail.insert(key, (s0, s1))
                    } else {
                        tail
                    }
                } else {
                    multi_agg_helper(num, sub, tag, pre, i0, i1, i2 + 1, 0)
                }
            } else {
                multi_agg_helper(num, sub, tag, pre, i0, i1 + 1, 0, 0)
            }
        } else {
            multi_agg_helper(num, sub, tag, pre, i0 + 1, 0, 0, 0)
        }
    } else {
        Map::empty()
    }
}

pub open spec fn apply_having_filter<K, V>(m: Map<K, V>, pred: spec_fn(K, V) -> bool) -> Map<K, V> {
    m.filter_keys(|k| pred(k, m[k]))
}

pub open spec fn method_spec(num: &Cols_num, sub: &Cols_sub, tag: &Cols_tag, pre: &Cols_pre) -> Map<(Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), (u64, u64)>
    recommends
        valid_cols_num(num),
        valid_cols_sub(sub),
        valid_cols_tag(tag),
        valid_cols_pre(pre),
{
    {
    let m = {
        let raw = multi_agg_helper(num, sub, tag, pre, 0, 0, 0, 0);
    raw.map_values(|v: (u64, u64)| (v.0, v.1))
    };
    apply_having_filter(m, |k: (Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), v: (u64, u64)| (v.1 > 1))
}
}

// Note: ORDER BY (total_value DESC), LIMIT 1000, OFFSET 0 are not part of method_spec (((Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), (u64, u64))); agent may apply in run_query.
// === Agent: use TRUSTED helpers below for opaque views.
// Maps: agg_new_* / agg_add_* (wrapping) / agg_put_* (set projected tuple).
// Multi-agg steps: agg_step_state_new_* / agg_step_* (+ agg_step_apply_row_* spec).
// HAVING: host post-filter exec helper (ensures vs apply_having_filter).
// Distinct sets: hashset_*_view + set_new_* / set_insert_* (COUNT_DISTINCT state).
// Seqs: seq_new_* / seq_push_* when present. Raw HashMap::new()/Vec::new()
// will not prove against opaque hashmap_*/vec_*_view.
// === TRUSTED structural map helpers (view + agg_new + agg_put/agg_add) ===
#[verifier::external_body]
pub open spec fn hashmap_str_u32_str_str_str__u64_u64_view(hm: Map<(String, u32, String, String, String), (u64, u64)>) -> Map<(Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), (u64, u64)> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn agg_new_str_u32_str_str_str__u64_u64() -> (hm: HashMap<(String, u32, String, String, String), (u64, u64)>)
    ensures hashmap_str_u32_str_str_str__u64_u64_view(hm@) == Map::empty(),
{
    HashMap::new()
}

#[verifier::external_body]
pub exec fn agg_put_str_u32_str_str_str__u64_u64(hm: &mut HashMap<(String, u32, String, String, String), (u64, u64)>, k0: &str, k1: u32, k2: &str, k3: &str, k4: &str, v0: u64, v1: u64)
    ensures hashmap_str_u32_str_str_str__u64_u64_view(final(hm)@) == hashmap_str_u32_str_str_str__u64_u64_view(old(hm)@).insert((k0@, k1, k2@, k3@, k4@), (v0, v1)),
{
    let key = (k0.to_string(), k1, k2.to_string(), k3.to_string(), k4.to_string());
    hm.insert(key, (v0, v1));
}

#[verifier::external_body]
pub exec fn agg_add_str_u32_str_str_str__u64_u64(hm: &mut HashMap<(String, u32, String, String, String), (u64, u64)>, k0: &str, k1: u32, k2: &str, k3: &str, k4: &str, d0: u64, d1: u64)
    ensures
        hashmap_str_u32_str_str_str__u64_u64_view(final(hm)@) == hashmap_str_u32_str_str_str__u64_u64_view(old(hm)@).insert(
        (k0@, k1, k2@, k3@, k4@),
        (if hashmap_str_u32_str_str_str__u64_u64_view(old(hm)@).contains_key((k0@, k1, k2@, k3@, k4@)) {
            (hashmap_str_u32_str_str_str__u64_u64_view(old(hm)@)[(k0@, k1, k2@, k3@, k4@)].0 as int + d0 as int) as u64
        } else {
            d0
        }, if hashmap_str_u32_str_str_str__u64_u64_view(old(hm)@).contains_key((k0@, k1, k2@, k3@, k4@)) {
            (hashmap_str_u32_str_str_str__u64_u64_view(old(hm)@)[(k0@, k1, k2@, k3@, k4@)].1 as int + d1 as int) as u64
        } else {
            d1
        }),
    ),
{
    let key = (k0.to_string(), k1, k2.to_string(), k3.to_string(), k4.to_string());
    let prev = hm.get(&key).copied().unwrap_or((0u64, 0u64));
    hm.insert(key, (prev.0.wrapping_add(d0), prev.1.wrapping_add(d1)));
}

// === TRUSTED distinct-set helpers (str: HashSet exec ↔ Map spec view) ===
#[verifier::external_body]
pub open spec fn hashset_str_view(s: Set<String>) -> Map<Seq<char>, bool> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn set_new_str() -> (s: HashSet<String>)
    ensures hashset_str_view(s@) == Map::empty(),
{
    HashSet::new()
}

#[verifier::external_body]
pub exec fn set_insert_str(s: &mut HashSet<String>, k: &str) -> (is_new: bool)
    ensures
        hashset_str_view(final(s)@).contains_key(k@),
        hashset_str_view(final(s)@) == hashset_str_view(old(s)@).insert(k@, true),
        is_new == !hashset_str_view(old(s)@).contains_key(k@),
        is_new ==> hashset_str_view(final(s)@).dom().len() == hashset_str_view(old(s)@).dom().len() + 1,
        !is_new ==> hashset_str_view(final(s)@).dom().len() == hashset_str_view(old(s)@).dom().len(),
{
    let is_new = !s.contains(k);
    s.insert(k.to_string());
    is_new
}

// === TRUSTED distinct-set helpers (u32: HashSet exec ↔ Map spec view) ===
#[verifier::external_body]
pub open spec fn hashset_u32_view(s: Set<u32>) -> Map<u32, bool> {
    arbitrary()
}

#[verifier::external_body]
pub exec fn set_new_u32() -> (s: HashSet<u32>)
    ensures hashset_u32_view(s@) == Map::empty(),
{
    HashSet::new()
}

#[verifier::external_body]
pub exec fn set_insert_u32(s: &mut HashSet<u32>, k: u32) -> (is_new: bool)
    ensures
        hashset_u32_view(final(s)@).contains_key(k),
        hashset_u32_view(final(s)@) == hashset_u32_view(old(s)@).insert(k, true),
        is_new == !hashset_u32_view(old(s)@).contains_key(k),
        is_new ==> hashset_u32_view(final(s)@).dom().len() == hashset_u32_view(old(s)@).dom().len() + 1,
        !is_new ==> hashset_u32_view(final(s)@).dom().len() == hashset_u32_view(old(s)@).dom().len(),
{
    let is_new = !s.contains(&k);
    s.insert(k);
    is_new
}

// === Multi-agg group step (str_u32_str_str_str__u64_u64): inner HashMap + projected map ===
pub struct AggStepState_str_u32_str_str_str__u64_u64 {
    pub projected: HashMap<(String, u32, String, String, String), (u64, u64)>,
    pub inner: HashMap<(String, u32, String, String, String), (u64, u64)>,
}

#[verifier::external_body]
pub open spec fn agg_step_inner_str_u32_str_str_str__u64_u64_view(hm: Map<(String, u32, String, String, String), (u64, u64)>) -> Map<(Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), (u64, u64)> {
    arbitrary()
}

pub open spec fn agg_step_project_str_u32_str_str_str__u64_u64(v: (u64, u64)) -> (u64, u64) {
    (v.0, v.1)
}

pub open spec fn agg_step_apply_row_str_u32_str_str_str__u64_u64(prev: (u64, u64), row_u64_0: u64) -> (u64, u64) {
    let s0 = (prev.0 as int + (row_u64_0 as int) as int) as u64;
    let s1 = (prev.1 as int + 1) as u64;
    (s0, s1)
}

#[verifier::external_body]
pub exec fn agg_step_state_new_str_u32_str_str_str__u64_u64() -> (st: AggStepState_str_u32_str_str_str__u64_u64)
    ensures
        hashmap_str_u32_str_str_str__u64_u64_view(st.projected@) == Map::empty(),
        agg_step_inner_str_u32_str_str_str__u64_u64_view(st.inner@) == Map::empty(),
{
    AggStepState_str_u32_str_str_str__u64_u64 { projected: HashMap::new(), inner: HashMap::new() }
}

#[verifier::external_body]
pub exec fn agg_step_str_u32_str_str_str__u64_u64(
    st: &mut AggStepState_str_u32_str_str_str__u64_u64,
    k0: &str, k1: u32, k2: &str, k3: &str, k4: &str, row_u64_0: u64,
)
    ensures
        ({
            let spec_key = (k0@, k1, k2@, k3@, k4@);
            let old_inner = agg_step_inner_str_u32_str_str_str__u64_u64_view(old(st).inner@);
            let prev_inner = if old_inner.contains_key(spec_key) {
                old_inner[spec_key]
            } else {
                (0u64, 0u64)
            };
            let new_inner = agg_step_apply_row_str_u32_str_str_str__u64_u64(prev_inner, row_u64_0);
            &&& agg_step_inner_str_u32_str_str_str__u64_u64_view(final(st).inner@) == old_inner.insert(spec_key, new_inner)
            &&& hashmap_str_u32_str_str_str__u64_u64_view(final(st).projected@) == hashmap_str_u32_str_str_str__u64_u64_view(old(st).projected@).insert(
                spec_key,
                agg_step_project_str_u32_str_str_str__u64_u64(new_inner),
            )
        }),
{
    let key = (k0.to_string(), k1, k2.to_string(), k3.to_string(), k4.to_string());
    let prev = st.inner.get(&key).cloned().unwrap_or((0u64, 0u64));
    let v0 = prev.0.wrapping_add(row_u64_0);
    let v1 = prev.1.wrapping_add(1);
    let new_inner = (v0, v1);
    st.inner.insert(key.clone(), new_inner.clone());
    st.projected.insert(key, (new_inner.0, new_inner.1));
}

// === HAVING post-filter (str_u32_str_str_str__u64_u64): exec HashMap retain vs apply_having_filter ===
#[verifier::external_body]
pub exec fn apply_having_filter_exec_str_u32_str_str_str__u64_u64(
    hm: HashMap<(String, u32, String, String, String), (u64, u64)>,
) -> (res: HashMap<(String, u32, String, String, String), (u64, u64)>)
    ensures
        hashmap_str_u32_str_str_str__u64_u64_view(res@)
            == apply_having_filter(
                hashmap_str_u32_str_str_str__u64_u64_view(hm@),
                |k: (Seq<char>, u32, Seq<char>, Seq<char>, Seq<char>), v: (u64, u64)| (v.1 > 1),
            ),
{
    hm.into_iter()
        .filter(|(_k, v)| (v.1 > 1))
        .collect()
}
} // verus!
