//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.name, p.stmt, n.tag, p.plabel,
//!          SUM(n.value) AS total_value, COUNT(*) AS cnt
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   JOIN pre p ON n.adsh = p.adsh AND n.tag = p.tag AND n.version = p.version
//!   WHERE n.uom = 'USD' AND p.stmt = 'IS' AND s.fy = 2024
//!         AND n.value IS NOT NULL
//!   GROUP BY s.name, p.stmt, n.tag, p.plabel
//!   ORDER BY total_value DESC
//!   LIMIT 200;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, Seq<char>, Seq<char>, Seq<char>), (u64, u64)>
// Trusted exec↔spec views in context/ro/spec.rs (use one in ensures): hashmap_str_str_str_str__u64_u64_view
// Nested reverse scan matches multi_agg_helper; ORDER BY/LIMIT are outside method_spec.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub, pre: &Cols_pre) -> (res: HashMap<(String, String, String, String), (u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub), valid_cols_pre(pre),
    ensures hashmap_str_str_str_str__u64_u64_view(res@) == method_spec(num, sub, pre),
{
    let mut st = agg_step_state_new_str_str_str_str__u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    let mut i2: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            i2 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            valid_cols_pre(pre),
            agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                == multi_agg_helper(num, sub, pre, i0 as int, 0, 0),
            hashmap_str_str_str_str__u64_u64_view(st.projected@)
                == agg_step_inner_str_str_str_str__u64_u64_view(st.inner@).map_values(
                    |v: (u64, u64)| agg_step_project_str_str_str_str__u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, pre, i0 as int, sub.n as int, 0)
                == multi_agg_helper(num, sub, pre, (i0 + 1) as int, 0, 0));
            assert(agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                == multi_agg_helper(num, sub, pre, i0 as int, i1 as int, 0));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                i2 == 0,
                valid_cols_num(num),
                valid_cols_sub(sub),
                valid_cols_pre(pre),
                agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                    == multi_agg_helper(num, sub, pre, i0 as int, i1 as int, 0),
                hashmap_str_str_str_str__u64_u64_view(st.projected@)
                    == agg_step_inner_str_str_str_str__u64_u64_view(st.inner@).map_values(
                        |v: (u64, u64)| agg_step_project_str_str_str_str__u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            i2 = pre.n;
            proof {
                assert(multi_agg_helper(num, sub, pre, i0 as int, i1 as int, pre.n as int)
                    == multi_agg_helper(num, sub, pre, i0 as int, (i1 + 1) as int, 0));
                assert(agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                    == multi_agg_helper(num, sub, pre, i0 as int, i1 as int, i2 as int));
            }
            while i2 > 0
                invariant
                    i0 < num.n,
                    i1 < sub.n,
                    i2 <= pre.n,
                    valid_cols_num(num),
                    valid_cols_sub(sub),
                    valid_cols_pre(pre),
                    agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                        == multi_agg_helper(num, sub, pre, i0 as int, i1 as int, i2 as int),
                    hashmap_str_str_str_str__u64_u64_view(st.projected@)
                        == agg_step_inner_str_str_str_str__u64_u64_view(st.inner@).map_values(
                            |v: (u64, u64)| agg_step_project_str_str_str_str__u64_u64(v),
                        ),
                decreases i2,
            {
                i2 = i2 - 1;
                let adsh_s = sub.get_adsh_exec(i1);
                let adsh_p = pre.get_adsh_exec(i2);
                let tag_p = pre.get_tag_exec(i2);
                let ver_p = pre.get_version_exec(i2);
                let fy_s = sub.get_fy_exec(i1);
                if num.eq_at_adsh(i0, adsh_s.as_str())
                    && num.eq_at_adsh(i0, adsh_p.as_str())
                    && num.eq_at_tag(i0, tag_p.as_str())
                    && num.eq_at_version(i0, ver_p.as_str())
                    && num.eq_at_uom(i0, "USD")
                    && pre.eq_at_stmt(i2, "IS")
                    && fy_s == 2024
                {
                    let name = sub.get_name_exec(i1);
                    let stmt = pre.get_stmt_exec(i2);
                    let tag = num.get_tag_exec(i0);
                    let plabel = pre.get_plabel_exec(i2);
                    let value = num.get_value_exec(i0);
                    agg_step_str_str_str_str__u64_u64(
                        &mut st,
                        name.as_str(),
                        stmt.as_str(),
                        tag.as_str(),
                        plabel.as_str(),
                        value,
                    );
                    proof {
                        let ghost tail = multi_agg_helper(
                            num, sub, pre, i0 as int, i1 as int, (i2 + 1) as int,
                        );
                        let ghost key = (
                            sub.name[i1 as int]@,
                            pre.stmt[i2 as int]@,
                            num.tag[i0 as int]@,
                            pre.plabel[i2 as int]@,
                        );
                        let ghost prev = if tail.contains_key(key) {
                            tail[key]
                        } else {
                            (0u64, 0u64)
                        };
                        let ghost expected = agg_step_apply_row_str_str_str_str__u64_u64(
                            prev,
                            num.value[i0 as int] as u64,
                        );
                        assert(expected == multi_agg_helper(
                            num, sub, pre, i0 as int, i1 as int, i2 as int,
                        )[key]);
                        assert(
                            agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                                == multi_agg_helper(
                                    num, sub, pre, i0 as int, i1 as int, i2 as int,
                                )
                        );
                    }
                } else {
                    proof {
                        assert(
                            multi_agg_helper(
                                num, sub, pre, i0 as int, i1 as int, i2 as int,
                            )
                                == multi_agg_helper(
                                    num, sub, pre, i0 as int, i1 as int, (i2 + 1) as int,
                                )
                        );
                    }
                }
            }
            proof {
                assert(i2 == 0);
                assert(
                    agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                        == multi_agg_helper(num, sub, pre, i0 as int, i1 as int, 0)
                );
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
                    == multi_agg_helper(num, sub, pre, i0 as int, 0, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_str_str_str__u64_u64_view(st.inner@)
            == multi_agg_helper(num, sub, pre, 0, 0, 0));
        assert(
            hashmap_str_str_str_str__u64_u64_view(st.projected@)
                == multi_agg_helper(num, sub, pre, 0, 0, 0).map_values(
                    |v: (u64, u64)| agg_step_project_str_str_str_str__u64_u64(v),
                )
        );
        assert(
            hashmap_str_str_str_str__u64_u64_view(st.projected@)
                == multi_agg_helper(num, sub, pre, 0, 0, 0).map_values(
                    |v: (u64, u64)| (v.0, v.1),
                )
        );
    }
    st.projected
}
// AGENT_EDIT_END

} // verus!
