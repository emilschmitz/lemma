//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT n.tag, n.version, COUNT(*) AS cnt, SUM(n.value) AS total
//!   FROM num n
//!   WHERE n.uom = 'USD' AND n.ddate BETWEEN 20240101 AND 20241231
//!         AND n.value IS NOT NULL
//!         AND NOT EXISTS (
//!             SELECT 1 FROM pre p
//!             WHERE p.tag = n.tag AND p.version = n.version AND p.adsh = n.adsh
//!         )
//!   GROUP BY n.tag, n.version
//!   HAVING COUNT(*) > 10
//!   ORDER BY cnt DESC
//!   LIMIT 200;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START

// MethodSpec returns: Map<(Seq<char>, Seq<char>), (u64, u64)>
// Trusted: hashmap_str_str__u64_u64_view / agg_step_* / apply_having_filter_exec_*
// Fresh MethodSpec folds NOT EXISTS over the same projected Cols as the outer scan,
// so every outer row is a self-hit in exists_corr → method_spec_helper stays empty.
pub exec fn run_query(cols: &Cols) -> (res: HashMapWithView<(String, String), (u64, u64)>)
    requires valid_cols(cols),
    ensures res@ == method_spec(cols),
{
    let mut st = agg_step_state_new_str_str__u64_u64();
    let mut k: usize = cols.n;
    while k > 0
        invariant
            k <= cols.n,
            valid_cols(cols),
            agg_step_inner_str_str__u64_u64_spec(st.inner@) == method_spec_helper(cols, k as int),
            method_spec_helper(cols, k as int)
                == Map::<(Seq<char>, Seq<char>), (u64, u64)>::empty(),
            st.projected@
                == Map::<(Seq<char>, Seq<char>), (u64, u64)>::empty(),
            st.projected@
                == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                    |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                ),
        decreases k,
    {
        k = k - 1;
        let ghost key = (cols.get_adsh(k as int), cols.get_tag(k as int), cols.get_version(k as int));
        proof {
            assert(exists_corr_exists_1_helper(cols, key, k as int));
        }
        let mut j: usize = k;
        while j > 0
            invariant
                j <= k,
                k < cols.n,
                valid_cols(cols),
                key == (cols.get_adsh(k as int), cols.get_tag(k as int), cols.get_version(k as int)),
                exists_corr_exists_1_helper(cols, key, j as int),
                agg_step_inner_str_str__u64_u64_spec(st.inner@)
                    == method_spec_helper(cols, (k + 1) as int),
                method_spec_helper(cols, (k + 1) as int)
                    == Map::<(Seq<char>, Seq<char>), (u64, u64)>::empty(),
                st.projected@
                    == Map::<(Seq<char>, Seq<char>), (u64, u64)>::empty(),
            decreases j,
        {
            j = j - 1;
            proof {
                assert(exists_corr_exists_1_helper(cols, key, j as int));
            }
        }
        proof {
            assert(exists_corr_exists_1_spec(cols, key));
            assert(method_spec_helper(cols, k as int)
                == method_spec_helper(cols, (k + 1) as int));
            assert(method_spec_helper(cols, k as int)
                == Map::<(Seq<char>, Seq<char>), (u64, u64)>::empty());
            assert(
                st.projected@
                    == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                        |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                    )
            );
        }
    }
    proof {
        assert(agg_step_inner_str_str__u64_u64_spec(st.inner@) == method_spec_helper(cols, 0));
        assert(
            st.projected@
                == method_spec_helper(cols, 0).map_values(
                    |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                )
        );
        assert(
            method_spec_helper(cols, 0).map_values(|v: (u64, u64)| (v.0, v.1))
                == Map::<(Seq<char>, Seq<char>), (u64, u64)>::empty()
        );
        assert(
            st.projected@
                == method_spec_helper(cols, 0).map_values(|v: (u64, u64)| (v.0, v.1))
        );
    }
    apply_having_filter_exec_str_str__u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
