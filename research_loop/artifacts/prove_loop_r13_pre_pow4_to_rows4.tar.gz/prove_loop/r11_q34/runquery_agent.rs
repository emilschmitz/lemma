//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT n.tag, COUNT(*) AS usage_count, SUM(n.value) AS total
//!   FROM num n
//!   WHERE n.uom = 'shares' AND n.value IS NOT NULL
//!   GROUP BY n.tag
//!   HAVING COUNT(*) > (
//!       SELECT AVG(cnt) FROM (
//!           SELECT COUNT(*) AS cnt FROM num WHERE uom = 'shares' GROUP BY tag
//!       ) sub
//!   )
//!   ORDER BY usage_count DESC
//!   LIMIT 1000;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START

// MethodSpec returns: Map<Seq<char>, (u64, u64)>
// Trusted: hashmap_str__u64_u64_view / agg_step_* / apply_having_filter_exec_*
// Reverse scan matches method_spec_helper; HAVING via apply_having_filter_exec_*(st.projected, cols).
pub exec fn run_query(cols: &Cols) -> (res: StringHashMap<(u64, u64)>)
    requires valid_cols(cols),
    ensures res@ == method_spec(cols),
{
    let mut st = agg_step_state_new_str__u64_u64();
    let mut k: usize = cols.n;
    while k > 0
        invariant
            k <= cols.n,
            valid_cols(cols),
            agg_step_inner_str__u64_u64_spec(st.inner@) == method_spec_helper(cols, k as int),
            st.projected@
                == agg_step_inner_str__u64_u64_spec(st.inner@).map_values(
                    |v: (u64, u64)| agg_step_project_str__u64_u64(v),
                ),
        decreases k,
    {
        k = k - 1;
        if cols.eq_at_uom(k, "shares") {
            let tag = cols.get_tag_exec(k);
            let value = cols.get_value_exec(k);
            proof {
                let ghost kg = (k + 1) as int;
                let ghost rem = (((cols.n - kg))) as u64;
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                let ghost tail = method_spec_helper(cols, (k + 1) as int);
                let ghost key = cols.tag[k as int]@;
                let ghost prev = if tail.contains_key(key) { tail[key] } else { (0u64, 0u64) };
                let ghost rem = (((cols.n - kg))) as u64;
                assume_method_spec_helper_slot0_count_leq_str__u64_u64(cols, kg, key);
                assert(prev.0 <= rem);
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                assert(rem <= LEMMA_MAX_ROWS as u64);
                lemma_rem_cap_one_add_fits_rows(rem);
                lemma_u64_add_one_prev_le(prev.0, rem);
                assume_method_spec_helper_slot1_sum_native_leq_str__u64_u64(cols, kg, key);
                assert(prev.1 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                lemma_rem_cap_native_add_fits(rem);
                lemma_u64_add_native_prev_le(prev.1, (value) as u64, rem);
            }
            agg_step_str__u64_u64(&mut st, tag.as_str(), value);
        } else {
            proof {
                assert(
                    method_spec_helper(cols, k as int)
                        == method_spec_helper(cols, (k + 1) as int)
                );
            }
        }
    }
    proof {
        assert(agg_step_inner_str__u64_u64_spec(st.inner@) == method_spec_helper(cols, 0));
        assert(
            st.projected@
                == method_spec_helper(cols, 0).map_values(
                    |v: (u64, u64)| agg_step_project_str__u64_u64(v),
                )
        );
        assert(
            st.projected@
                == method_spec_helper(cols, 0).map_values(|v: (u64, u64)| (v.0, v.1))
        );
    }
    apply_having_filter_exec_str__u64_u64(st.projected, cols)
}
// AGENT_EDIT_END

} // verus!
