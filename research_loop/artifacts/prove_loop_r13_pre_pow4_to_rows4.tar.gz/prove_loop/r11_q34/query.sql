SELECT n.tag, COUNT(*) AS usage_count, SUM(n.value) AS total
FROM num n
WHERE n.uom = 'shares' AND n.value IS NOT NULL
GROUP BY n.tag
HAVING COUNT(*) > (
    SELECT AVG(cnt) FROM (
        SELECT COUNT(*) AS cnt FROM num WHERE uom = 'shares' GROUP BY tag
    ) sub
)
ORDER BY usage_count DESC
LIMIT 1000;
