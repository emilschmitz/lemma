use vstd::prelude::*;
use std::collections::{HashMap, HashSet};

verus! {

// === Lemma global input bounds ===
pub const LEMMA_MAX_ROWS: usize = 65536;
pub const LEMMA_MAX_ROWS_CUBE: usize = 2047;
pub const LEMMA_MAX_ROWS_4: usize = 256;
pub const LEMMA_MAX_NATIVE_U32: u32 = 2147483648;
pub const LEMMA_MAX_STRING_LEN: usize = 128;
// Assumption-driven u64 cell cap (NOT implied by BIGINT type width).
pub const LEMMA_MAX_CELL_U64: u64 = 2147483648;
pub const LEMMA_MAX_MONEY_U64: u64 = LEMMA_MAX_CELL_U64;


// === Lemma global product bounds (host arithmetic) ===
#[verifier::external_body]
pub proof fn lemma_max_rows_times_native_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_sq_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_sq_times_native_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_NATIVE_U32 as int)
            <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS², then (rem_cap+1)·MONEY fits in u64 (uses join product bound).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS², then (rem_cap+1)·NATIVE_U32 fits (2-table join rem for SUM(native)).
#[verifier::external_body]
pub proof fn lemma_rem_cap_native_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

// ASSUMPTION (catalog/user): nested-loop rem ≤ ROWS² under valid_cols row caps.
// Not Verus-proved from fold induction — expert accepts under table assumptions.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_sq(
    n0: usize,
    n1: usize,
    i0: int,
    i1: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
    ensures
        ((n1 as int - i1) + (n0 as int - i0 - 1) * (n1 as int)) >= 0,
        (((n1 - i1) + (n0 - i0 - 1) * n1) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_cube_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_ROWS_CUBE as int)
            * (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_4_times_cell_u64_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_CELL_U64 as int)
            <= u64::MAX as int,
{
}

// rem_cap ≤ CUBE³ ⇒ (rem_cap+1)·MONEY fits (3-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS_4⁴ ⇒ (rem_cap+1)·MONEY fits (4-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS² ⇒ rem_cap+1 fits in u64 (COUNT / prev_le discharge).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS ⇒ rem_cap+1 fits (single-table suffix rem).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_rows(prev_cap: u64)
    requires
        prev_cap <= LEMMA_MAX_ROWS as u64,
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS³ ⇒ rem_cap+1 fits (3-table suffix rem with ROWS caps).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_pow3(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS⁴ ⇒ rem_cap+1 fits (4-table suffix rem with ROWS caps).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ CUBE³ ⇒ rem_cap+1 fits (3-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// rem_cap ≤ ROWS_4⁴ ⇒ rem_cap+1 fits (4-table nested loops).
#[verifier::external_body]
pub proof fn lemma_rem_cap_one_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int) + 1 <= u64::MAX as int,
{
}

// ASSUMPTION (catalog/user): 3-table nested rem ≤ CUBE³ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_cube(
    n0: usize,
    n1: usize,
    n2: usize,
    i0: int,
    i1: int,
    i2: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS_CUBE,
        n1 <= LEMMA_MAX_ROWS_CUBE,
        n2 <= LEMMA_MAX_ROWS_CUBE,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
    ensures
        ((n2 as int - i2)
            + (n1 as int - i1 - 1) * (n2 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int)) >= 0,
        (((n2 - i2) + (n1 - i1 - 1) * n2 + (n0 - i0 - 1) * n1 * n2) as u64)
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
{
}

// ASSUMPTION (catalog/user): 4-table nested rem ≤ ROWS_4⁴ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_join_nested_rem_leq_rows_4(
    n0: usize,
    n1: usize,
    n2: usize,
    n3: usize,
    i0: int,
    i1: int,
    i2: int,
    i3: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS_4,
        n1 <= LEMMA_MAX_ROWS_4,
        n2 <= LEMMA_MAX_ROWS_4,
        n3 <= LEMMA_MAX_ROWS_4,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
        0 <= i3 <= n3 as int,
    ensures
        ((n3 as int - i3)
            + (n2 as int - i2 - 1) * (n3 as int)
            + (n1 as int - i1 - 1) * (n2 as int) * (n3 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int) * (n3 as int)) >= 0,
        (((n3 - i3) + (n2 - i2 - 1) * n3 + (n1 - i1 - 1) * n2 * n3
            + (n0 - i0 - 1) * n1 * n2 * n3) as u64)
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
{
}

// ASSUMPTION (catalog/user): 3-table suffix rem ≤ ROWS³ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_fold_suffix_rem_leq_rows_pow3(
    n0: usize,
    n1: usize,
    n2: usize,
    i0: int,
    i1: int,
    i2: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        n2 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
    ensures
        (((n2 as int - i2) + (n1 as int - i1 - 1) * (n2 as int) + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int)) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

// ASSUMPTION (catalog/user): 4-table suffix rem ≤ ROWS⁴ under valid_cols row caps.
#[verifier::external_body]
pub proof fn assume_fold_suffix_rem_leq_rows_pow4(
    n0: usize,
    n1: usize,
    n2: usize,
    n3: usize,
    i0: int,
    i1: int,
    i2: int,
    i3: int,
)
    requires
        n0 <= LEMMA_MAX_ROWS,
        n1 <= LEMMA_MAX_ROWS,
        n2 <= LEMMA_MAX_ROWS,
        n3 <= LEMMA_MAX_ROWS,
        0 <= i0 <= n0 as int,
        0 <= i1 <= n1 as int,
        0 <= i2 <= n2 as int,
        0 <= i3 <= n3 as int,
    ensures
        (((n3 as int - i3) + (n2 as int - i2 - 1) * (n3 as int) + (n1 as int - i1 - 1) * (n2 as int) * (n3 as int)
            + (n0 as int - i0 - 1) * (n1 as int) * (n2 as int) * (n3 as int)) as u64)
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_cell_u64_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_native_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
{
}

// === Discharge add_u64 / agg_add_* / agg_step_* checked_add requires ===
// COUNT / AVG-denom: prev <= n rows processed so far.
pub proof fn lemma_u64_add_one_fit(prev: u64, n: usize)
    requires
        prev <= n as u64,
        n <= LEMMA_MAX_ROWS,
    ensures
        (prev as int) + 1 <= u64::MAX as int,
{
}

// SUM(native u32 cell): prev <= n * cell_cap, cell < cell_cap, n <= LEMMA_MAX_ROWS.
#[verifier::external_body]
pub proof fn lemma_u64_add_native_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_NATIVE_U32 as u64),
        cell < LEMMA_MAX_NATIVE_U32 as u64,
        n <= LEMMA_MAX_ROWS,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// SUM(money u64 cell): requires global product bound (honest gate when constants allow).
#[verifier::external_body]
pub proof fn lemma_u64_add_cell_u64_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_CELL_U64 as u64),
        cell < LEMMA_MAX_CELL_U64,
        n <= LEMMA_MAX_ROWS,
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// COUNT with an explicit row-suffix / join-rem cap (elementary: prev ≤ cap ⇒ prev+1 fits).
#[verifier::external_body]
pub proof fn lemma_u64_add_one_prev_le(prev: u64, prev_cap: u64)
    requires
        prev <= prev_cap,
        (prev_cap as int) + 1 <= u64::MAX as int,
    ensures
        (prev as int) + 1 <= u64::MAX as int,
{
}

// SUM(money) with explicit rem-cap: prev ≤ cap·M, cell < M, (cap+1)·M fits ⇒ prev+cell fits.
// Same *kind* of fact as bounded int add (checkable from constants when cap ≤ ROWS²).
#[verifier::external_body]
pub proof fn lemma_u64_add_cell_u64_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_CELL_U64 as u64),
        cell < LEMMA_MAX_CELL_U64,
        (prev_cap as int + 1) * (LEMMA_MAX_CELL_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

// Native SUM with rem-cap (same shape as money).
#[verifier::external_body]
pub proof fn lemma_u64_add_native_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_NATIVE_U32 as u64),
        cell < LEMMA_MAX_NATIVE_U32 as u64,
        (prev_cap as int + 1) * (LEMMA_MAX_NATIVE_U32 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}


// === Deprecated aliases (money → cell_u64); prefer cell_u64 names ===
pub proof fn lemma_max_rows_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
    lemma_max_rows_times_cell_u64_fits_u64();
}

pub proof fn lemma_max_rows_sq_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
    lemma_max_rows_sq_times_cell_u64_fits_u64();
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits(prev_cap: u64)
    requires
        prev_cap <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_u64_add_money_fit(prev: u64, cell: u64, n: usize)
    requires
        prev <= (n as u64) * (LEMMA_MAX_MONEY_U64 as u64),
        cell < LEMMA_MAX_MONEY_U64,
        n <= LEMMA_MAX_ROWS,
        (LEMMA_MAX_ROWS as int) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_u64_add_money_prev_le(prev: u64, cell: u64, prev_cap: u64)
    requires
        prev <= prev_cap * (LEMMA_MAX_MONEY_U64 as u64),
        cell < LEMMA_MAX_MONEY_U64,
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
    ensures
        (prev as int) + (cell as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_cube(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_CUBE as u64) * (LEMMA_MAX_ROWS_CUBE as u64)
                * (LEMMA_MAX_ROWS_CUBE as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64)
                * (LEMMA_MAX_ROWS_4 as u64) * (LEMMA_MAX_ROWS_4 as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_rem_cap_money_add_fits_pow4(prev_cap: u64)
    requires
        prev_cap
            <= (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64) * (LEMMA_MAX_ROWS as u64)
                * (LEMMA_MAX_ROWS as u64),
    ensures
        (prev_cap as int + 1) * (LEMMA_MAX_MONEY_U64 as int) <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_cube_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_ROWS_CUBE as int)
            * (LEMMA_MAX_ROWS_CUBE as int) * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
}

#[verifier::external_body]
pub proof fn lemma_max_rows_4_times_money_fits_u64()
    ensures
        (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_ROWS_4 as int) * (LEMMA_MAX_ROWS_4 as int)
            * (LEMMA_MAX_MONEY_U64 as int)
            <= u64::MAX as int,
{
}


// === Trusted arithmetic helpers ===
// TRUSTED: if (a as int) + (b as int) <= u64::MAX then add is mathematical +.
#[verifier::external_body]
pub exec fn add_u64(a: u64, b: u64) -> (res: u64)
    requires
        (a as int) + (b as int) <= u64::MAX as int,
    ensures
        res == a + b,
{
    a.checked_add(b).expect("Trusted overflow: ValidCols/requires violated")
}

// TRUSTED: if (a as int) * (b as int) <= u64::MAX then mul is mathematical *.
#[verifier::external_body]
pub exec fn mul_u64_u32(a: u64, b: u32) -> (res: u64)
    requires
        (a as int) * (b as int) <= u64::MAX as int,
    ensures
        res == a * (b as u64),
{
    a.checked_mul(b as u64).expect("Trusted overflow: ValidCols/requires violated")
}

// TRUSTED: if (a as int) - (b as int) fits in i64 then sub is mathematical -.
#[verifier::external_body]
pub exec fn sub_u64_to_i64(a: u64, b: u64) -> (res: i64)
    requires
        (a as int) - (b as int) >= i64::MIN as int,
        (a as int) - (b as int) <= i64::MAX as int,
    ensures
        res == (a as int) - (b as int),
{
    (a as i64) - (b as i64)
}

// TRUSTED: if (a as int) + (b as int) fits in i64 then add is mathematical +.
#[verifier::external_body]
pub exec fn add_i64(a: i64, b: i64) -> (res: i64)
    requires
        (a as int) + (b as int) >= i64::MIN as int,
        (a as int) + (b as int) <= i64::MAX as int,
    ensures
        res == a + b,
{
    a.checked_add(b).expect("Trusted overflow: ValidCols/requires violated")
}

// === CASE WHEN (simple int branches) ===
pub open spec fn case_when_u64(cond: bool, then_v: u64, else_v: u64) -> u64 {
    if cond { then_v } else { else_v }
}

#[verifier::external_body]
pub exec fn case_when_u64_exec(cond: bool, then_v: u64, else_v: u64) -> (res: u64)
    ensures res == case_when_u64(cond, then_v, else_v),
{
    if cond { then_v } else { else_v }
}

// === String LIKE helpers (basic % prefix/suffix/contains) ===
pub open spec fn str_like_prefix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_prefix_of(s)
}

pub open spec fn str_like_suffix(s: Seq<char>, lit: Seq<char>) -> bool {
    lit.is_suffix_of(s)
}

// Substring containment (open spec; empty lit matches any s).
pub open spec fn str_like_contains(s: Seq<char>, lit: Seq<char>) -> bool {
  if lit.len() == 0 {
    true
  } else {
    exists|i: int|
      0 <= i
      && i + lit.len() <= s.len()
      && #[trigger] s.subrange(i, i + lit.len()) == lit
  }
}

// TRUSTED: exec string prefix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_prefix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_prefix(s@, lit@),
{
    s.starts_with(lit)
}

// TRUSTED: exec string suffix check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_suffix_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_suffix(s@, lit@),
{
    s.ends_with(lit)
}

// TRUSTED: exec string contains check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_contains_exec(s: &str, lit: &str) -> (res: bool)
    ensures res == str_like_contains(s@, lit@),
{
    s.contains(lit)
}

// === ILIKE + underscore LIKE (C-tier: ASCII / DuckDB-like exec path) ===
pub open spec fn ascii_lower_char(c: char) -> char {
    if 'A' <= c && c <= 'Z' {
        ((c as int) - ('A' as int) + ('a' as int)) as char
    } else {
        c
    }
}

pub open spec fn str_ascii_lower(s: Seq<char>) -> Seq<char> {
    str_ascii_lower_helper(s, 0)
}

pub open spec fn str_ascii_lower_helper(s: Seq<char>, i: int) -> Seq<char>
    decreases s.len() - i,
{
    if i >= s.len() {
        Seq::empty()
    } else {
        str_ascii_lower_helper(s, i + 1).insert(0, ascii_lower_char(s[i]))
    }
}

pub open spec fn str_like_underscore_match(s: Seq<char>, pat: Seq<char>) -> bool {
    str_like_underscore_match_rec(s, pat, 0, 0)
}

pub open spec fn str_like_underscore_match_rec(
    s: Seq<char>,
    pat: Seq<char>,
    si: int,
    pi: int,
) -> bool
    decreases pat.len() - pi,
{
    if pi >= pat.len() {
        si >= s.len()
    } else if pat[pi] == '%' {
        exists|k: int|
            si <= k
            && k <= s.len()
            && #[trigger] str_like_underscore_match_rec(s, pat, k, pi + 1)
    } else if pat[pi] == '_' {
        si < s.len() && str_like_underscore_match_rec(s, pat, si + 1, pi + 1)
    } else if si >= s.len() || s[si] != pat[pi] {
        false
    } else {
        str_like_underscore_match_rec(s, pat, si + 1, pi + 1)
    }
}

// C-tier: ASCII ILIKE (matches exec to_ascii_lowercase + underscore match).
pub open spec fn str_ilike_match(s: Seq<char>, pat: Seq<char>) -> bool {
    str_like_underscore_match(str_ascii_lower(s), str_ascii_lower(pat))
}

// TRUSTED: exec ILIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_ilike_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_ilike_match(s@, pat@),
{
    str_like_underscore_match_exec(&s.to_ascii_lowercase(), &pat.to_ascii_lowercase())
}

// TRUSTED: exec underscore LIKE pattern check (ensures tie to spec).
#[verifier::external_body]
pub exec fn str_like_underscore_match_exec(s: &str, pat: &str) -> (res: bool)
    ensures res == str_like_underscore_match(s@, pat@),
{
    fn m(s: &[char], si: usize, p: &[char], pi: usize) -> bool {
        if pi >= p.len() {
            return si >= s.len();
        }
        if p[pi] == '%' {
            let mut k = si;
            while k <= s.len() {
                if m(s, k, p, pi + 1) {
                    return true;
                }
                k += 1;
            }
            return false;
        }
        if p[pi] == '_' {
            if si >= s.len() {
                return false;
            }
            return m(s, si + 1, p, pi + 1);
        }
        if si >= s.len() || s[si] != p[pi] {
            return false;
        }
        m(s, si + 1, p, pi + 1)
    }
    let sc: Vec<char> = s.chars().collect();
    let pc: Vec<char> = pat.chars().collect();
    m(&sc, 0, &pc, 0)
}

// === Scalar helpers (abs / case) ===
// abs on u64 cell: identity (non-negative type; SQL ABS on unsigned is a no-op).
pub open spec fn abs_u64(x: u64) -> u64 {
    x
}

#[verifier::external_body]
pub exec fn abs_u64_exec(x: u64) -> (res: u64)
    ensures res == abs_u64(x),
{
    x
}

// C-tier/ASCII dialect pin (same as ILIKE): lower/upper via per-char ASCII fold.
pub open spec fn ascii_upper_char(c: char) -> char {
    if 'a' <= c && c <= 'z' {
        ((c as int) - ('a' as int) + ('A' as int)) as char
    } else {
        c
    }
}

pub open spec fn str_ascii_upper(s: Seq<char>) -> Seq<char> {
    str_ascii_upper_helper(s, 0)
}

pub open spec fn str_ascii_upper_helper(s: Seq<char>, i: int) -> Seq<char>
    decreases s.len() - i,
{
    if i >= s.len() {
        Seq::empty()
    } else {
        str_ascii_upper_helper(s, i + 1).insert(0, ascii_upper_char(s[i]))
    }
}

pub open spec fn str_lower(s: Seq<char>) -> Seq<char> {
    str_ascii_lower(s)
}

pub open spec fn str_upper(s: Seq<char>) -> Seq<char> {
    str_ascii_upper(s)
}

#[verifier::external_body]
pub exec fn str_lower_exec(s: &str) -> (res: String)
    ensures res@ == str_lower(s@),
{
    s.to_ascii_lowercase()
}

#[verifier::external_body]
pub exec fn str_upper_exec(s: &str) -> (res: String)
    ensures res@ == str_upper(s@),
{
    s.to_ascii_uppercase()
}

// === Seq helpers (projection + LIMIT) ===
pub open spec fn spec_seq_take<A>(s: Seq<A>, n: int) -> Seq<A> {
    if n <= 0 {
        Seq::empty()
    } else if n >= s.len() {
        s
    } else {
        s.subrange(0, n)
    }
}

pub open spec fn spec_seq_concat<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_concat_helper(a, b, 0)
}

pub open spec fn spec_seq_concat_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        spec_seq_concat_helper(a.push(b[i]), b, i + 1)
    } else {
        a
    }
}

pub open spec fn spec_seq_union_distinct<A>(a: Seq<A>, b: Seq<A>) -> Seq<A> {
    spec_seq_union_distinct_helper(a, b, 0)
}

pub open spec fn spec_seq_union_distinct_helper<A>(a: Seq<A>, b: Seq<A>, i: int) -> Seq<A>
    decreases b.len() - i,
{
    if i < b.len() {
        let tail = spec_seq_union_distinct_helper(a, b, i + 1);
        if tail.contains(b[i]) {
            tail
        } else {
            tail.push(b[i])
        }
    } else {
        a
    }
}

pub open spec fn seq_sum_u64(s: Seq<u64>) -> u64 {
    seq_sum_u64_helper(s, 0)
}

pub open spec fn seq_sum_u64_helper(s: Seq<u64>, i: int) -> u64
    decreases s.len() - i,
{
    if i < s.len() {
        (seq_sum_u64_helper(s, i + 1) as int + s[i] as int) as u64
    } else {
        0
    }
}

// === IS NULL / anti-join (Lemma non-null loads; LEFT JOIN miss) ===
// Lemma non-null columnar loads compile base-table IS NULL without this helper.
// Multi-table LEFT JOIN miss is join-specific in MethodSpec; this schema-agnostic
// placeholder is always false (no unconstrained miss axiom on single-table emit).
pub open spec fn left_join_miss_generic(cols: &Cols, row: int) -> bool {
    false
}

// TRUSTED: multi-agg HashMap exec view bridge.
#[verifier::external_body]
pub open spec fn hashmap_multi_agg_view<K, V>(m: Map<K, V>) -> Map<K, V> {
    m
}


pub struct Cols {
    pub n: usize,
    pub tag: Vec<String>,
    pub version: Vec<String>,
    pub uom: Vec<String>,
    pub value: Vec<u64>,
    pub stmt: Vec<String>,
}

impl Cols {
    pub open spec fn get_tag(self, i: int) -> Seq<char> {
        self.tag[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_tag_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_tag(i as int),
    {
        self.tag[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_tag(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_tag(i as int) == lit@),
    {
        self.tag[i] == lit
    }
    pub open spec fn get_version(self, i: int) -> Seq<char> {
        self.version[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_version_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_version(i as int),
    {
        self.version[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_version(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_version(i as int) == lit@),
    {
        self.version[i] == lit
    }
    pub open spec fn get_uom(self, i: int) -> Seq<char> {
        self.uom[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_uom_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_uom(i as int),
    {
        self.uom[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_uom(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_uom(i as int) == lit@),
    {
        self.uom[i] == lit
    }
    pub open spec fn get_value(self, i: int) -> u64 {
        self.value[i as int]
    }

    #[verifier::external_body]
    pub exec fn get_value_exec(&self, i: usize) -> (res: u64)
        requires i < self.n,
        ensures res == self.get_value(i as int),
    {
        self.value[i]
    }
    pub open spec fn get_stmt(self, i: int) -> Seq<char> {
        self.stmt[i as int]@
    }

    #[verifier::external_body]
    pub exec fn get_stmt_exec(&self, i: usize) -> (res: String)
        requires i < self.n,
        ensures res@ == self.get_stmt(i as int),
    {
        self.stmt[i].clone()
    }

    #[verifier::external_body]
    pub exec fn eq_at_stmt(&self, i: usize, lit: &str) -> (res: bool)
        requires i < self.n,
        ensures res == (self.get_stmt(i as int) == lit@),
    {
        self.stmt[i] == lit
    }
    #[verifier::external_body]
    pub exec fn agg_push_str_tag_version(
        &self,
        agg: &mut HashMapWithView<(String, String), u64>,
        i: usize,
        delta: u64,
    )
        requires
            i < self.n &&
        delta < LEMMA_MAX_CELL_U64 &&
        (if old(agg)@.contains_key((self.get_tag(i as int), self.get_version(i as int))) { old(agg)@[(self.get_tag(i as int), self.get_version(i as int))] } else { 0u64 } as int) + ((delta as int) as int) <= u64::MAX as int,
        ensures
            final(agg)@ == old(agg)@.insert(
        (self.get_tag(i as int), self.get_version(i as int)),
        if old(agg)@.contains_key((self.get_tag(i as int), self.get_version(i as int))) {
            (old(agg)@[(self.get_tag(i as int), self.get_version(i as int))] as int + delta as int) as u64
        } else {
            delta
        },
    ),
    {
        let key = (self.get_tag_exec(i), self.get_version_exec(i));
        let prev = agg.get(&key).copied().unwrap_or(0u64);
        let next = prev.checked_add(delta).expect("Trusted overflow: requires violated");
        agg.insert(key, next);
    }
}


pub open spec fn valid_cols(cols: &Cols) -> bool {
    &&& cols.n <= LEMMA_MAX_ROWS
    &&& cols.tag@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.tag[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.version@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.version[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.uom@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.uom[i]@).len() <= LEMMA_MAX_STRING_LEN
    &&& cols.value.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> cols.value[i] < LEMMA_MAX_CELL_U64
    &&& cols.stmt@.len() == cols.n
    &&& forall|i: int| 0 <= i && i < cols.n as int ==> (cols.stmt[i]@).len() <= LEMMA_MAX_STRING_LEN
}

pub proof fn valid_cols_get_tag(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.tag[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_version(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.version[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_uom(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.uom[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub proof fn valid_cols_get_value(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures cols.value[i as int] < LEMMA_MAX_CELL_U64,
{
}

pub proof fn valid_cols_get_stmt(cols: &Cols, i: int)
    requires
        valid_cols(cols),
        0 <= i && i < cols.n as int,
    ensures (cols.stmt[i as int]@).len() <= LEMMA_MAX_STRING_LEN,
{
}

pub open spec fn method_spec_helper(cols: &Cols, k: int) -> Map<(Seq<char>, Seq<char>), u64>
    recommends
        0 <= k && k <= cols.n,
        valid_cols(cols),
    decreases cols.n - k,
{
    if k < cols.n {
        let tail = method_spec_helper(cols, k + 1);
        if ((cols.get_uom(k) == "USD"@ && true) && exists_corr_exists_1_spec(cols, (cols.get_tag(k), cols.get_version(k)))) {
            let key = (cols.tag[k as int]@, cols.version[k as int]@);
            let prev = if tail.contains_key(key) { tail[key] } else { 0u64 };
            tail.insert(key, (prev as int + 1u64 as int) as u64)
        } else {
            tail
        }
    } else {
        Map::empty()
    }
}

pub open spec fn exists_corr_exists_1_helper(cols: &Cols, outer_key: (Seq<char>, Seq<char>), k: int) -> bool
    recommends valid_cols(cols),
    decreases cols.n - k,
{
    if k < cols.n {
        if ((cols.get_tag(k) == outer_key.0 && cols.get_version(k) == outer_key.1) && cols.get_stmt(k) == "BS"@) {
            true
        } else {
            exists_corr_exists_1_helper(cols, outer_key, k + 1)
        }
    } else {
        false
    }
}

pub open spec fn exists_corr_exists_1_spec(cols: &Cols, outer_key: (Seq<char>, Seq<char>)) -> bool
    recommends valid_cols(cols),
{
    exists_corr_exists_1_helper(cols, outer_key, 0)
}

pub open spec fn method_spec(cols: &Cols) -> Map<(Seq<char>, Seq<char>), u64>
    recommends valid_cols(cols),
{
    method_spec_helper(cols, 0)
}

// Note: ORDER BY (cnt DESC), LIMIT 100, OFFSET 0 are not part of method_spec (((Seq<char>, Seq<char>), u64)); agent may apply in run_query.
// === Agent: use TRUSTED helpers below (vstd map/set @ views).
// Maps: agg_new_* / agg_add_* / agg_put_*; ensures res@ == method_spec.
// Multi-agg steps: agg_step_state_new_* / agg_step_* (+ agg_step_apply_row_* spec).
// HAVING: host post-filter exec helper (ensures vs apply_having_filter).
// Distinct sets: hashset_*_as_map + set_new_* / set_insert_* (COUNT_DISTINCT state).
// Seqs: seq_new_* / seq_push_* when present; else Vec@ directly.
use vstd::hash_map::{HashMapWithView, StringHashMap};
use vstd::hash_set::HashSetWithView;

// === TRUSTED structural map helpers (vstd view @ + agg_new + agg_put/agg_add) ===
#[verifier::external_body]
pub exec fn agg_new_str_str__u64() -> (hm: HashMapWithView<(String, String), u64>)
    ensures hm@ == Map::empty(),
{
    HashMapWithView::new()
}

#[verifier::external_body]
pub exec fn agg_add_str_str__u64(hm: &mut HashMapWithView<(String, String), u64>, k0: &str, k1: &str, delta: u64)
    requires
        delta < LEMMA_MAX_CELL_U64 &&
        (if old(hm)@.contains_key((k0@, k1@)) { old(hm)@[(k0@, k1@)] } else { 0u64 } as int) + ((delta as int)) <= u64::MAX as int,
    ensures
        final(hm)@ == old(hm)@.insert(
        (k0@, k1@),
        if old(hm)@.contains_key((k0@, k1@)) {
            (old(hm)@[(k0@, k1@)] as int + delta as int) as u64
        } else {
            delta
        },
    ),
{

    let key = (k0.to_string(), k1.to_string());
    let prev = hm.get(&key).copied().unwrap_or(0);
    hm.insert(key, prev.checked_add(delta).expect("Trusted overflow: ValidCols/requires violated"));
}

// === Scalar map fold bound assumptions (str_str_u64) ===
// ASSUMPTION (catalog/user): under `valid_cols` + this open-spec fold, partial agg ≤ rem·cap.
// Not a Verus-proved induction — expert accepts under table/catalog assumptions.
// COUNT: ≤((cols.n - k)) as u64 filtered rows in fold suffix.
#[verifier::external_body]
pub proof fn assume_method_spec_helper_count_leq_str_str_u64(
    cols: &Cols,
    k: int,
    key: (Seq<char>, Seq<char>),
)
    requires
        valid_cols(cols),
        0 <= cols.n as int,
        0 <= k <= cols.n as int,
    ensures
        (if method_spec_helper(cols, k).contains_key(key) { method_spec_helper(cols, k)[key] } else { 0u64 }) <= ((cols.n - k)) as u64,
{
}
} // verus!
