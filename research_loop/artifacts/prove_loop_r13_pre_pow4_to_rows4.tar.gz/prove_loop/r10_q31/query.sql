SELECT t.tlabel, t.datatype, COUNT(*) AS usage_count,
       COUNT(DISTINCT p.adsh) AS filing_count
FROM pre p
JOIN tag t ON p.tag = t.tag AND p.version = t.version
WHERE p.stmt = 'CI' AND t.tlabel IS NOT NULL
GROUP BY t.tlabel, t.datatype
HAVING COUNT(*) > 5
ORDER BY usage_count DESC
LIMIT 100;
