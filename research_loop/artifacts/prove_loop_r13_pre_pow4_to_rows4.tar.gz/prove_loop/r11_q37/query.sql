SELECT s.countryba, s.stprba,
       COUNT(DISTINCT s.adsh) AS num_filings,
       COUNT(DISTINCT s.cik) AS num_companies,
       SUM(n.value) AS total_value
FROM num n
JOIN sub s ON n.adsh = s.adsh
WHERE n.uom = 'shares' AND s.form = '10-Q'
      AND s.countryba IS NOT NULL AND n.value > 0
GROUP BY s.countryba, s.stprba
ORDER BY total_value DESC
LIMIT 100;
