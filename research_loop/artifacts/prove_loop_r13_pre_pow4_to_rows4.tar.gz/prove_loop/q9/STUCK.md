# Q9 — SUCCESS

Verified end-to-end (2026-08-10): nested reverse `agg_step_str_str__u64_u64` loops +
`apply_having_filter_exec_str_str__u64_u64(st.projected)`.

Admission OK; Verus `VERIFY True` / `SUCCESS`.
