//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT DISTINCT n.tag, n.version, COUNT(*) AS cnt
//!   FROM num n
//!   WHERE n.uom = 'pure' AND n.value IS NOT NULL
//!         AND EXISTS (
//!             SELECT 1 FROM pre p
//!             WHERE p.tag = n.tag AND p.version = n.version
//!                   AND p.stmt = 'EQ'
//!         )
//!   GROUP BY n.tag, n.version
//!   ORDER BY cnt DESC
//!   LIMIT 500;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
pub exec fn run_query(cols: &Cols) -> (res: HashMap<(String, String), u64>)
    requires valid_cols(cols),
    ensures hashmap_str_str_u64_view(res@) == method_spec(cols),
{
    let mut agg = agg_new_str_str_u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            hashmap_str_str_u64_view(agg@) == method_spec_helper(cols, i as int),
        decreases i,
    {
        i = i - 1;
        assert(i < cols.n);
        let uom_ok = cols.eq_at_uom(i, "pure");
        let tag = cols.get_tag_exec(i);
        let ver = cols.get_version_exec(i);
        let mut exists: bool = false;
        let mut j: usize = 0;
        while j < cols.n
            invariant
                i < cols.n,
                j <= cols.n,
                valid_cols(cols),
                tag@ == cols.get_tag(i as int),
                ver@ == cols.get_version(i as int),
                hashmap_str_str_u64_view(agg@) == method_spec_helper(cols, (i + 1) as int),
                (exists ==> exists_corr_exists_1_spec(
                    cols,
                    (cols.get_tag(i as int), cols.get_version(i as int)),
                )),
                (!exists ==> (
                    exists_corr_exists_1_helper(
                        cols,
                        (cols.get_tag(i as int), cols.get_version(i as int)),
                        0,
                    )
                    == exists_corr_exists_1_helper(
                        cols,
                        (cols.get_tag(i as int), cols.get_version(i as int)),
                        j as int,
                    )
                )),
            decreases cols.n - j,
        {
            if !exists {
                let tag_match = cols.eq_at_tag(j, tag.as_str());
                let ver_match = cols.eq_at_version(j, ver.as_str());
                let stmt_ok = cols.eq_at_stmt(j, "EQ");
                if tag_match && ver_match && stmt_ok {
                    exists = true;
                    proof {
                        let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
                        assert(cols.get_tag(j as int) == key.0);
                        assert(cols.get_version(j as int) == key.1);
                        assert(cols.get_stmt(j as int) == "EQ"@);
                        assert(exists_corr_exists_1_helper(cols, key, j as int));
                        assert(exists_corr_exists_1_helper(cols, key, 0)
                            == exists_corr_exists_1_helper(cols, key, j as int));
                        assert(exists_corr_exists_1_spec(cols, key));
                    }
                } else {
                    proof {
                        let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
                        assert(exists_corr_exists_1_helper(cols, key, j as int)
                            == exists_corr_exists_1_helper(cols, key, (j + 1) as int));
                    }
                }
            }
            j = j + 1;
        }
        proof {
            let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
            if exists {
                assert(exists_corr_exists_1_spec(cols, key));
            } else {
                assert(exists_corr_exists_1_helper(cols, key, 0)
                    == exists_corr_exists_1_helper(cols, key, cols.n as int));
                assert(!exists_corr_exists_1_helper(cols, key, cols.n as int));
                assert(!exists_corr_exists_1_spec(cols, key));
            }
        }
        if uom_ok && exists {
            agg_add_str_str_u64(&mut agg, tag.as_str(), ver.as_str(), 1u64);
            proof {
                let ghost tail = method_spec_helper(cols, (i + 1) as int);
                let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
                let ghost prev = if tail.contains_key(key) { tail[key] } else { 0u64 };
                assert(cols.get_uom(i as int) == "pure"@);
                assert(exists_corr_exists_1_spec(cols, key));
                assert(
                    method_spec_helper(cols, i as int)
                        == tail.insert(key, (prev as int + 1u64 as int) as u64)
                );
                assert(
                    hashmap_str_str_u64_view(agg@) == method_spec_helper(cols, i as int)
                );
            }
        } else {
            proof {
                assert(
                    method_spec_helper(cols, i as int)
                        == method_spec_helper(cols, (i + 1) as int)
                );
            }
        }
    }
    proof {
        assert(hashmap_str_str_u64_view(agg@) == method_spec_helper(cols, 0));
        assert(hashmap_str_str_u64_view(agg@) == method_spec(cols));
    }
    agg
}
// AGENT_EDIT_END

} // verus!
