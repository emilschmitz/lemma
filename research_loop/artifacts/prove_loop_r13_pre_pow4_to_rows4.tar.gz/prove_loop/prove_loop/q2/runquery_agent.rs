//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.form, s.fy, COUNT(*) AS num_lines,
//!          COUNT(DISTINCT p.tag) AS distinct_tags,
//!          AVG(p.line) AS avg_line
//!   FROM pre p
//!   JOIN sub s ON p.adsh = s.adsh
//!   WHERE p.stmt = 'IS'
//!   GROUP BY s.form, s.fy
//!   ORDER BY num_lines DESC
//!   LIMIT 1000;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, u32), (u64, u64, u64)>
// Trusted exec↔spec views in context/ro/spec.rs (use one in ensures): hashmap_str_u32__u64_u64_u64_view
// e.g. hashmap_str_u32__u64_u64_u64_view(res@) == method_spec(pre, sub)
// Hint stub below uses a common exec encoding; you may change -> / ensures to any admitted Trusted view for T.
pub exec fn run_query(pre: &Cols_pre, sub: &Cols_sub) -> (res: HashMap<(String, u32), (u64, u64, u64)>)
    requires valid_cols_pre(pre), valid_cols_sub(sub),
    ensures hashmap_str_u32__u64_u64_u64_view(res@) == method_spec(pre, sub),
{
    // TODO: implement hot path to match method_spec (see context/ro/spec.rs)
    HashMap::new()
}
// AGENT_EDIT_END

} // verus!
