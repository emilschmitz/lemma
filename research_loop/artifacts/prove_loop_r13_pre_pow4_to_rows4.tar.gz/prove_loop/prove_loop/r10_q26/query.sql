SELECT n.tag, t.tlabel, t.datatype,
       COUNT(DISTINCT n.adsh) AS num_filings,
       COUNT(*) AS total_entries,
       SUM(CASE WHEN n.value > 0 THEN 1 ELSE 0 END) AS positive_count,
       SUM(CASE WHEN n.value < 0 THEN 1 ELSE 0 END) AS negative_count
FROM num n
JOIN tag t ON n.tag = t.tag AND n.version = t.version
WHERE n.ddate BETWEEN 20220101 AND 20221231 AND n.value IS NOT NULL
      AND t.custom = 0
GROUP BY n.tag, t.tlabel, t.datatype
HAVING COUNT(DISTINCT n.adsh) > 100
ORDER BY num_filings DESC
LIMIT 500;
