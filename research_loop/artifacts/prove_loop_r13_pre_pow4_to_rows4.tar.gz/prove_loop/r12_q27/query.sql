SELECT s.form, s.fy, COUNT(*) AS num_lines,
       COUNT(DISTINCT p.tag) AS distinct_tags,
       AVG(p.line) AS avg_line
FROM pre p
JOIN sub s ON p.adsh = s.adsh
WHERE p.stmt = 'EQ'
GROUP BY s.form, s.fy
ORDER BY num_lines DESC
LIMIT 100;
