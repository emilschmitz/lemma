SELECT DISTINCT n.tag, n.version, COUNT(*) AS cnt
FROM num n
WHERE n.uom = 'pure' AND n.value IS NOT NULL
      AND EXISTS (
          SELECT 1 FROM pre p
          WHERE p.tag = n.tag AND p.version = n.version
                AND p.stmt = 'CI'
      )
GROUP BY n.tag, n.version
ORDER BY cnt DESC
LIMIT 1000;
