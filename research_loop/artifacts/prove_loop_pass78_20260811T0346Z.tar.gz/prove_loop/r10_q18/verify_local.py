#!/usr/bin/env python3
"""Local verify: transpile → admit → assemble → Verus (timeout=360)."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))

from research_loop.admit_agent_runquery import admit_agent_runquery
from research_loop.harness import run_verus_verify
from research_loop.method_spec_ret_type import resolve_ret_type_from_method_spec
from research_loop.scripts.sqlsmith_trusted_coverage import _assemble_program, load_sec_schema
from verus_transpiler import transpile_sql_to_verus
from verus_transpiler.column_projection import project_multi_schema_for_query
from verus_transpiler.parse_sql import normalize_schema

DIR = Path(__file__).resolve().parent


def main() -> int:
    sql = (DIR / "query.sql").read_text(encoding="utf-8")
    agent_src = (DIR / "runquery_agent.rs").read_text(encoding="utf-8")
    schema = load_sec_schema()
    _flat, multi = normalize_schema(schema)
    projected = project_multi_schema_for_query(sql, multi)
    spec_rs = transpile_sql_to_verus(sql, projected)
    (DIR / "spec_transpiled.rs").write_text(spec_rs, encoding="utf-8")

    ret_type = resolve_ret_type_from_method_spec(spec_rs)
    admit = admit_agent_runquery(agent_src, method_spec_rs=spec_rs)
    print("ADMIT", admit.ok, admit.violations)
    if not admit.ok:
        return 1
    assert admit.run_query_fn is not None

    program = _assemble_program(
        sql=sql,
        spec_rs=spec_rs,
        run_query_body=admit.run_query_fn,
        schema=schema,
        projected=projected,
        ret_type=ret_type,
    )
    out = DIR / "assembled.rs"
    out.write_text(program, encoding="utf-8")
    print("ASSEMBLED", out, "bytes", len(program))

    ok, msg = run_verus_verify(str(out), timeout=360)
    print("VERIFY", ok)
    if not ok:
        err = DIR / "verify_error.log"
        err.write_text(msg, encoding="utf-8")
        print(msg[-4000:])
        return 1
    (DIR / "verify_run.out").write_text(msg, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
