SELECT s.name, s.cik, s.sic, COUNT(*) AS num_entries,
       SUM(n.value) AS total_value
FROM num n
JOIN sub s ON n.adsh = s.adsh
WHERE n.uom = 'pure' AND n.ddate BETWEEN 20220101 AND 20221231
      AND n.value > 0
GROUP BY s.name, s.cik, s.sic
HAVING SUM(n.value) > 10000
ORDER BY total_value DESC
LIMIT 500;
