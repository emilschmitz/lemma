//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.name, s.cik, s.sic, COUNT(*) AS num_entries,
//!          SUM(n.value) AS total_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.uom = 'pure' AND n.ddate BETWEEN 20220101 AND 20221231
//!         AND n.value > 0
//!   GROUP BY s.name, s.cik, s.sic
//!   HAVING SUM(n.value) > 10000
//!   ORDER BY total_value DESC
//!   LIMIT 500;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START



// MethodSpec returns: Map<(Seq<char>, u32, u32), (u64, u64)>
// Trusted: hashmap_str_u32_u32__u64_u64_view / agg_step_* / apply_having_filter_exec_*
// Nested reverse scan matches multi_agg_helper; HAVING via apply_having_filter_exec_*.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: HashMapWithView<(String, u32, u32), (u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures res@ == method_spec(num, sub),
{
    let mut st = agg_step_state_new_str_u32_u32__u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, 0),
            st.projected@
                == agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@).map_values(
                    |v: (u64, u64)| agg_step_project_str_u32_u32__u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, i0 as int, sub.n as int)
                == multi_agg_helper(num, sub, (i0 + 1) as int, 0));
            assert(agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                valid_cols_num(num),
                valid_cols_sub(sub),
                agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, i1 as int),
                st.projected@
                    == agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@).map_values(
                        |v: (u64, u64)| agg_step_project_str_u32_u32__u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh_s = sub.get_adsh_exec(i1);
            let ddate = num.get_ddate_exec(i0);
            let value = num.get_value_exec(i0);
            if num.eq_at_adsh(i0, adsh_s.as_str())
                && num.eq_at_uom(i0, "pure")
                && ddate >= 20220101
                && ddate <= 20221231
                && value > 0
            {
                let name = sub.get_name_exec(i1);
                let cik = sub.get_cik_exec(i1);
                let sic = sub.get_sic_exec(i1);
                proof {
                    let ghost i0g = i0 as int;
                    let ghost i1g = (i1 + 1) as int;
                    let ghost tail = multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = (sub.name[i1 as int]@, sub.cik[i1 as int], sub.sic[i1 as int]);
                    let ghost prev = if tail.contains_key(key) { tail[key] } else { (0u64, 0u64) };
                    let ghost rem = (((sub.n - i1g) + (num.n - i0g - 1) * sub.n)) as u64;
                    lemma_multi_agg_helper_slot0_count_leq_str_u32_u32__u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.0 <= rem);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_u64_add_one_prev_le(prev.0, rem);
                    lemma_multi_agg_helper_slot1_sum_native_leq_str_u32_u32__u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.1 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_u64_add_native_prev_le(prev.1, (value) as u64, rem);
                }
                agg_step_str_u32_u32__u64_u64(
                    &mut st,
                    name.as_str(),
                    cik,
                    sic,
                    value,
                );
            } else {
                proof {
                    assert(
                        multi_agg_helper(num, sub, i0 as int, i1 as int)
                            == multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_u32_u32__u64_u64_spec(st.inner@)
            == multi_agg_helper(num, sub, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (u64, u64)| agg_step_project_str_u32_u32__u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (u64, u64)| (v.0, v.1),
                )
        );
    }
    apply_having_filter_exec_str_u32_u32__u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
