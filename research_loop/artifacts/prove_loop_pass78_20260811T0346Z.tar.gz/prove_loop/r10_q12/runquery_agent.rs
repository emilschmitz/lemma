//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.form, s.fy, COUNT(*) AS num_lines,
//!          COUNT(DISTINCT p.tag) AS distinct_tags,
//!          AVG(p.line) AS avg_line
//!   FROM pre p
//!   JOIN sub s ON p.adsh = s.adsh
//!   WHERE p.stmt = 'CF'
//!   GROUP BY s.form, s.fy
//!   ORDER BY num_lines DESC
//!   LIMIT 200;
//!

use vstd::prelude::*;
use std::collections::HashMap;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, u32), (u64, u64, u64)>
// Nested reverse scan matches multi_agg_helper; Trusted agg_step_* for COUNT/COUNT_DISTINCT/AVG.
pub exec fn run_query(pre: &Cols_pre, sub: &Cols_sub) -> (res: HashMap<(String, u32), (u64, u64, u64)>)
    requires valid_cols_pre(pre), valid_cols_sub(sub),
    ensures hashmap_str_u32__u64_u64_u64_view(res@) == method_spec(pre, sub),
{
    let mut st = agg_step_state_new_str_u32__u64_u64_u64();
    let mut i0: usize = pre.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= pre.n,
            i1 == 0,
            valid_cols_pre(pre),
            valid_cols_sub(sub),
            agg_step_inner_str_u32__u64_u64_u64_view(st.inner@)
                == multi_agg_helper(pre, sub, i0 as int, 0),
            hashmap_str_u32__u64_u64_u64_view(st.projected@)
                == agg_step_inner_str_u32__u64_u64_u64_view(st.inner@).map_values(
                    |v: (u64, Map<Seq<char>, bool>, u64, u64)| agg_step_project_str_u32__u64_u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(pre, sub, i0 as int, sub.n as int)
                == multi_agg_helper(pre, sub, (i0 + 1) as int, 0));
            assert(agg_step_inner_str_u32__u64_u64_u64_view(st.inner@)
                == multi_agg_helper(pre, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < pre.n,
                i1 <= sub.n,
                valid_cols_pre(pre),
                valid_cols_sub(sub),
                agg_step_inner_str_u32__u64_u64_u64_view(st.inner@)
                    == multi_agg_helper(pre, sub, i0 as int, i1 as int),
                hashmap_str_u32__u64_u64_u64_view(st.projected@)
                    == agg_step_inner_str_u32__u64_u64_u64_view(st.inner@).map_values(
                        |v: (u64, Map<Seq<char>, bool>, u64, u64)| agg_step_project_str_u32__u64_u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh_s = sub.get_adsh_exec(i1);
            if pre.eq_at_adsh(i0, adsh_s.as_str()) && pre.eq_at_stmt(i0, "CF") {
                let form = sub.get_form_exec(i1);
                let fy = sub.get_fy_exec(i1);
                let tag = pre.get_tag_exec(i0);
                let line = pre.get_line_exec(i0);
                agg_step_str_u32__u64_u64_u64(
                    &mut st,
                    form.as_str(),
                    fy,
                    tag.as_str(),
                    line as u64,
                );
                proof {
                    let ghost tail = multi_agg_helper(pre, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = (sub.form[i1 as int]@, sub.fy[i1 as int]);
                    let ghost prev = if tail.contains_key(key) {
                        tail[key]
                    } else {
                        (0u64, Map::empty(), 0u64, 0u64)
                    };
                    let ghost expected = agg_step_apply_row_str_u32__u64_u64_u64(
                        prev,
                        pre.tag[i0 as int]@,
                        pre.line[i0 as int] as u64,
                    );
                    assert(expected == multi_agg_helper(pre, sub, i0 as int, i1 as int)[key]);
                    assert(
                        agg_step_inner_str_u32__u64_u64_u64_view(st.inner@)
                            == multi_agg_helper(pre, sub, i0 as int, i1 as int)
                    );
                }
            } else {
                proof {
                    assert(
                        multi_agg_helper(pre, sub, i0 as int, i1 as int)
                            == multi_agg_helper(pre, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_u32__u64_u64_u64_view(st.inner@)
                    == multi_agg_helper(pre, sub, i0 as int, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_u32__u64_u64_u64_view(st.inner@)
            == multi_agg_helper(pre, sub, 0, 0));
        assert(
            hashmap_str_u32__u64_u64_u64_view(st.projected@)
                == multi_agg_helper(pre, sub, 0, 0).map_values(
                    |v: (u64, Map<Seq<char>, bool>, u64, u64)| agg_step_project_str_u32__u64_u64_u64(v),
                )
        );
        assert(
            hashmap_str_u32__u64_u64_u64_view(st.projected@)
                == multi_agg_helper(pre, sub, 0, 0).map_values(
                    |v: (u64, Map<Seq<char>, bool>, u64, u64)|
                        (v.0, v.1.dom().len() as u64, if v.3 == 0 { 0 } else { v.2 / v.3 }),
                )
        );
        assert(hashmap_str_u32__u64_u64_u64_view(st.projected@) == method_spec(pre, sub));
    }
    st.projected
}
// AGENT_EDIT_END

} // verus!
