SELECT s.form, COUNT(*) AS num_values,
       SUM(n.value) AS total_value, AVG(n.value) AS avg_value
FROM num n
JOIN sub s ON n.adsh = s.adsh
WHERE n.uom = 'USD' AND s.fy = 2024 AND n.value IS NOT NULL
GROUP BY s.form
ORDER BY total_value DESC;
