//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.name, s.cik, SUM(n.value) AS total_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.uom = 'shares' AND s.fy = 2024 AND n.value IS NOT NULL
//!   GROUP BY s.name, s.cik
//!   HAVING SUM(n.value) > (
//!       SELECT AVG(sub_total) FROM (
//!           SELECT SUM(n2.value) AS sub_total
//!           FROM num n2
//!           JOIN sub s2 ON n2.adsh = s2.adsh
//!           WHERE n2.uom = 'shares' AND s2.fy = 2024 AND n2.value IS NOT NULL
//!           GROUP BY s2.cik
//!       ) avg_sub
//!   )
//!   ORDER BY total_value DESC
//!   LIMIT 1000;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, u32), u64>
// Nested reverse scan matches join_method_spec_helper; HAVING via apply_having_filter_exec_*(agg, num, sub).
// ORDER BY/LIMIT are outside method_spec.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: HashMapWithView<(String, u32), u64>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures res@ == method_spec(num, sub),
{
    let mut hm = agg_new_str_u32__u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            hm@ == join_method_spec_helper(num, sub, i0 as int, 0),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(join_method_spec_helper(num, sub, i0 as int, sub.n as int)
                == join_method_spec_helper(num, sub, (i0 + 1) as int, 0));
            assert(hm@
                == join_method_spec_helper(num, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                valid_cols_num(num),
                valid_cols_sub(sub),
                hm@
                    == join_method_spec_helper(num, sub, i0 as int, i1 as int),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh_s = sub.get_adsh_exec(i1);
            let fy = sub.get_fy_exec(i1);
            if num.eq_at_adsh(i0, adsh_s.as_str())
                && num.eq_at_uom(i0, "shares")
                && fy == 2024
            {
                let name = sub.get_name_exec(i1);
                let cik = sub.get_cik_exec(i1);
                let value = num.get_value_exec(i0);
                proof {
                    let ghost i0g = i0 as int;
                    let ghost i1g = (i1 + 1) as int;
                    let ghost tail = join_method_spec_helper(num, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = (sub.name[i1 as int]@, sub.cik[i1 as int]);
                    let ghost prev = if tail.contains_key(key) { tail[key] } else { 0u64 };
                    let ghost rem = (((sub.n - i1g) + (num.n - i0g - 1) * sub.n)) as u64;
                    lemma_join_method_spec_helper_sum_money_leq_str_u32_u64(num, sub, i0g, i1g, key);
                    assert(prev <= rem * (LEMMA_MAX_MONEY_U64 as u64));
                    assert(value < LEMMA_MAX_MONEY_U64);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_rem_cap_money_add_fits(rem);
                    lemma_u64_add_money_prev_le(prev, value, rem);
                }
                agg_add_str_u32__u64(&mut hm, name.as_str(), cik, value);
            } else {
                proof {
                    assert(
                        join_method_spec_helper(num, sub, i0 as int, i1 as int)
                            == join_method_spec_helper(num, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(hm@ == join_method_spec_helper(num, sub, i0 as int, 0));
        }
    }
    proof {
        assert(hm@ == join_method_spec_helper(num, sub, 0, 0));
    }
    let res = apply_having_filter_exec_str_u32_u64(hm, num, sub);
    proof {
        let ghost m = join_method_spec_helper(num, sub, 0, 0);
        assert(
            res@
                == apply_having_filter(m, |k: (Seq<char>, u32), v: u64| (v > subquery_having_sq1_spec(num, sub)))
        );
        assert(res@ == method_spec(num, sub));
    }
    res
}
// AGENT_EDIT_END

} // verus!
