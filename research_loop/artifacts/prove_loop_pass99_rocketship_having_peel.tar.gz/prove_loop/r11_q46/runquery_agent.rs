//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.name, t.tlabel, SUM(n.value) AS total_value,
//!          COUNT(*) AS cnt
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   JOIN tag t ON n.tag = t.tag AND n.version = t.version
//!   WHERE n.uom = 'pure' AND s.fy = 2023
//!         AND s.sic BETWEEN 2000 AND 3999
//!         AND n.value IS NOT NULL AND t.abstract = 0
//!   GROUP BY s.name, t.tlabel
//!   HAVING SUM(n.value) > 1000
//!   ORDER BY total_value DESC
//!   LIMIT 1000;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START

// MethodSpec returns: Map<(Seq<char>, Seq<char>), (u64, u64)>
// Trusted: hashmap_str_str__u64_u64_view / agg_step_* / apply_having_filter_exec_*
// Nested reverse scan matches multi_agg_helper; HAVING via apply_having_filter_exec_*.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub, tag: &Cols_tag) -> (res: HashMapWithView<(String, String), (u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub), valid_cols_tag(tag),
    ensures res@ == method_spec(num, sub, tag),
{
    let mut st = agg_step_state_new_str_str__u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    let mut i2: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            i2 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            valid_cols_tag(tag),
            agg_step_inner_str_str__u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, tag, i0 as int, 0, 0),
            st.projected@
                == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                    |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, tag, i0 as int, sub.n as int, 0)
                == multi_agg_helper(num, sub, tag, (i0 + 1) as int, 0, 0));
            assert(agg_step_inner_str_str__u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, tag, i0 as int, i1 as int, 0));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                i2 == 0,
                valid_cols_num(num),
                valid_cols_sub(sub),
                valid_cols_tag(tag),
                agg_step_inner_str_str__u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, tag, i0 as int, i1 as int, 0),
                st.projected@
                    == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                        |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            i2 = tag.n;
            proof {
                assert(multi_agg_helper(num, sub, tag, i0 as int, i1 as int, tag.n as int)
                    == multi_agg_helper(num, sub, tag, i0 as int, (i1 + 1) as int, 0));
                assert(agg_step_inner_str_str__u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, tag, i0 as int, i1 as int, i2 as int));
            }
            while i2 > 0
                invariant
                    i0 < num.n,
                    i1 < sub.n,
                    i2 <= tag.n,
                    valid_cols_num(num),
                    valid_cols_sub(sub),
                    valid_cols_tag(tag),
                    agg_step_inner_str_str__u64_u64_spec(st.inner@)
                        == multi_agg_helper(num, sub, tag, i0 as int, i1 as int, i2 as int),
                    st.projected@
                        == agg_step_inner_str_str__u64_u64_spec(st.inner@).map_values(
                            |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                        ),
                decreases i2,
            {
                i2 = i2 - 1;
                let adsh_s = sub.get_adsh_exec(i1);
                let tag_t = tag.get_tag_exec(i2);
                let ver_t = tag.get_version_exec(i2);
                let fy_s = sub.get_fy_exec(i1);
                let sic_s = sub.get_sic_exec(i1);
                let abs_t = tag.get_abstract_exec(i2);
                if num.eq_at_adsh(i0, adsh_s.as_str())
                    && num.eq_at_tag(i0, tag_t.as_str())
                    && num.eq_at_version(i0, ver_t.as_str())
                    && num.eq_at_uom(i0, "pure")
                    && fy_s == 2023
                    && sic_s >= 2000
                    && sic_s <= 3999
                    && abs_t == 0
                {
                    let name = sub.get_name_exec(i1);
                    let tlabel = tag.get_tlabel_exec(i2);
                    let value = num.get_value_exec(i0);
                    proof {
                        let ghost i0g = i0 as int;
                        let ghost i1g = i1 as int;
                        let ghost i2g = (i2 + 1) as int;
                        let ghost tail = multi_agg_helper(num, sub, tag, i0 as int, i1 as int, (i2 + 1) as int);
                        let ghost key = (sub.name[i1 as int]@, tag.tlabel[i2 as int]@);
                        let ghost prev = if tail.contains_key(key) { tail[key] } else { (0u64, 0u64) };
                        let ghost rem = (((tag.n - i2g) + (sub.n - i1g - 1) * tag.n + (num.n - i0g - 1) * sub.n * tag.n)) as u64;
                        lemma_multi_agg_helper_slot0_sum_native_leq_str_str__u64_u64(num, sub, tag, i0g, i1g, i2g, key);
                        assert(prev.0 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                        assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                        assert(num.n <= LEMMA_MAX_ROWS);
                        assert(sub.n <= LEMMA_MAX_ROWS);
                        assert(tag.n <= LEMMA_MAX_ROWS);
                        lemma_fold_suffix_rem_leq_rows_pow3(num.n, sub.n, tag.n, i0g, i1g, i2g);
                        lemma_rem_cap_native_add_fits_pow4(rem);
                        lemma_u64_add_native_prev_le(prev.0, (value) as u64, rem);
                        lemma_multi_agg_helper_slot1_count_leq_str_str__u64_u64(num, sub, tag, i0g, i1g, i2g, key);
                        assert(prev.1 <= rem);
                        assert(num.n <= LEMMA_MAX_ROWS);
                        assert(sub.n <= LEMMA_MAX_ROWS);
                        assert(tag.n <= LEMMA_MAX_ROWS);
                        lemma_fold_suffix_rem_leq_rows_pow3(num.n, sub.n, tag.n, i0g, i1g, i2g);
                        lemma_u64_add_one_prev_le(prev.1, rem);
                    }
                    agg_step_str_str__u64_u64(
                        &mut st,
                        name.as_str(),
                        tlabel.as_str(),
                        value,
                    );
                } else {
                    proof {
                        assert(
                            multi_agg_helper(num, sub, tag, i0 as int, i1 as int, i2 as int)
                                == multi_agg_helper(num, sub, tag, i0 as int, i1 as int, (i2 + 1) as int)
                        );
                    }
                }
            }
            proof {
                assert(i2 == 0);
                assert(
                    agg_step_inner_str_str__u64_u64_spec(st.inner@)
                        == multi_agg_helper(num, sub, tag, i0 as int, i1 as int, 0)
                );
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_str__u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, tag, i0 as int, 0, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_str__u64_u64_spec(st.inner@)
            == multi_agg_helper(num, sub, tag, 0, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(num, sub, tag, 0, 0, 0).map_values(
                    |v: (u64, u64)| agg_step_project_str_str__u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(num, sub, tag, 0, 0, 0).map_values(
                    |v: (u64, u64)| (v.0, v.1),
                )
        );
    }
    apply_having_filter_exec_str_str__u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
