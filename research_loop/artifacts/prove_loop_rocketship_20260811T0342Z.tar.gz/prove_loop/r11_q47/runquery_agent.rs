//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT DISTINCT n.tag, n.version, COUNT(*) AS cnt
//!   FROM num n
//!   WHERE n.uom = 'USD' AND n.value IS NOT NULL
//!         AND EXISTS (
//!             SELECT 1 FROM pre p
//!             WHERE p.tag = n.tag AND p.version = n.version
//!                   AND p.stmt = 'BS'
//!         )
//!   GROUP BY n.tag, n.version
//!   ORDER BY cnt DESC
//!   LIMIT 100;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START

// MethodSpec returns: Map<(Seq<char>, Seq<char>), u64>
// Trusted: hashmap_str_str_u64_view / agg_new_str_str__u64 / agg_add_str_str__u64
// Reverse scan + nested EXISTS scan (same Cols); no HAVING / agg_step for this ret_type.
pub exec fn run_query(cols: &Cols) -> (res: HashMapWithView<(String, String), u64>)
    requires valid_cols(cols),
    ensures res@ == method_spec(cols),
{
    let mut agg = agg_new_str_str__u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            agg@ == method_spec_helper(cols, i as int),
        decreases i,
    {
        i = i - 1;
        assert(i < cols.n);
        let uom_ok = cols.eq_at_uom(i, "USD");
        let tag = cols.get_tag_exec(i);
        let ver = cols.get_version_exec(i);
        let mut exists: bool = false;
        let mut j: usize = 0;
        while j < cols.n
            invariant
                i < cols.n,
                j <= cols.n,
                valid_cols(cols),
                tag@ == cols.get_tag(i as int),
                ver@ == cols.get_version(i as int),
                agg@ == method_spec_helper(cols, (i + 1) as int),
                (exists ==> exists_corr_exists_1_spec(
                    cols,
                    (cols.get_tag(i as int), cols.get_version(i as int)),
                )),
                (!exists ==> (
                    exists_corr_exists_1_helper(
                        cols,
                        (cols.get_tag(i as int), cols.get_version(i as int)),
                        0,
                    )
                    == exists_corr_exists_1_helper(
                        cols,
                        (cols.get_tag(i as int), cols.get_version(i as int)),
                        j as int,
                    )
                )),
            decreases cols.n - j,
        {
            if !exists {
                let tag_match = cols.eq_at_tag(j, tag.as_str());
                let ver_match = cols.eq_at_version(j, ver.as_str());
                let stmt_ok = cols.eq_at_stmt(j, "BS");
                if tag_match && ver_match && stmt_ok {
                    exists = true;
                    proof {
                        let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
                        assert(cols.get_tag(j as int) == key.0);
                        assert(cols.get_version(j as int) == key.1);
                        assert(cols.get_stmt(j as int) == "BS"@);
                        assert(exists_corr_exists_1_helper(cols, key, j as int));
                        assert(exists_corr_exists_1_helper(cols, key, 0)
                            == exists_corr_exists_1_helper(cols, key, j as int));
                        assert(exists_corr_exists_1_spec(cols, key));
                    }
                } else {
                    proof {
                        let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
                        assert(exists_corr_exists_1_helper(cols, key, j as int)
                            == exists_corr_exists_1_helper(cols, key, (j + 1) as int));
                    }
                }
            }
            j = j + 1;
        }
        proof {
            let ghost key = (cols.get_tag(i as int), cols.get_version(i as int));
            if exists {
                assert(exists_corr_exists_1_spec(cols, key));
            } else {
                assert(exists_corr_exists_1_helper(cols, key, 0)
                    == exists_corr_exists_1_helper(cols, key, cols.n as int));
                assert(!exists_corr_exists_1_helper(cols, key, cols.n as int));
                assert(!exists_corr_exists_1_spec(cols, key));
            }
        }
        if uom_ok && exists {
            proof {
                let ghost kg = (i + 1;
                let ghost tail = method_spec_helper(cols, (i + 1);
                let ghost key = (cols.tag[i as int]@, cols.version[i as int]@);
                let ghost prev = if tail.contains_key(key) { tail[key] } else { 0u64 };
                let ghost rem = (((cols.n - kg))) as u64;
                lemma_method_spec_helper_count_leq_str_str_u64(cols, kg, key);
                assert(prev <= rem);
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                lemma_u64_add_one_prev_le(prev, rem);
            }
            agg_add_str_str__u64(&mut agg, tag.as_str(), ver.as_str(), 1u64);
        } else {
            proof {
                assert(
                    method_spec_helper(cols, (i + 1)
                        == method_spec_helper(cols, (i + 1)
                );
            }
        }
    }
    proof {
        assert(agg@ == method_spec_helper(cols, 0));
        assert(agg@ == method_spec(cols));
    }
    agg
}
// AGENT_EDIT_END

} // verus!
