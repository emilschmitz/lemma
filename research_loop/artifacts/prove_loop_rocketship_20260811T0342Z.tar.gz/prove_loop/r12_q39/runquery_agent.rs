//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.name, n.tag, n.value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.uom = 'shares' AND s.fy = 2023 AND n.value IS NOT NULL
//!         AND n.value = (
//!             SELECT MAX(n2.value)
//!             FROM num n2
//!             WHERE n2.tag = n.tag AND n2.adsh = n.adsh AND n2.uom = 'shares'
//!         )
//!   ORDER BY n.value DESC
//!   LIMIT 200;
//!

use vstd::prelude::*;
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Seq<(Seq<char>, Seq<char>, u64)>
// Reverse nested scan ≡ join_projection_helper; LIMIT via spec_seq_take / early stop;
// per-num-row reverse scan ≡ subquery_sq1_helper (MAX value for tag+adsh+uom).
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: Vec<(String, String, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures vec_str_str_u64_view(res@) == method_spec(num, sub),
{
    let mut out = seq_new_str_str_u64();
    let mut taken: usize = 0;
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            taken <= 200,
            valid_cols_num(num),
            valid_cols_sub(sub),
            taken as int == vec_str_str_u64_view(out@)))))).len(),
            vec_str_str_u64_view(out@))))))
                == spec_seq_take(join_projection_helper(num, sub, i0 as int, 0), 200),
        decreases i0,
    {
        i0 = i0 - 1;
        let tag_s = num.get_tag_exec(i0);
        let adsh_s = num.get_adsh_exec(i0);
        let mut mx: u64 = 0;
        let mut k: usize = num.n;
        while k > 0
            invariant
                i0 < num.n,
                k <= num.n,
                valid_cols_num(num),
                tag_s@ == num.get_tag(i0 as int),
                adsh_s@ == num.get_adsh(i0 as int),
                mx == subquery_sq1_helper(num, tag_s@, adsh_s@, k as int),
            decreases k,
        {
            k = k - 1;
            if num.eq_at_tag(k, tag_s.as_str())
                && num.eq_at_adsh(k, adsh_s.as_str())
                && num.eq_at_uom(k, "shares")
            {
                let v = num.get_value_exec(k);
                if v > mx {
                    mx = v;
                }
            }
            proof {
                assert(mx == subquery_sq1_helper(num, tag_s@, adsh_s@, k as int));
            }
        }
        proof {
            assert(mx == subquery_sq1_spec(num, tag_s@, adsh_s@));
            assert(mx == subquery_sq1_spec(num, num.tag[i0 as int]@, num.adsh[i0 as int]@));
        }
        i1 = sub.n;
        proof {
            assert(join_projection_helper(num, sub, i0 as int, sub.n as int)
                == join_projection_helper(num, sub, (i0 + 1) as int, 0));
            assert(vec_str_str_u64_view(out@))))))
                == spec_seq_take(join_projection_helper(num, sub, i0 as int, i1 as int), 200));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                taken <= 200,
                valid_cols_num(num),
                valid_cols_sub(sub),
                tag_s@ == num.get_tag(i0 as int),
                adsh_s@ == num.get_adsh(i0 as int),
                mx == subquery_sq1_spec(num, num.tag[i0 as int]@, num.adsh[i0 as int]@),
                taken as int == vec_str_str_u64_view(out@)))))).len(),
                vec_str_str_u64_view(out@))))))
                    == spec_seq_take(join_projection_helper(num, sub, i0 as int, i1 as int), 200),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh_sub = sub.get_adsh_exec(i1);
            let fy = sub.get_fy_exec(i1);
            let val = num.get_value_exec(i0);
            if num.eq_at_adsh(i0, adsh_sub.as_str())
                && num.eq_at_uom(i0, "shares")
                && fy == 2023
                && val == mx
            {
                if taken < 200 {
                    let name_s = sub.get_name_exec(i1);
                    seq_push_str_str_u64(
                        &mut out,
                        name_s.as_str(),
                        tag_s.as_str(),
                        val,
                    );
                    taken = taken + 1;
                    proof {
                        let ghost tail = join_projection_helper(
                            num, sub, i0 as int, (i1 + 1) as int,
                        );
                        let ghost row = (
                            sub.name[i1 as int]@,
                            num.tag[i0 as int]@,
                            num.value[i0 as int],
                        );
                        assert(join_projection_helper(num, sub, i0 as int, i1 as int)
                            == tail.push(row));
                        assert(vec_str_str_u64_view(out@))))))
                            == spec_seq_take(tail.push(row), 200));
                    }
                } else {
                    proof {
                        let ghost tail = join_projection_helper(
                            num, sub, i0 as int, (i1 + 1) as int,
                        );
                        let ghost row = (
                            sub.name[i1 as int]@,
                            num.tag[i0 as int]@,
                            num.value[i0 as int],
                        );
                        assert(join_projection_helper(num, sub, i0 as int, i1 as int)
                            == tail.push(row));
                        assert(taken == 200);
                        assert(vec_str_str_u64_view(out@))))))
                            == spec_seq_take(tail, 200));
                        assert(spec_seq_take(tail.push(row), 200)
                            == spec_seq_take(tail, 200));
                    }
                }
            } else {
                proof {
                    assert(join_projection_helper(num, sub, i0 as int, i1 as int)
                        == join_projection_helper(num, sub, i0 as int, (i1 + 1) as int));
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(vec_str_str_u64_view(out@))))))
                == spec_seq_take(join_projection_helper(num, sub, i0 as int, 0), 200));
        }
    }
    proof {
        assert(vec_str_str_u64_view(out@))))))
            == spec_seq_take(join_projection_helper(num, sub, 0, 0), 200));
        assert(vec_str_str_u64_view(out@)))))) == method_spec(num, sub));
    }
    out
}
// AGENT_EDIT_END

} // verus!
