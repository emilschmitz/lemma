//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.form, COUNT(*) AS num_values,
//!          SUM(n.value) AS total_value, AVG(n.value) AS avg_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.uom = 'USD' AND s.fy = 2024 AND n.value IS NOT NULL
//!   GROUP BY s.form
//!   ORDER BY total_value DESC;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START




// MethodSpec returns: Map<Seq<char>, (u64, u64, u64)>
// Nested reverse scan matches multi_agg_helper; Trusted agg_step + view.
// No HAVING predicate — return projected map directly.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: StringHashMap<(u64, u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures res@ == method_spec(num, sub),
{
    let mut st = agg_step_state_new_str__u64_u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            agg_step_inner_str__u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, 0),
            st.projected@
                == agg_step_inner_str__u64_u64_u64_spec(st.inner@).map_values(
                    |v: (u64, u64, u64, u64)| agg_step_project_str__u64_u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, i0 as int, sub.n as int)
                == multi_agg_helper(num, sub, (i0 + 1) as int, 0));
            assert(agg_step_inner_str__u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                valid_cols_num(num),
                valid_cols_sub(sub),
                agg_step_inner_str__u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, i1 as int),
                st.projected@
                    == agg_step_inner_str__u64_u64_u64_spec(st.inner@).map_values(
                        |v: (u64, u64, u64, u64)| agg_step_project_str__u64_u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh = sub.get_adsh_exec(i1);
            let fy = sub.get_fy_exec(i1);
            if num.eq_at_adsh(i0, adsh.as_str())
                && num.eq_at_uom(i0, "USD")
                && fy == 2024
            {
                let form = sub.get_form_exec(i1);
                let value = num.get_value_exec(i0);
                proof {
                    let ghost i0g = i0 as int;
                    let ghost i1g = (i1 + 1) as int;
                    let ghost rem = (((sub.n - i1g) + (num.n - i0g - 1) * sub.n)) as u64;
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    let ghost tail = multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = sub.form[i1 as int]@;
                    let ghost prev = if tail.contains_key(key) { tail[key] } else { (0u64, 0u64, 0u64, 0u64) };
                    let ghost rem = (((sub.n - i1g) + (num.n - i0g - 1) * sub.n)) as u64;
                    lemma_multi_agg_helper_slot0_count_leq_str__u64_u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.0 <= rem);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_rem_cap_one_add_fits(rem);
                    lemma_u64_add_one_prev_le(prev.0, rem);
                    lemma_multi_agg_helper_slot1_sum_native_leq_str__u64_u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.1 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_u64_add_native_prev_le(prev.1, (value) as u64, rem);
                    lemma_multi_agg_helper_slot2_sum_native_leq_str__u64_u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.2 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_u64_add_native_prev_le(prev.2, (value) as u64, rem);
                    lemma_multi_agg_helper_slot3_count_leq_str__u64_u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.3 <= rem);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    lemma_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_rem_cap_one_add_fits(rem);
                    lemma_u64_add_one_prev_le(prev.3, rem);
                }
                agg_step_str__u64_u64_u64(&mut st, form.as_str(), value);
            } else {
                proof {
                    assert(
                        multi_agg_helper(num, sub, i0 as int, i1 as int)
                            == multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
                assert(i1 == 0);
                assert(agg_step_inner_str__u64_u64_u64_spec(st.inner@) == multi_agg_helper(num, sub, i0 as int, 0));
        }
    }
    proof {
        assert(agg_step_inner_str__u64_u64_u64_spec(st.inner@)
            == multi_agg_helper(num, sub, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (u64, u64, u64, u64)| agg_step_project_str__u64_u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (u64, u64, u64, u64)| (v.0, v.1, if v.3 == 0 { 0 } else { v.2 / v.3 }),
                )
        );
    }
    st.projected
}
// AGENT_EDIT_END

} // verus!
