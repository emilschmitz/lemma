//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT n.tag, t.tlabel, t.datatype,
//!          COUNT(DISTINCT n.adsh) AS num_filings,
//!          COUNT(*) AS total_entries,
//!          SUM(CASE WHEN n.value > 0 THEN 1 ELSE 0 END) AS positive_count,
//!          SUM(CASE WHEN n.value < 0 THEN 1 ELSE 0 END) AS negative_count
//!   FROM num n
//!   JOIN tag t ON n.tag = t.tag AND n.version = t.version
//!   WHERE n.ddate BETWEEN 20220101 AND 20241231 AND n.value IS NOT NULL
//!         AND t.custom = 0
//!   GROUP BY n.tag, t.tlabel, t.datatype
//!   HAVING COUNT(DISTINCT n.adsh) > 100
//!   ORDER BY num_filings DESC
//!   LIMIT 1000;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START


// MethodSpec returns: Map<(Seq<char>, Seq<char>, Seq<char>), (u64, u64, u64, u64)>
// Nested reverse scan matches multi_agg_helper; HAVING via apply_having_filter_exec_*.
pub exec fn run_query(num: &Cols_num, tag: &Cols_tag) -> (res: HashMapWithView<(String, String, String), (u64, u64, u64, u64)>)
    requires valid_cols_num(num), valid_cols_tag(tag),
    ensures res@ == method_spec(num, tag),
{
    let mut st = agg_step_state_new_str_str_str__u64_u64_u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_tag(tag),
            agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, tag, i0 as int, 0),
            st.projected@
                == agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@).map_values(
                    |v: (Map<Seq<char>, bool>, u64, u64, u64)| agg_step_project_str_str_str__u64_u64_u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = tag.n;
        proof {
            assert(multi_agg_helper(num, tag, i0 as int, tag.n as int)
                == multi_agg_helper(num, tag, (i0 + 1) as int, 0));
            assert(agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, tag, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= tag.n,
                valid_cols_num(num),
                valid_cols_tag(tag),
                agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, tag, i0 as int, i1 as int),
                st.projected@
                    == agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@).map_values(
                        |v: (Map<Seq<char>, bool>, u64, u64, u64)| agg_step_project_str_str_str__u64_u64_u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let tag_s = tag.get_tag_exec(i1);
            let ver_s = tag.get_version_exec(i1);
            let ddate = num.get_ddate_exec(i0);
            let custom = tag.get_custom_exec(i1);
            if num.eq_at_tag(i0, tag_s.as_str())
                && num.eq_at_version(i0, ver_s.as_str())
                && ddate >= 20220101
                && ddate <= 20241231
                && custom == 0
            {
                let ntag = num.get_tag_exec(i0);
                let tlabel = tag.get_tlabel_exec(i1);
                let datatype = tag.get_datatype_exec(i1);
                let adsh = num.get_adsh_exec(i0);
                let value = num.get_value_exec(i0);
                proof {
                    let ghost i0g = i0 as int;
                    let ghost i1g = (i1 + 1) as int;
                    let ghost rem = (((tag.n - i1g) + (num.n - i0g - 1) * tag.n)) as u64;
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(tag.n <= LEMMA_MAX_ROWS);
                    assume_join_nested_rem_leq_rows_sq(num.n, tag.n, i0g, i1g);
                    let ghost tail = multi_agg_helper(num, tag, i0 as int, (i1 + 1) as int);
                    let ghost key = (num.tag[i0 as int]@, tag.tlabel[i1 as int]@, tag.datatype[i1 as int]@);
                    let ghost prev = if tail.contains_key(key) { tail[key] } else { (Map::empty(), 0u64, 0u64, 0u64) };
                    let ghost rem = (((tag.n - i1g) + (num.n - i0g - 1) * tag.n)) as u64;
                    assume_multi_agg_helper_slot1_count_leq_str_str_str__u64_u64_u64_u64(num, tag, i0g, i1g, key);
                    assert(prev.1 <= rem);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(tag.n <= LEMMA_MAX_ROWS);
                    assume_join_nested_rem_leq_rows_sq(num.n, tag.n, i0g, i1g);
                    lemma_rem_cap_one_add_fits(rem);
                    lemma_u64_add_one_prev_le(prev.1, rem);
                    assume_multi_agg_helper_slot2_count_leq_str_str_str__u64_u64_u64_u64(num, tag, i0g, i1g, key);
                    assert(prev.2 <= rem);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(tag.n <= LEMMA_MAX_ROWS);
                    assume_join_nested_rem_leq_rows_sq(num.n, tag.n, i0g, i1g);
                    lemma_rem_cap_one_add_fits(rem);
                    lemma_u64_add_one_prev_le(prev.2, rem);
                    assume_multi_agg_helper_slot3_count_leq_str_str_str__u64_u64_u64_u64(num, tag, i0g, i1g, key);
                    assert(prev.3 <= rem);
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(tag.n <= LEMMA_MAX_ROWS);
                    assume_join_nested_rem_leq_rows_sq(num.n, tag.n, i0g, i1g);
                    lemma_rem_cap_one_add_fits(rem);
                    lemma_u64_add_one_prev_le(prev.3, rem);
                }
                agg_step_str_str_str__u64_u64_u64_u64(
                    &mut st,
                    ntag.as_str(),
                    tlabel.as_str(),
                    datatype.as_str(),
                    adsh.as_str(),
                    value,
                );
            } else {
                proof {
                    assert(
                        multi_agg_helper(num, tag, i0 as int, i1 as int)
                            == multi_agg_helper(num, tag, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, tag, i0 as int, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_str_str__u64_u64_u64_u64_spec(st.inner@)
            == multi_agg_helper(num, tag, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(num, tag, 0, 0).map_values(
                    |v: (Map<Seq<char>, bool>, u64, u64, u64)| agg_step_project_str_str_str__u64_u64_u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(num, tag, 0, 0).map_values(
                    |v: (Map<Seq<char>, bool>, u64, u64, u64)| (v.0.dom().len() as u64, v.1, v.2, v.3),
                )
        );
    }
    apply_having_filter_exec_str_str_str__u64_u64_u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
