//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s1.cik, s1.name,
//!          COUNT(DISTINCT s1.fy) AS years_filed,
//!          MIN(s1.fy) AS first_year, MAX(s1.fy) AS last_year,
//!          COUNT(*) AS total_filings
//!   FROM sub s1
//!   WHERE s1.form = '10-K' AND s1.fy IS NOT NULL
//!   GROUP BY s1.cik, s1.name
//!   HAVING COUNT(DISTINCT s1.fy) >= 2
//!   ORDER BY total_filings DESC
//!   LIMIT 200;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START

// MethodSpec returns: Map<(u32, Seq<char>), (u64, u64, u64, u64)>
// Trusted: hashmap_u32_str__u64_u64_u64_u64_view / agg_step_* / apply_having_filter_exec_*
// Reverse scan matches method_spec_helper; HAVING via apply_having_filter_exec_*.
pub exec fn run_query(cols: &Cols) -> (res: HashMapWithView<(u32, String), (u64, u64, u64, u64)>)
    requires valid_cols(cols),
    ensures res@ == method_spec(cols),
{
    let mut st = agg_step_state_new_u32_str__u64_u64_u64_u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            agg_step_inner_u32_str__u64_u64_u64_u64_spec(st.inner@) == method_spec_helper(cols, i as int),
            st.projected@
                == agg_step_inner_u32_str__u64_u64_u64_u64_spec(st.inner@).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str__u64_u64_u64_u64(v),
                ),
        decreases i,
    {
        i = i - 1;
        if cols.eq_at_form(i, "10-K") {
            let cik = cols.get_cik_exec(i);
            let name = cols.get_name_exec(i);
            let fy = cols.get_fy_exec(i);
            proof {
                let ghost kg = (i + 1) as int;
                let ghost tail = method_spec_helper(cols, (i + 1) as int);
                let ghost key = (cols.cik[i as int], cols.name[i as int]@);
                let ghost prev = if tail.contains_key(key) { tail[key] } else { (Map::empty(), u64::MAX, 0u64, 0u64) };
                let ghost rem = (((cols.n - kg))) as u64;
                lemma_method_spec_helper_slot3_count_leq_u32_str__u64_u64_u64_u64(cols, kg, key);
                assert(prev.3 <= rem);
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                lemma_u64_add_one_prev_le(prev.3, rem);
            }
            agg_step_u32_str__u64_u64_u64_u64(
                &mut st,
                cik,
                name.as_str(),
                fy,
                fy as u64,
            );
        } else {
            proof {
                assert(
                    method_spec_helper(cols, i as int)
                        == method_spec_helper(cols, (i + 1) as int)
                );
            }
        }
    }
    proof {
        assert(agg_step_inner_u32_str__u64_u64_u64_u64_spec(st.inner@) == method_spec_helper(cols, 0));
        assert(
            st.projected@
                == method_spec_helper(cols, 0).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str__u64_u64_u64_u64(v),
                )
        );
        assert(
            st.projected@
                == method_spec_helper(cols, 0).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64)| (v.0.dom().len() as u64, v.1, v.2, v.3),
                )
        );
    }
    apply_having_filter_exec_u32_str__u64_u64_u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
