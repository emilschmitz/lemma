//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT stmt, rfile, COUNT(*) AS cnt,
//!          COUNT(DISTINCT adsh) AS num_filings,
//!          AVG(line) AS avg_line_num
//!   FROM pre
//!   WHERE stmt IS NOT NULL
//!   GROUP BY stmt, rfile
//!   ORDER BY cnt DESC;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// MethodSpec returns: Map<(Seq<char>, Seq<char>), (u64, u64, u64)>
// Trusted exec↔spec views in context/ro/spec.rs (use one in ensures): hashmap_str_str__u64_u64_u64_view
// Reverse scan + agg_step_* (no HAVING on this query).
pub exec fn run_query(cols: &Cols) -> (res: HashMapWithView<(String, String), (u64, u64, u64)>)
    requires valid_cols(cols),
    ensures res@ == method_spec(cols),
{
    let mut st = agg_step_state_new_str_str__u64_u64_u64();
    let mut i: usize = cols.n;
    while i > 0
        invariant
            i <= cols.n,
            valid_cols(cols),
            agg_step_inner_str_str__u64_u64_u64_spec(st.inner@) == method_spec_helper(cols, i as int),
            st.projected@
                == agg_step_inner_str_str__u64_u64_u64_spec(st.inner@).map_values(
                    |v: (u64, Map<Seq<char>, bool>, u64, u64)| agg_step_project_str_str__u64_u64_u64(v),
                ),
        decreases i,
    {
        i = i - 1;
        if !cols.eq_at_stmt(i, "") {
            let stmt = cols.get_stmt_exec(i);
            let rfile = cols.get_rfile_exec(i);
            let adsh = cols.get_adsh_exec(i);
            let line = cols.get_line_exec(i);
            proof {
                let ghost kg = (i + 1) as int;
                let ghost tail = method_spec_helper(cols, (i + 1) as int);
                let ghost key = (cols.stmt[i as int]@, cols.rfile[i as int]@);
                let ghost prev = if tail.contains_key(key) { tail[key] } else { (0u64, Map::empty(), 0u64, 0u64) };
                let ghost rem = (((cols.n - kg))) as u64;
                lemma_method_spec_helper_slot0_count_leq_str_str__u64_u64_u64(cols, kg, key);
                assert(prev.0 <= rem);
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                lemma_u64_add_one_prev_le(prev.0, rem);
                lemma_method_spec_helper_slot2_sum_native_leq_str_str__u64_u64_u64(cols, kg, key);
                assert(prev.2 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                assert(((line) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                lemma_u64_add_native_prev_le(prev.2, (line) as u64, rem);
                lemma_method_spec_helper_slot3_count_leq_str_str__u64_u64_u64(cols, kg, key);
                assert(prev.3 <= rem);
                assert(cols.n <= LEMMA_MAX_ROWS);
                assert(0 <= kg <= cols.n as int);
                assert((cols.n as int - kg) <= LEMMA_MAX_ROWS as int);
                lemma_u64_add_one_prev_le(prev.3, rem);
            }
            agg_step_str_str__u64_u64_u64(
                &mut st,
                stmt.as_str(),
                rfile.as_str(),
                adsh.as_str(),
                line as u64,
            );
        } else {
            proof {
                assert(
                    method_spec_helper(cols, i as int)
                        == method_spec_helper(cols, (i + 1) as int)
                );
            }
        }
    }
    st.projected
}
// AGENT_EDIT_END

} // verus!
