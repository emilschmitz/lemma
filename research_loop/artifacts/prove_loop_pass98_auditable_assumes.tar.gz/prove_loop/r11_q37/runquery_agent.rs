//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! MethodSpec + Trusted: context/ro/spec.rs (read-only; do not redefine).
//! schema.json lists the same projected columns as Cols.
//! Admission accepts direct or Trusted-view ensures matching MethodSpec T.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.countryba, s.stprba,
//!          COUNT(DISTINCT s.adsh) AS num_filings,
//!          COUNT(DISTINCT s.cik) AS num_companies,
//!          SUM(n.value) AS total_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   WHERE n.uom = 'shares' AND s.form = '10-Q'
//!         AND s.countryba IS NOT NULL AND n.value > 0
//!   GROUP BY s.countryba, s.stprba
//!   ORDER BY total_value DESC
//!   LIMIT 100;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START





// MethodSpec returns: Map<(Seq<char>, Seq<char>), (u64, u64, u64)>
// Nested reverse scan matches multi_agg_helper; ORDER BY/LIMIT are outside method_spec.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub) -> (res: HashMapWithView<(String, String), (u64, u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub),
    ensures res@ == method_spec(num, sub),
{
    let mut st = agg_step_state_new_str_str__u64_u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            agg_step_inner_str_str__u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, 0),
            st.projected@
                == agg_step_inner_str_str__u64_u64_u64_spec(st.inner@).map_values(
                    |v: (Map<Seq<char>, bool>, Map<u32, bool>, u64)|
                        agg_step_project_str_str__u64_u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, i0 as int, sub.n as int)
                == multi_agg_helper(num, sub, (i0 + 1) as int, 0));
            assert(agg_step_inner_str_str__u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, i0 as int, i1 as int));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                valid_cols_num(num),
                valid_cols_sub(sub),
                agg_step_inner_str_str__u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, i1 as int),
                st.projected@
                    == agg_step_inner_str_str__u64_u64_u64_spec(st.inner@).map_values(
                        |v: (Map<Seq<char>, bool>, Map<u32, bool>, u64)|
                            agg_step_project_str_str__u64_u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            let adsh_s = sub.get_adsh_exec(i1);
            let value = num.get_value_exec(i0);
            if num.eq_at_adsh(i0, adsh_s.as_str())
                && num.eq_at_uom(i0, "shares")
                && sub.eq_at_form(i1, "10-Q")
                && !sub.eq_at_countryba(i1, "")
                && value > 0
            {
                let countryba = sub.get_countryba_exec(i1);
                let stprba = sub.get_stprba_exec(i1);
                let adsh_n = num.get_adsh_exec(i0);
                let cik = sub.get_cik_exec(i1);
                proof {
                    let ghost i0g = i0 as int;
                    let ghost i1g = (i1 + 1) as int;
                    let ghost rem = (((sub.n - i1g) + (num.n - i0g - 1) * sub.n)) as u64;
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    assume_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    let ghost tail = multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int);
                    let ghost key = (sub.countryba[i1 as int]@, sub.stprba[i1 as int]@);
                    let ghost prev = if tail.contains_key(key) { tail[key] } else { (Map::empty(), Map::empty(), 0u64) };
                    let ghost rem = (((sub.n - i1g) + (num.n - i0g - 1) * sub.n)) as u64;
                    assume_multi_agg_helper_slot2_sum_native_leq_str_str__u64_u64_u64(num, sub, i0g, i1g, key);
                    assert(prev.2 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                    assert(num.n <= LEMMA_MAX_ROWS);
                    assert(sub.n <= LEMMA_MAX_ROWS);
                    assume_join_nested_rem_leq_rows_sq(num.n, sub.n, i0g, i1g);
                    lemma_rem_cap_native_add_fits(rem);
                    lemma_u64_add_native_prev_le(prev.2, (value) as u64, rem);
                }
                agg_step_str_str__u64_u64_u64(
                    &mut st,
                    countryba.as_str(),
                    stprba.as_str(),
                    adsh_n.as_str(),
                    cik,
                    value,
                );
            } else {
                proof {
                    assert(
                        multi_agg_helper(num, sub, i0 as int, i1 as int)
                            == multi_agg_helper(num, sub, i0 as int, (i1 + 1) as int)
                    );
                }
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_str_str__u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, i0 as int, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_str_str__u64_u64_u64_spec(st.inner@)
            == multi_agg_helper(num, sub, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (Map<Seq<char>, bool>, Map<u32, bool>, u64)|
                        agg_step_project_str_str__u64_u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(num, sub, 0, 0).map_values(
                    |v: (Map<Seq<char>, bool>, Map<u32, bool>, u64)|
                        (v.0.dom().len() as u64, v.1.dom().len() as u64, v.2),
                )
        );
    }
    st.projected
}
// AGENT_EDIT_END

} // verus!
