//! Host-owned shell — edit ONLY between AGENT_EDIT_START/END.
//! Cols / method_spec / valid_cols: context/ro/spec.rs (query-projected, not inlined).
//! schema.json lists the same projected columns as Cols.
//! Target SQL (also in context/ro/query.sql):
//!   SELECT s.sic, t.tlabel, p.stmt,
//!          COUNT(DISTINCT s.cik) AS num_companies,
//!          SUM(n.value) AS total_value,
//!          AVG(n.value) AS avg_value
//!   FROM num n
//!   JOIN sub s ON n.adsh = s.adsh
//!   JOIN tag t ON n.tag = t.tag AND n.version = t.version
//!   JOIN pre p ON n.adsh = p.adsh AND n.tag = p.tag AND n.version = p.version
//!   WHERE n.uom = 'USD' AND p.stmt = 'IS'
//!         AND s.sic BETWEEN 7000 AND 8999
//!         AND n.value IS NOT NULL AND t.abstract = 0
//!   GROUP BY s.sic, t.tlabel, p.stmt
//!   HAVING COUNT(DISTINCT s.cik) >= 2
//!   ORDER BY total_value DESC
//!   LIMIT 1000;
//!

use vstd::prelude::*;
use vstd::hash_map::{HashMapWithView, StringHashMap};
// Types below are provided when host assembles with spec.rs.

verus! {

// AGENT_EDIT_START
// Nested reverse scan matches multi_agg_helper; COUNT DISTINCT + SUM + AVG via agg_step_*;
// HAVING via apply_having_filter_exec_*.
pub exec fn run_query(num: &Cols_num, sub: &Cols_sub, tag: &Cols_tag, pre: &Cols_pre) -> (res: HashMapWithView<(u32, String, String), (u64, u64, u64)>)
    requires valid_cols_num(num), valid_cols_sub(sub), valid_cols_tag(tag), valid_cols_pre(pre),
    ensures res@ == method_spec(num, sub, tag, pre),
{
    let mut st = agg_step_state_new_u32_str_str__u64_u64_u64();
    let mut i0: usize = num.n;
    let mut i1: usize = 0;
    let mut i2: usize = 0;
    let mut i3: usize = 0;
    while i0 > 0
        invariant
            i0 <= num.n,
            i1 == 0,
            i2 == 0,
            i3 == 0,
            valid_cols_num(num),
            valid_cols_sub(sub),
            valid_cols_tag(tag),
            valid_cols_pre(pre),
            agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, tag, pre, i0 as int, 0, 0, 0),
            st.projected@
                == agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str_str__u64_u64_u64(v),
                ),
        decreases i0,
    {
        i0 = i0 - 1;
        i1 = sub.n;
        proof {
            assert(multi_agg_helper(num, sub, tag, pre, i0 as int, sub.n as int, 0, 0)
                == multi_agg_helper(num, sub, tag, pre, (i0 + 1) as int, 0, 0, 0));
            assert(agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, 0, 0));
        }
        while i1 > 0
            invariant
                i0 < num.n,
                i1 <= sub.n,
                i2 == 0,
                i3 == 0,
                valid_cols_num(num),
                valid_cols_sub(sub),
                valid_cols_tag(tag),
                valid_cols_pre(pre),
                agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, 0, 0),
                st.projected@
                    == agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@).map_values(
                        |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str_str__u64_u64_u64(v),
                    ),
            decreases i1,
        {
            i1 = i1 - 1;
            i2 = tag.n;
            proof {
                assert(multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, tag.n as int, 0)
                    == multi_agg_helper(num, sub, tag, pre, i0 as int, (i1 + 1) as int, 0, 0));
                assert(agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, 0));
            }
            while i2 > 0
                invariant
                    i0 < num.n,
                    i1 < sub.n,
                    i2 <= tag.n,
                    i3 == 0,
                    valid_cols_num(num),
                    valid_cols_sub(sub),
                    valid_cols_tag(tag),
                    valid_cols_pre(pre),
                    agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                        == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, 0),
                    st.projected@
                        == agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@).map_values(
                            |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str_str__u64_u64_u64(v),
                        ),
                decreases i2,
            {
                i2 = i2 - 1;
                i3 = pre.n;
                proof {
                    assert(multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, pre.n as int)
                        == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, (i2 + 1) as int, 0));
                    assert(agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                        == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, i3 as int));
                }
                while i3 > 0
                    invariant
                        i0 < num.n,
                        i1 < sub.n,
                        i2 < tag.n,
                        i3 <= pre.n,
                        valid_cols_num(num),
                        valid_cols_sub(sub),
                        valid_cols_tag(tag),
                        valid_cols_pre(pre),
                        agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                            == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, i3 as int),
                        st.projected@
                            == agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@).map_values(
                                |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str_str__u64_u64_u64(v),
                            ),
                    decreases i3,
                {
                    i3 = i3 - 1;
                    let adsh_s = sub.get_adsh_exec(i1);
                    let tag_t = tag.get_tag_exec(i2);
                    let ver_t = tag.get_version_exec(i2);
                    let adsh_p = pre.get_adsh_exec(i3);
                    let tag_p = pre.get_tag_exec(i3);
                    let ver_p = pre.get_version_exec(i3);
                    let abs_t = tag.get_abstract_exec(i2);
                    let sic = sub.get_sic_exec(i1);
                    if num.eq_at_adsh(i0, adsh_s.as_str())
                        && num.eq_at_tag(i0, tag_t.as_str())
                        && num.eq_at_version(i0, ver_t.as_str())
                        && num.eq_at_adsh(i0, adsh_p.as_str())
                        && num.eq_at_tag(i0, tag_p.as_str())
                        && num.eq_at_version(i0, ver_p.as_str())
                        && num.eq_at_uom(i0, "USD")
                        && pre.eq_at_stmt(i3, "IS")
                        && sic >= 7000
                        && sic <= 8999
                        && abs_t == 0
                    {
                        let tlabel = tag.get_tlabel_exec(i2);
                        let stmt = pre.get_stmt_exec(i3);
                        let cik = sub.get_cik_exec(i1);
                        let value = num.get_value_exec(i0);
                        proof {
                            let ghost i0g = i0 as int;
                            let ghost i1g = i1 as int;
                            let ghost i2g = i2 as int;
                            let ghost i3g = (i3 + 1) as int;
                            let ghost rem = (((pre.n as int - i3g) + (tag.n as int - i2g - 1) * (pre.n as int) + (sub.n as int - i1g - 1) * (tag.n as int * pre.n as int) + (num.n as int - i0g - 1) * (sub.n as int * tag.n as int * pre.n as int))) as u64;
                            assert(num.n <= LEMMA_MAX_ROWS_4);
                            assert(sub.n <= LEMMA_MAX_ROWS_4);
                            assert(tag.n <= LEMMA_MAX_ROWS_4);
                            assert(pre.n <= LEMMA_MAX_ROWS_4);
                            lemma_join_nested_rem_leq_rows_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g);
                            let ghost tail = multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, (i3 + 1) as int);
                            let ghost key = (sub.sic[i1 as int], tag.tlabel[i2 as int]@, pre.stmt[i3 as int]@);
                            let ghost prev = if tail.contains_key(key) { tail[key] } else { (Map::empty(), 0u64, 0u64, 0u64) };
                            let ghost rem = (((pre.n as int - i3g) + (tag.n as int - i2g - 1) * (pre.n as int) + (sub.n as int - i1g - 1) * (tag.n as int * pre.n as int) + (num.n as int - i0g - 1) * (sub.n as int * tag.n as int * pre.n as int))) as u64;
                            lemma_multi_agg_helper_slot1_sum_native_leq_u32_str_str__u64_u64_u64(num, sub, tag, pre, i0g, i1g, i2g, i3g, key);
                            assert(prev.1 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                            assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                            assert(num.n <= LEMMA_MAX_ROWS_4);
                            assert(sub.n <= LEMMA_MAX_ROWS_4);
                            assert(tag.n <= LEMMA_MAX_ROWS_4);
                            assert(pre.n <= LEMMA_MAX_ROWS_4);
                            lemma_join_nested_rem_leq_rows_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g);
                            lemma_rem_cap_native_add_fits_4((rem_join_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g) as u64));
                            lemma_u64_add_native_prev_le(prev.1, (value) as u64, (rem_join_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g) as u64));
                            lemma_multi_agg_helper_slot2_sum_native_leq_u32_str_str__u64_u64_u64(num, sub, tag, pre, i0g, i1g, i2g, i3g, key);
                            assert(prev.2 <= rem * (LEMMA_MAX_NATIVE_U32 as u64));
                            assert(((value) as u64) < (LEMMA_MAX_NATIVE_U32 as u64));
                            assert(num.n <= LEMMA_MAX_ROWS_4);
                            assert(sub.n <= LEMMA_MAX_ROWS_4);
                            assert(tag.n <= LEMMA_MAX_ROWS_4);
                            assert(pre.n <= LEMMA_MAX_ROWS_4);
                            lemma_join_nested_rem_leq_rows_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g);
                            lemma_rem_cap_native_add_fits_4((rem_join_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g) as u64));
                            lemma_u64_add_native_prev_le(prev.2, (value) as u64, (rem_join_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g) as u64));
                            lemma_multi_agg_helper_slot3_count_leq_u32_str_str__u64_u64_u64(num, sub, tag, pre, i0g, i1g, i2g, i3g, key);
                            assert(prev.3 <= rem);
                            assert(num.n <= LEMMA_MAX_ROWS_4);
                            assert(sub.n <= LEMMA_MAX_ROWS_4);
                            assert(tag.n <= LEMMA_MAX_ROWS_4);
                            assert(pre.n <= LEMMA_MAX_ROWS_4);
                            lemma_join_nested_rem_leq_rows_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g);
                            lemma_rem_cap_one_add_fits_4((rem_join_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g) as u64));
                            lemma_u64_add_one_prev_le(prev.3, (rem_join_4(num.n, sub.n, tag.n, pre.n, i0g, i1g, i2g, i3g) as u64));
                        }
                        agg_step_u32_str_str__u64_u64_u64(
                            &mut st,
                            sic,
                            tlabel.as_str(),
                            stmt.as_str(),
                            cik,
                            value,
                        );
                    } else {
                        proof {
                            assert(
                                multi_agg_helper(
                                    num, sub, tag, pre, i0 as int, i1 as int, i2 as int, i3 as int,
                                )
                                    == multi_agg_helper(
                                        num, sub, tag, pre, i0 as int, i1 as int, i2 as int, (i3 + 1) as int,
                                    )
                            );
                        }
                    }
                }
                proof {
                    assert(i3 == 0);
                    assert(
                        agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                            == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, i2 as int, 0)
                    );
                }
            }
            proof {
                assert(i2 == 0);
                assert(
                    agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                        == multi_agg_helper(num, sub, tag, pre, i0 as int, i1 as int, 0, 0)
                );
            }
        }
        proof {
            assert(i1 == 0);
            assert(
                agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
                    == multi_agg_helper(num, sub, tag, pre, i0 as int, 0, 0, 0)
            );
        }
    }
    proof {
        assert(agg_step_inner_u32_str_str__u64_u64_u64_spec(st.inner@)
            == multi_agg_helper(num, sub, tag, pre, 0, 0, 0, 0));
        assert(
            st.projected@
                == multi_agg_helper(num, sub, tag, pre, 0, 0, 0, 0).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64)| agg_step_project_u32_str_str__u64_u64_u64(v),
                )
        );
        assert(
            st.projected@
                == multi_agg_helper(num, sub, tag, pre, 0, 0, 0, 0).map_values(
                    |v: (Map<u32, bool>, u64, u64, u64)|
                        (v.0.dom().len() as u64, v.1, if v.3 == 0 { 0 } else { v.2 / v.3 }),
                )
        );
    }
    apply_having_filter_exec_u32_str_str__u64_u64_u64(st.projected)
}
// AGENT_EDIT_END

} // verus!
